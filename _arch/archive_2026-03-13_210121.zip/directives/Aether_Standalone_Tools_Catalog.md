# Aether Standalone Tools Catalog

Every component listed here is usable independently without the Aether pipeline. Each tool has a clean interface, zero coupling to other Aether modules, and solves a specific problem on its own.

Updated: 2026-03-05 (Phase 2 start)

---

## 1. AEC — Aether Entailment Check

**File:** `aec.py`
**Function:** `verify(response: str, kg_nodes: list[dict]) -> dict`
**Standalone Use:** Validate any LLM output against any structured knowledge.

```python
from aec import verify

response = "The company was founded in 2015 and has 500 employees."
kg = [{"@id": "company:acme", "founded": 2015, "employees": 500}]

result = verify(response, kg)
# score: 1.0, passed: True, grounded: 2, ungrounded: 0
```

**Value without Aether:** Plug into any LangChain chain, any LangGraph node, any custom pipeline. Any system that produces LLM output and has structured reference data can use AEC to measure grounding. No vectors, no embeddings, no dependencies.

**Who needs this:** Anyone who needs to know if an LLM is making things up.

---

## 2. Document to Knowledge Graph

**File:** Deep Research Prompt v2.0 template
**Function:** Structured prompt that produces KG triples from research output
**Standalone Use:** Convert any deep research paper into a JSON-LD knowledge graph.

**Input:** Any subject + areas of focus → feed to Gemini Deep Research or Claude
**Output:** Research paper + S-P-O triples + entity registry + persona + agent definition + citation registry

**Value without Aether:** Produces structured knowledge from unstructured research regardless of what system consumes it. The JSON-LD output is a standard format readable by Neo4j, any graph database, or plain JSON parsers.

**Who needs this:** Anyone building knowledge graphs from research material.

---

## 3. KG Loader & Manager

**File:** `kg.py`
**Functions:** `load_kg()`, `get_nodes()`, `query_nodes()`, `add_acquired()`, `get_core_nodes()`, `get_acquired_nodes()`, `save_kg()`, `stats()`
**Standalone Use:** General-purpose JSON-LD knowledge graph utility.

```python
from kg import load_kg, query_nodes, add_acquired, stats

kg = load_kg("any_graph.jsonld")
matches = query_nodes(kg, ["Thomas Jefferson", "France"])
kg = add_acquired(kg, {"subject": "New Fact", "predicate": "rdfs:comment", 
                        "object": "Learned", "confidence": 0.9})
print(stats(kg))  # {total: N, core: N, acquired: N}
```

**Value without Aether:** Read, query, and extend any JSON-LD file. Zone separation (core/acquired) is useful for any system that tracks knowledge provenance.

**Who needs this:** Anyone working with JSON-LD knowledge graphs in Python without wanting a full graph database.

---

## 4. Capsule Stamper

**File:** `stamper.py`
**Functions:** `stamp_empty()`, `stamp_from_source()`, `validate_capsule()`, `restamp()`
**Standalone Use:** Convert any document into a structured agent definition folder.

```python
from stamper import stamp_from_source

path = stamp_from_source("my-agent", "knowledge.md", "./agents")
# Creates: my-agent-v1.0.0-{uid}/
#   my-agent-v1.0.0-{uid}-manifest.json
#   my-agent-v1.0.0-{uid}-kb.md (from knowledge.md)
#   my-agent-v1.0.0-{uid}-definition.json (defaults)
#   my-agent-v1.0.0-{uid}-persona.json (defaults)
#   my-agent-v1.0.0-{uid}-kg.jsonld (empty)
```

**Value without Aether:** Standardizes any document into a 5-file agent package. The output folder structure works as a convention even without the Aether runtime — any system can read the JSON files.

**Who needs this:** Anyone who wants a repeatable structure for defining AI agents as files.

---

## 5. KG-to-DrawIO Diagram Generator

**File:** `skills/kg_drawio/kg_drawio.py`
**Function:** `generate_drawio(kg_data: dict, config: dict) -> str`
**Standalone Use:** Visualize any JSON-LD knowledge graph as a draw.io diagram.

```python
from kg_drawio import generate_drawio_file

generate_drawio_file(any_kg_data, "output.drawio", {
    "theme": "blueprint", "title": "My Graph", "layout_direction": "LR"
})
```

**Value without Aether:** Takes any JSON-LD data and produces a .drawio file. Entity types determine node shapes and colors. Relationship triples become edges. Inferred vs stated confidence renders as dashed vs solid lines. Four themes included.

**Who needs this:** Anyone who has structured data and wants a visual diagram without manual drawing.

---

## 6. Habitat — Service Registry & Router

**File:** `habitat.py`
**Class:** `Habitat()`
**Standalone Use:** Generic in-memory service registry with topic-based routing and gap detection.

```python
from habitat import Habitat

h = Habitat()
h.register("service-a", {"scent_subscriptions": ["orders.*", "payments"]})
h.register("service-b", {"scent_subscriptions": ["inventory.*"]})

h.route("orders.new")          # ["service-a"]
h.detect_gaps("shipping.track") # True — no handler
```

**Value without Aether:** A lightweight pub/sub router for any microservice, agent, or tool registry. Wildcard topic matching. Gap detection tells you what capabilities are missing. Message logging for audit.

**Who needs this:** Anyone building a service mesh, agent orchestrator, or capability registry.

---

## 7. LLM Wrapper

**File:** `llm.py`
**Functions:** `call_llm()`, `make_llm_fn()`
**Standalone Use:** Thin multi-provider LLM wrapper with token tracking and cost estimation.

```python
from llm import call_llm

result = call_llm("Explain photosynthesis", provider="anthropic")
# {"text": "...", "tokens_in": 12, "tokens_out": 150, "cost": 0.002}
```

**Value without Aether:** Never raises exceptions. Returns error strings instead. Tracks tokens and estimates cost automatically. Loads API keys from .env without python-dotenv. Supports Anthropic, OpenAI, and stub providers.

**Who needs this:** Anyone who wants a simple, safe LLM call wrapper without LangChain overhead.

---

## 8. Project Summary Prompt

**File:** Prompt template (text)
**Function:** Generate complete architectural documentation of any codebase
**Standalone Use:** Point Claude Code at any repo and get a structured summary.

```
Analyze this entire project and produce a structured summary 
document saved as PROJECT_SUMMARY.md...
```

**Output:** Directory tree, core components, architecture pattern, key abstractions, config files, dependencies, current state, known issues, how to run, file inventory.

**Value without Aether:** Works on any codebase in any language. The output is a universal format for onboarding, documentation, or feeding context to another AI instance.

**Who needs this:** Anyone who needs to understand a codebase quickly, onboard to a new project, or share architectural context across AI tools.

---

## 9. Deep Research Prompt v2.0

**File:** Prompt template (text)
**Function:** Generate a complete capsule-ready research paper from a subject and focus areas
**Standalone Use:** Produce publication-grade research with structured machine-readable outputs.

**Input:** `{Person}` + `{Areas of Focus}`
**Output:** 8 sections — research paper, KG triples, metadata, persona, persona metadata, agent definition, works cited, citation registry

**Value without Aether:** The research paper is useful on its own. The KG triples feed any graph database. The persona JSON works for any chatbot. The citation registry enables provenance tracking in any system.

**Who needs this:** Researchers, educators, content creators, anyone building knowledge-grounded AI agents.

---

## 10. ASCII Report Formatter

**File:** `report.py`
**Function:** `print_report(ctx: dict, aec_result: dict, capsule) -> None`
**Standalone Use:** Format any pipeline execution data into a structured ASCII terminal report.

**Value without Aether:** The report format (box-drawing chars, score bars, stage breakdowns, telemetry) could be adapted to visualize any multi-stage pipeline's execution. The pattern — header, profile, per-stage results, verification, telemetry summary, footer — is reusable.

**Who needs this:** Anyone who wants professional terminal output for pipeline debugging.

---

## Adoption Paths

Each standalone tool is an entry point into the architecture:

```
Use AEC alone → discover capsules → adopt the pipeline
Use the stamper → discover AEC → add verification
Use the KG loader → discover AEC → verify against your graph
Use the research prompt → discover the stamper → build agents from research
Use the draw.io skill → discover the KG format → build knowledge graphs
```

No tool requires adoption of the full framework. Every tool rewards it.

---

*Catalog will be reviewed and updated after each Phase 2 step.*
