# Aether Deferred Topics

Living list of topics identified during the clean build that are outside core scope. These are valid features, enhancements, or architectural decisions that should be addressed after the foundation is working.

Updated: 2026-03-05 (rev 4 — 37 items)

---

## AEC Refinements

1. **LLM self-scoring layer** — 60/40 hybrid scoring (60% LLM, 40% deterministic gate). V1 is deterministic-only. Add LLM self-classification of statements as KB_GROUNDED vs PERSONA_GENERATED when an llm_fn is available.

2. **Education queue** — When AEC fails, the prompt-response pair and identified gaps should enter an async queue (Kafka, Redis, or simple file-based). Background process researches gaps, validates new knowledge through AEC, and integrates into KG acquired zone. Stub the interface, build later.

3. **Name matching precision** — Bidirectional partial matching ("Thomas" matches "Thomas Jefferson") is too loose. Consider requiring minimum token overlap ratio or exact match on multi-word names.

4. **Cross-statement entity resolution** — Currently each statement is evaluated independently. "He authored the Declaration" loses the "He = Jefferson" reference. Coreference resolution would improve accuracy but adds complexity.

5. **Persona ratio monitoring** — Track persona_ratio over time per capsule. If it trends above 30-40%, the KB may need expansion even if individual responses pass threshold.

---

## Code Refinements

5.5. **Refactor aether.py augment to use kg.py** — aether.py's augment stage (lines 157-165) duplicates KG node matching logic. Should delegate to `kg.query_nodes()` to avoid duplicate search logic. After all seven core files exist.

---

## KG & Knowledge Management

6. **Selective subgraph extraction** — N-hop expansion, temporal filtering, edge pruning for large KGs. Current augment stage does basic entity matching. Needed when KGs exceed ~100 nodes.

7. **Knowledge Origin Classification (5 types)** — Every KG node carries an `aether:origin` tag. Full classification:

    | Type | How it gets there | Mutable | Example |
    |---|---|---|---|
    | **core** | Original source material at stamp time | Never | Deep research paper content |
    | **acquired** | AEC self-education loop — agent learned from a failure | Prunable if it degrades | Fact the agent didn't know, researched, validated, added |
    | **updated** | Scheduled maintenance sweep — validated against live sources | Replaces stale data | URL checked, source content changed, KG node refreshed |
    | **deprecated** | Manual or automated flag — knowledge no longer valid | Frozen, not deleted | Technology replaced, law changed, person left a role |
    | **provenance** | Citation and source metadata | Updated during maintenance | URL, access date, validation status, source type |

    Node lifecycle: `core → (maintenance) → updated → (source dies) → deprecated` and `core → (AEC gap) → acquired → (maintenance) → updated` and `acquired → (reinforcement score drops) → pruned`

    Implementation: Update `kg.py`'s `add_acquired()` to accept any origin type as a parameter instead of hardcoding "acquired". Add `mark_deprecated()` and `mark_updated()` convenience functions. Each node gets full provenance metadata: origin, timestamp, trigger event, confidence, source reference.

    Future file consideration: agents with systematic updates may split KB into typed files (`{agent}-kb.md` for core, `{agent}-kb-acquired.md` for learned). For v1, the KG handles all zone tracking through node tags. KB stays as one file.

8. **KG maintenance sweeps** — Background process that walks provenance nodes, validates URLs are live, checks if source content has changed. Flags stale knowledge across all agents. Supports: scheduled sweeps, manual override, forced revalidation when a technology is deprecated or similar. Dead URLs flag all connected claim nodes. Changed content triggers AEC re-education. Works against the agent registry KG (item 17) to identify all affected agents from a single source change.

9. **KG consolidation and pruning** — Analogous to human expertise abstracting mental models. Merge redundant nodes, prune low-value edges, simplify graph structure as it grows.

10. **Inter-capsule KG linking** — How do KG nodes from different capsules relate? Shared entity registry? Federated graph? Needed for multi-agent composition.

---

## UI & Embodiment

11. **EDS token mapping + DAI pulse** — CSS custom property streaming for real-time UI adaptation. Agent projects its body through CSS variables. Core concept proven in aether-KB-as-body and aether-RD.

12. **NEEDS plugin** — Replace React entirely with EDS HTML output + DAI pulse CSS streams. Proven in POC.

13. **Aura protocol** — 500-byte WebSocket client for UI streaming. Separate project from core framework.

14. **Design system adaptation** — EDS tokens mapping to SAP UI5 theming, React components, native/mobile. One agent DNA drives all render targets.

---

## Communication & Multi-Agent

15. **A2A KG handshake** — Agents communicating via JSON-LD subgraphs rather than text. Proven in POC.

16. **Pheromone routing / stigmergic communication** — Capsules emit and sniff signals through a Habitat registry. Anti-graph principle: capsules never call each other directly. Proven in aether-RD.

17. **Agent registry KG** — A meta-KG listing all capsules, their capabilities, domain boundaries, and provenance dependencies. Enables orchestrator routing and fleet maintenance.

18. **Framework adapters** — LangChain, LangGraph, CrewAI adapters. Built in aether-core. Important for adoption but not core.

---

## Platform Export & Import (NEAR-TERM PRIORITY)

18.5. **Bidirectional agent.md integration** — GitHub now supports `agent.md` files at `.github/agents/` for defining Copilot agent personas. Two directions:

    **Export:** Generate agent.md from an Aether capsule. The capsule already has definition, persona, domain boundaries, and constraints. Formatting these into agent.md is ~30 lines of code. A stamper add-on.

    **Import:** Use an agent.md file AS the KB for stamping an Aether capsule. The agent.md is the seed — same graduation model as skill.md. File → stamp → capsule → AEC improves it → export updated agent.md back to Copilot.

    **Bidirectional flow:**
    `agent.md → stamp into capsule → AEC self-education → export improved agent.md`
    Copilot agent gets smarter through Aether's loop, deploys back as an updated agent.md. User never sees capsule internals.

    **Implementation:** Build a generic export layer, not hardcoded to one platform:
    `export(capsule, format="github-agent-md")`
    Then add formats as needed:
    - `format="github-agent-md"` — GitHub Copilot Desktop
    - `format="claude-skill"` — Anthropic Claude skills
    - `format="openai-assistant"` — OpenAI assistant definitions
    - `format="a2a-agent-card"` — A2A .well-known/agent-card.json

    This is low-effort, high-value. Capsules become deployable to any platform that accepts agent definition files. Jeff is already creating agent.md files for Copilot Desktop and using them as KB inputs — pattern is proven.

---

## Meta-Agent & Self-Assembly

19. **DSL-driven composition** — Logic agent reads composition rules, matches diagnosed failures to brick registry, stamps new capsules. Section 8 of architecture doc.

20. **Autonomous brick creation** — When no existing capsule solves a problem, orchestrator writes new code (Python file), creates it as a feature brick, attaches to existing capsule, restamps.

21. **Brick registry** — Catalog of all available skills, DSL rules, API specs, native functions. Searchable, composable. Future tier.

22. **Version restamping** — Adding a brick to a capsule creates a new version (new folder, new ID). Original untouched. Rollback possible.

---

## Enterprise & Deployment

23. **SAP CAP integration** — Aether capsules pluggable into CAP applications. Needed for the work project sales agent demo.

24. **MCP server** — Capsule capabilities exposed as MCP tools for Claude, Cline, or other AI interfaces.

25. **"Do not re-educate" flag** — Manifest configuration that freezes a capsule's knowledge. For legal documents, regulatory snapshots, historical records.

26. **Fleet-wide operations** — Re-educate all agents affected by a source change. Upgrade protocols across agents. Driven by the agent registry KG.

---

## Documentation & Publication

27. **Letter to Anthropic** — Draft complete. Needs personal details filled in and final review.

28. **Conceptual piece** — "Agents as code = agents as skills." Paradigm argument for broad audience.

29. **Technical paper** — AEC process, capsule architecture, deterministic validation gates. Rigorous enough for peer review.

30. **Practitioner piece** — How a principal SA at Fortune 50 used this to produce validated deliverables. LinkedIn/Hacker News audience.

31. **Deep research prompt v2** — Complete. Generates all capsule components from a single prompt.

---

## Build Kit & Side Hustle

32. **Vulture Nest** — Trend-based app gap analysis. Automated community research, complaint extraction, application creation.

33. **Automated build kits** — Chrome extension output, mobile app output. Standard design system, legal stamps.

34. **Project agent pattern** — Dump project files into a folder, have Claude Code/Gemini CLI transform into structured knowledge. Project summary prompt proven.

---

## Dashboard & Command Center (NEAR-TERM PRIORITY)

35. **Aether Dashboard** — Single HTML file, no React, no framework. Served via `aether serve` command added to cli.py. SSE for live updates. Same pattern as aether-KB-as-body 17-line kernel. Build AFTER cli.py is done and one real capsule has run end-to-end with a live LLM. Reference: aether-RD/capsules/skill_lab.html (1,454 lines). Components:
    - **Capsule browser** — List all capsules in habitat, show manifest, definition, persona, KG stats, AEC history
    - **KG visualizer** — Interactive D3.js force-directed graph. Nodes colored by entity type. Core vs acquired nodes visually distinct. Click node to inspect properties. Edge labels show predicates.
    - **Pipeline runner** — Type query, select capsule, watch distill → augment → generate → review in real time. Show selected subgraph, built prompt, response, AEC breakdown per statement.
    - **AEC inspector** — Per-run view of every statement tagged GROUNDED/UNGROUNDED/PERSONA. Show matched KG nodes. Show gaps. Primary debugging tool.
    - **Habitat map** — All registered capsules, topic subscriptions, message routing visualization. Highlight gaps (topics with no subscribers).
    - **Test execution** — Run test suites against capsules directly from the dashboard. Show pass/fail, AEC scores, regression tracking.

---

*Items are numbered for reference. Priority and sequencing TBD after core build is complete.*
