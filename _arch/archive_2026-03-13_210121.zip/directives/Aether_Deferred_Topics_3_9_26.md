# Aether Deferred Topics

Living list of topics identified during the clean build that are outside core scope. These are valid features, enhancements, or architectural decisions that should be addressed after the foundation is working.

Updated: 2026-03-09 (rev 13 — 55 items)

---

## AEC Refinements

1. **LLM self-scoring layer** — 60/40 hybrid scoring (60% LLM, 40% deterministic gate). V1 is deterministic-only. Add LLM self-classification of statements as KB_GROUNDED vs PERSONA_GENERATED when an llm_fn is available.

2. **Education queue** — When AEC fails, the prompt-response pair and identified gaps should enter an async queue (Kafka, Redis, or simple file-based). Background process researches gaps, validates new knowledge through AEC, and integrates into KG acquired zone. Stub the interface, build later.

3. **Name matching precision** — Bidirectional partial matching ("Thomas" matches "Thomas Jefferson") is too loose. Consider requiring minimum token overlap ratio or exact match on multi-word names.

4. **Cross-statement entity resolution** — Currently each statement is evaluated independently. "He authored the Declaration" loses the "He = Jefferson" reference. Coreference resolution would improve accuracy but adds complexity.

5. **Persona ratio monitoring** — Track persona_ratio over time per capsule. If it trends above 30-40%, the KB may need expansion even if individual responses pass threshold.

---

## AEC Extraction Architecture (NEAR-TERM PRIORITY)

5.6. **Pluggable extraction skills for the deterministic gate** — The current `_extract_values()` in aec.py is a monolithic function with hardcoded regex patterns. It fails on magnitude words ("$25 million" extracts as 25, not 25000000), scientific notation, unit conversions, regulatory references, and domain-specific identifiers.

    **Core problem:** Different agent domains need different value extraction capabilities. A financial agent needs magnitude expansion and currency parsing. A scientific agent needs exponent notation and unit conversion. A compliance agent needs statute reference parsing.

    **Proposed solution — Extraction skills as pluggable functions:**

    The `definition.json` already has `suggested_aec_gates`. These should map to actual extraction functions:

    ```json
    "suggested_aec_gates": [
        "numerical_validation",
        "magnitude_expansion",
        "currency_parsing",
        "percentage_validation",
        "ticker_symbol_matching"
    ]
    ```

    Each gate is a small function (5-20 lines) that takes text and returns `(original, normalized, type)` tuples — the same format `_extract_values()` currently produces. The base set ships with Aether:

    | Skill | What it handles | Example |
    |---|---|---|
    | `base_numbers` | Integers, decimals, comma-grouped | `1,743` → `1743.0` |
    | `base_dates` | Years, full dates, ISO | `April 13, 1743` → `1743-04-13` |
    | `base_names` | Capitalized word sequences | `Thomas Jefferson` |
    | `base_percentages` | N%, N percent | `19.8%` → `19.8` |
    | `magnitude_expansion` | million, billion, trillion | `$25 million` → `25000000` |
    | `currency_parsing` | $, €, £ with magnitude | `$373.3 billion` → `373300000000` |
    | `scientific_notation` | 3.2 × 10^8 | → `320000000` |
    | `regulatory_refs` | Section 501(c)(3), Rule 10b-5 | Pattern matching |
    | `ticker_symbols` | AAPL, BRK.B | Match against KG ticker fields |

    The base four (numbers, dates, names, percentages) are always active. Additional skills are loaded based on `suggested_aec_gates` in the definition. This makes AEC domain-adaptive without making aec.py larger.

    **Implementation:** A new file `extraction_skills.py` (~150 lines) containing all skill functions. `aec.py` imports it and calls the skills listed in the agent's definition. Default behavior (no definition) uses the base four.

    **Immediate fix (before full skill system):** Add magnitude expansion to `_extract_values()` as a stopgap. 10 lines: detect "million/billion/trillion" after a number, multiply accordingly. This unblocks the Buffett agent without waiting for the full pluggable system.

    **Evidence:** Buffett agent scored 0.091 because "$25 million" extracted as `25` vs KG value `25000000`. A correct extraction produces `25000000` which matches within 1% tolerance. Same issue affects every financial, scientific, and enterprise agent.

---

## Code Refinements

5.5. **Refactor aether.py augment to use kg.py** — aether.py's augment stage (lines 157-165) duplicates KG node matching logic. Should delegate to `kg.query_nodes()` to avoid duplicate search logic. After all seven core files exist.

---

## KG & Knowledge Management

6. **Selective subgraph extraction** — N-hop expansion, temporal filtering, edge pruning for large KGs. Current augment stage does basic entity matching. Needed when KGs exceed ~100 nodes.

7. **Knowledge Origin Classification (5 types)** — Every KG node carries an `aether:origin` tag. Full classification:

    | Type | How it gets there | Mutable | Example |
    |---|---|---|---|
    | **core** | Original source material at stamp time | Never | Deep research paper content |
    | **acquired** | AEC self-education loop — agent learned from a failure | Prunable if it degrades | Fact the agent didn't know, researched, validated, added |
    | **updated** | Scheduled maintenance sweep — validated against live sources | Replaces stale data | URL checked, source content changed, KG node refreshed |
    | **deprecated** | Manual or automated flag — knowledge no longer valid | Frozen, not deleted | Technology replaced, law changed, person left a role |
    | **provenance** | Citation and source metadata | Updated during maintenance | URL, access date, validation status, source type |

    Node lifecycle: `core → (maintenance) → updated → (source dies) → deprecated` and `core → (AEC gap) → acquired → (maintenance) → updated` and `acquired → (reinforcement score drops) → pruned`

    Implementation: Update `kg.py`'s `add_acquired()` to accept any origin type as a parameter instead of hardcoding "acquired". Add `mark_deprecated()` and `mark_updated()` convenience functions. Each node gets full provenance metadata: origin, timestamp, trigger event, confidence, source reference.

    Future file consideration: agents with systematic updates may split KB into typed files (`{agent}-kb.md` for core, `{agent}-kb-acquired.md` for learned). For v1, the KG handles all zone tracking through node tags. KB stays as one file.

8. **KG maintenance sweeps** — Background process that walks provenance nodes, validates URLs are live, checks if source content has changed. Flags stale knowledge across all agents. Supports: scheduled sweeps, manual override, forced revalidation when a technology is deprecated or similar. Dead URLs flag all connected claim nodes. Changed content triggers AEC re-education. Works against the agent registry KG (item 17) to identify all affected agents from a single source change.

9. **KG consolidation and pruning** — Analogous to human expertise abstracting mental models. Merge redundant nodes, prune low-value edges, simplify graph structure as it grows.

10. **Inter-capsule KG linking** — How do KG nodes from different capsules relate? Shared entity registry? Federated graph? Needed for multi-agent composition.

10.5. **KG storage scaling path** — JSON-LD flat files are validated correct for current scale (60 nodes post-education, <20KB). Tipping points for graph database migration: 500+ nodes per capsule, 3+ hop traversal queries, frequent concurrent writes, pattern search (cycles, shortest paths). When needed, swap implementation behind `kg.py` abstraction (`load_kg`, `query_nodes`, `add_knowledge`) — rest of framework doesn't change. Candidates: Neo4j (index-free adjacency, Cypher), Amazon Neptune (hybrid RDF + property graph), Memgraph (in-memory). RDF-star (RDF 1.2) eliminates the reification problem — our JSON-LD format is forward-compatible. NOT a current concern. Ref: Kimi KG v2 review.

---

## UI & Embodiment

11. **EDS token mapping + DAI pulse** — CSS custom property streaming for real-time UI adaptation. Agent projects its body through CSS variables. Core concept proven in aether-KB-as-body and aether-RD.

11.5. **Reactive Projection System (AETHER UI core concept)** — The agent doesn't have a UI. It radiates one. But critically, it also RECEIVES impulses — Adobe CJA journey events, Adobe Target segment assignments, API webhooks, pheromones from other capsules, user interaction events. Each impulse is absorbed as a context node in the KG, CSS custom properties recalculate, DOM elements transform. The interface is alive because the agent is BREATHING — impulses in, interface out.

    **The cycle:**
    ```
    External impulse (CJA, Target, webhook, pheromone)
      → KG absorbs as context node
        → CSS custom properties recalculate
          → DOM transforms
            → User sees adapted interface
              → User action generates new impulse
                → cycle continues
    ```

    **The AETHER name IS the architecture:**

    | Word | System | Function |
    |---|---|---|
    | Adaptive | DAI Pulse | Receives impulses, state shifts, projection changes |
    | Embodied | EDS Markup | Agent's knowledge IS the DOM, no template layer |
    | Thinking | AEC + Education | Verifies itself, identifies gaps, teaches itself |
    | Holistic | Capsule + Habitat | Complete agent in folder, discoverable, composable |
    | Evolutionary | Stamping + Education | Versions, lineage, knowledge grows through use |
    | Runtime | Pipeline | Distill → Augment → Generate → Review |

    **Enterprise framing:** "Your CJA journey data becomes the agent's nervous system. Your Target segments become its reflexes. The interface you see is the agent responding to your context in real time."

    **Marketing line:** "The agent breathes. Impulses in. Interface out."

12. **NEEDS plugin** — Replace React entirely with EDS HTML output + DAI pulse CSS streams. Proven in POC.

13. **Aura protocol** — 500-byte WebSocket client for UI streaming. Separate project from core framework.

14. **Design system adaptation** — EDS tokens mapping to SAP UI5 theming, React components, native/mobile. One agent DNA drives all render targets.

---

## Communication & Multi-Agent

15. **A2A KG handshake** — Agents communicating via JSON-LD subgraphs rather than text. Proven in POC.

16. **Pheromone routing / stigmergic communication** — Capsules emit and sniff signals through a Habitat registry. Anti-graph principle: capsules never call each other directly. Proven in aether-RD.

17. **Agent registry KG** — A meta-KG listing all capsules, their capabilities, domain boundaries, and provenance dependencies. Enables orchestrator routing and fleet maintenance.

18. **Framework adapters** — LangChain, LangGraph, CrewAI adapters. Built in aether-core. Important for adoption but not core.

---

## Platform Export & Import (NEAR-TERM PRIORITY)

18.5. **Bidirectional agent.md integration** — GitHub now supports `agent.md` files at `.github/agents/` for defining Copilot agent personas. Two directions:

    **Export:** Generate agent.md from an Aether capsule. The capsule already has definition, persona, domain boundaries, and constraints. Formatting these into agent.md is ~30 lines of code. A stamper add-on.

    **Import:** Use an agent.md file AS the KB for stamping an Aether capsule. The agent.md is the seed — same graduation model as skill.md. File → stamp → capsule → AEC improves it → export updated agent.md back to Copilot.

    **Bidirectional flow:**
    `agent.md → stamp into capsule → AEC self-education → export improved agent.md`
    Copilot agent gets smarter through Aether's loop, deploys back as an updated agent.md. User never sees capsule internals.

    **Implementation:** Build a generic export layer, not hardcoded to one platform:
    `export(capsule, format="github-agent-md")`
    Then add formats as needed:
    - `format="github-agent-md"` — GitHub Copilot Desktop
    - `format="claude-skill"` — Anthropic Claude skills
    - `format="openai-assistant"` — OpenAI assistant definitions
    - `format="a2a-agent-card"` — A2A .well-known/agent-card.json

    This is low-effort, high-value. Capsules become deployable to any platform that accepts agent definition files. Jeff is already creating agent.md files for Copilot Desktop and using them as KB inputs — pattern is proven.

---

## Meta-Agent & Self-Assembly

19. **DSL-driven composition** — Logic agent reads composition rules, matches diagnosed failures to brick registry, stamps new capsules. Section 8 of architecture doc.

20. **Autonomous brick creation** — When no existing capsule solves a problem, orchestrator writes new code (Python file), creates it as a feature brick, attaches to existing capsule, restamps.

21. **Brick registry** — Catalog of all available skills, DSL rules, API specs, native functions. Searchable, composable. Future tier.

22. **Version restamping** — Adding a brick to a capsule creates a new version (new folder, new ID). Original untouched. Rollback possible.

22.5. **Claude Code agent pattern integration** — Anthropic's "Learn Claude Code" tutorial describes a 12-session progressive agent build with execution loop, tool dispatch, planning, subagent delegation, context compression, and background threads. This is the execution layer that complements Aether's knowledge layer.

    **Two integration paths:**
    - **Capsule as tool:** An Aether capsule sits inside their tool dispatch map as a knowledge-grounded tool. LLM calls the capsule, capsule returns AEC-verified response. The execution agent gets grounded knowledge without knowing about AEC.
    - **Agent Builder capsule:** Their 12 sessions encoded as a Domain Expert DSL agent. KB is the rule set, KG captures session dependencies (s04 requires s01, s09 requires s07). Proves DSL-based KB format and third agent type.

    **What this proves if built:**
    | Agent | Type | KB Format | AEC Stresses |
    |---|---|---|---|
    | Jefferson | Scholar | Markdown | Dates, names |
    | Buffett | Scholar | Markdown | Numbers, percentages, currency |
    | Validator | Utility | Markdown | Standalone verification |
    | Agent Builder | Domain Expert | DSL rules | Rule references, session dependencies |

---

## Enterprise & Deployment

23. **SAP CAP integration** — Aether capsules pluggable into CAP applications. Needed for the work project sales agent demo.

24. **MCP server** — Capsule capabilities exposed as MCP tools for Claude, Cline, or other AI interfaces.

25. **"Do not re-educate" flag** — Manifest configuration that freezes a capsule's knowledge. For legal documents, regulatory snapshots, historical records.

25.5. **SLM (Small Language Model) hooks** — Route different pipeline stages to different LLM providers via definition.json configuration. Generate uses expensive Claude/GPT. Review and education use cheap local SLMs. Implementation: add `pipeline_providers` config to definition.json and per-stage provider routing in aether.py. The `llm.py` provider pattern already supports this — just add a `"local"` provider that calls an HTTP endpoint (Ollama, vLLM, llama.cpp server). No framework change needed — configuration only. Potential 67% cost reduction on AEC and education operations.

    ```json
    "pipeline_providers": {
        "generate": {"provider": "anthropic", "model": "claude-sonnet-4-20250514"},
        "review": {"provider": "local", "model": "llama-3.1-8b"},
        "educate": {"provider": "local", "model": "deepseek-8b"}
    }
    ```

25.6. **AEC as MCP server** — Expose AEC as a Model Context Protocol server so any MCP-compatible client (Claude Desktop, Cursor, Cline, custom agents) can call it as a "Universal Reliability Port." Three tools: `calibrate_response(response, context, persona)` → score + trigger, `identify_gaps(response, context)` → gap list, `query_graph_truth(entity, predicate)` → verified facts. We already have the CLI version (`aether verify`). MCP wrapper is a thin layer. Ref: Kimi AEC v2 review doc, pages 2-3. **Security requirements (2025 mandatory):** OAuth 2.1 + RFC 8707 Resource Indicators, human-in-the-loop for production, internal registry only (public MCP marketplaces have documented RCE vulnerabilities). Transport: stdio for local, HTTP+SSE for remote (now standardized). Ref: Kimi KG v2 review, MCP security section.

25.7. **AEC competitive positioning — "Deterministic Gate" framing** — Position AEC against industry eval frameworks using this distinction: RAGAS/DeepEval/TruLens are post-hoc probabilistic scoring. AEC is in-pipeline deterministic intervention. It stops errors before the user sees them AND generates the correction plan. Proven competitive matrix:

    | Feature | Standard RAG | RAGAS Eval | AEC (Proven) |
    |---|---|---|---|
    | Timing | Post-hoc | Post-hoc | In-pipeline |
    | Intervention | None | Logging | Self-education |
    | Persona | Ignored | Ignored | Quantified |
    | Numerical Precision | Low | Medium | Deterministic gate + magnitude |
    | Self-Improvement | No | No | 0.143 → 0.889 autonomous |
    | Cost | Baseline | +20% | $0.007/query |
    | Infrastructure | Vector DB required | Vector DB required | Zero — stdlib only |

    Use this framing in: Anthropic letter, scientific paper, README, any publication.

25.8. **Query-type-aware dynamic thresholds** — Instead of fixed 0.8 threshold, adjust per query complexity. Concept from Kimi review. Simple facts: 60%. Multi-hop reasoning: 85%. Numerical/financial: 95%. Temporal: 75%. NOT immediate priority — fixed 80% hasn't been proven wrong yet. The Buffett failure was extraction precision, not threshold calibration. Revisit after extraction skills (item 5.6) are implemented.

26. **Fleet-wide operations** — Re-educate all agents affected by a source change. Upgrade protocols across agents. Driven by the agent registry KG.

---

## Documentation & Publication

27. **Letter to Anthropic** — Draft complete. Needs personal details filled in and final review.

27.5. **Blind testing methodology (REQUIRED BEFORE PUBLICATION)** — Current test results use queries designed by someone who knows the KG contents. This creates favorable selection bias. Before publishing:
    - Random queries from someone unfamiliar with the KG
    - Adversarial queries designed to trick AEC (swapped numbers, wrong dates with right names)
    - 50+ runs for statistical significance, not 3-5
    - Blind evaluation where scorer doesn't know the threshold
    - Cross-domain boundary-crossing queries
    - Report distribution of scores, not cherry-picked highs
    - The education loop results (0.143 → 0.889) are real, but the queries that triggered education were chosen knowing KG contents. A reviewer would flag this.

27.6. **Aether value proposition beyond AEC** — We are over-indexing on AEC in documentation and conversation. AEC is the trust layer, but Aether's full value includes:

    **Capsule portability** — An agent is a folder. Copy it, email it, version it, deploy it anywhere. No server, no database, no runtime dependency. This alone is valuable.

    **Graduation model** — skill.md → stamped capsule → AEC-validated → KG-projected. Complexity increases only when value justifies it. Most agents never need AEC. A skill file is already useful.

    **Ingest pipeline** — One prompt, one LLM output, one command → working agent. The deep research prompt + ingest.py is a product by itself.

    **Stamping and versioning** — Agents have identity, lineage, and rollback. Restamping creates a new version without modifying the original. This is version control for AI capabilities.

    **Habitat routing and gap detection** — Discovery, composition, and identification of missing capabilities. The foundation for self-assembling systems.

    **Knowledge origin classification** — Core, acquired, updated, deprecated, provenance. Full audit trail for how an agent knows what it knows. Enterprise compliance requirement.

    **Persona as a first-class component** — Not an afterthought. The persona defines how the agent communicates, what constraints it follows, and how it interacts with humans and other agents. Persona is configurable, not hardcoded.

    **Domain-agnostic architecture** — Same 5 files, same pipeline, same stamper for historical scholars, financial analysts, technical domain experts, validators, and code-building agents. One framework, any domain.

    **Standalone tools** — 10 components usable independently without adopting the full framework. Each tool is an entry point into the architecture.

    AEC is the headline. The capsule model is the product. Don't let the trust layer overshadow the architecture it protects.

28. **Conceptual piece** — "Agents as code = agents as skills." Paradigm argument for broad audience.

29. **Technical paper** — AEC process, capsule architecture, deterministic validation gates. Rigorous enough for peer review.

30. **Practitioner piece** — How a principal SA at Fortune 50 used this to produce validated deliverables. LinkedIn/Hacker News audience.

31. **Deep research prompt v2** — Complete. Generates all capsule components from a single prompt.

---

## Build Kit & Side Hustle

32. **Vulture Nest** — Trend-based app gap analysis. Automated community research, complaint extraction, application creation.

33. **Automated build kits** — Chrome extension output, mobile app output. Standard design system, legal stamps.

34. **Project agent pattern** — Dump project files into a folder, have Claude Code/Gemini CLI transform into structured knowledge. Project summary prompt proven.

---

## Dashboard & Command Center (NEAR-TERM PRIORITY)

35. **Aether Dashboard** — Single HTML file, no React, no framework. Served via `aether serve` command added to cli.py. SSE for live updates. Same pattern as aether-KB-as-body 17-line kernel. Build AFTER cli.py is done and one real capsule has run end-to-end with a live LLM. Reference: aether-RD/capsules/skill_lab.html (1,454 lines). Components:
    - **Capsule browser** — List all capsules in habitat, show manifest, definition, persona, KG stats, AEC history
    - **KG visualizer** — Interactive D3.js force-directed graph. Nodes colored by entity type. Core vs acquired nodes visually distinct. Click node to inspect properties. Edge labels show predicates.
    - **Pipeline runner** — Type query, select capsule, watch distill → augment → generate → review in real time. Show selected subgraph, built prompt, response, AEC breakdown per statement.
    - **AEC inspector** — Per-run view of every statement tagged GROUNDED/UNGROUNDED/PERSONA. Show matched KG nodes. Show gaps. Primary debugging tool.
    - **Habitat map** — All registered capsules, topic subscriptions, message routing visualization. Highlight gaps (topics with no subscribers).
    - **Test execution** — Run test suites against capsules directly from the dashboard. Show pass/fail, AEC scores, regression tracking.

---

## Capsule Deployment & Portability

36. **Drag-and-drop agents** — A capsule is a folder. Dropping a capsule folder into a habitat directory should be the entire deployment process. No configuration, no wiring, no deployment pipeline. The habitat watches for new folders, reads the manifest, registers topic subscriptions from the definition, and the agent is live. This is the physical proof of "agents as skills instead of code" — you don't install a skill, you don't deploy it, you drop it in and it works. Implementation: file-system watcher in habitat.py (or `aether serve`), auto-registration on folder detection, manifest validation on discovery, immediate availability for routing. Extends to the dashboard (drag a capsule into the UI, see it appear in the habitat map) and to remote deployment (zip a capsule, send it anywhere, unzip, it runs). The capsule carries everything it needs — no external dependencies, no server configuration, no database connection. Copy the folder, the agent exists.

---

## Event Architecture & A2A Protocol

37. **Event catalog** — Comprehensive list of all system-wide events. Categories: pipeline events (distill_complete, augment_complete, generate_complete, review_complete, aec_passed, aec_failed), education events (education_queued, research_started, research_validated, knowledge_integrated), habitat events (capsule_registered, capsule_updated, knowledge_transferred, capability_changed), meta-events (agent_stamped, agent_restamped, lineage_recorded, version_deployed). Each event: name, trigger condition, payload schema, subscribers, example use case.

38. **2K adaptive JS orchestrator** — Locate and document the ~2K-line adaptive JavaScript file that manages React state + routes intent to DAI pipeline. AETHER-aware, React-agnostic. Understands AETHER events only; React pushes final output as messages. Flow: React fires event → orchestrator receives → (optionally) triggers DAI → gets result → emits event → React re-renders. Key architectural decision: orchestrator doesn't care about React internals.

---

## Prompt & Intelligence Management

39. **Prompt versioning and registry system** — Catalog all prompts (deep-research-v3.1 → v3.2 with citation embedding, scholar-specific variants, domain prompts). Version control, fork/contribute pattern, documentation. Prompts as first-class artifacts with provenance. Community contribution model: users fork, customize, rename (e.g., deep-research-financial-v1.0), contribute back.

40. **Ingest post-processing validation layer** — Deterministic checks for malformed JSON-LD, missing fields, orphaned triples. Smart defaults for agent type (Domain Expert → auto-suggest constraints: cite-official-documentation, no-speculation, correct-anti-patterns). Pre-stamp reporting: "9 disconnected triples, 3 empty constraint fields." User approves or cancels before expensive stamping. No LLM cost — structural validation only.

41. **Blind testing protocol** — Use secondary LLM (different provider/model) with adversarial prompt ("Your job is to find weaknesses in this agent. Generate 50 challenging queries designed to break it.") to generate test queries. Primary agent answers. AEC scores the responses. Results must exceed threshold before public release. Removes human bias entirely — LLM doesn't know the KG, incentivized to attack, not validate.

42. **Pluggable education queue backends** — Abstract queue interface so education-queue.json (local file) and external queues (Kafka, Redis) are interchangeable. Capsules don't care which backend is configured.

43. **Stamp policy configuration** — Add `stamp_policy` field to manifest: autonomous (auto-restamp when education completes), manual (queue notification, wait for human approval), hybrid (auto-restamp patches v1.0.1, manual for minor/major v1.1.0/v2.0.0). Dashboard approval workflow for human-gated restamps.

---

## Session Persistence & Recovery

44. **Session versioning and web session patterns** — Document how AETHER capsule versioning integrates with standard web session patterns (session isolation, background updates, graceful upgrade paths). Define orchestrator's role in version routing. Follow industry standards for session management — don't reinvent. AETHER's advantage: adapt faster because agent logic lives in files, not code.

---

## Autonomous Application Framework & Products

45. **Autonomous application framework** — Telegraph-based event system, orchestrator decision logic, unified build kit, integration with AETHER capsules. Enable "text command → full application" workflow for rapid idea capture and execution. Claude API as orchestrator, Claude Code for specialized tasks, Telegraph for notifications. Rebuild in AETHER: capsules replace Claude API/Code/Telegraph roles, habitat becomes orchestrator, event system becomes A2A protocol + pub/sub.

46. **Phase 1 MVP capsule suite** — At least one example of each agent type for internal demo: Scholar (Jefferson ✓, Buffett ✓), Domain Expert (SAP CAP ✓ — needs quality fix with v3.2 prompt), Validator (aether-validator ✓ — expand use cases), Process Agent (new — orchestrate multi-step workflow), UI-aware agent (new — adapts persona based on user feedback). Pick 3-4 for Phase 1 launch.

---

## Testing & QA Automation

47. **Auto-generated unit test agents** — Puppeteer + screen recording + self-aware capsule markup. Record user behavior (happy path, edge cases, error states). Puppeteer replays recording. AETHER agents know their own markup and design system, subscribe to events, validate state changes. Test agent gets stamped as capsule and disseminated across QA/production. Automated testing as agents, not scripts. Three-layer stack: AEC (knowledge validation) + Blind Testing (adversarial coverage) + Puppeteer (UI/UX validation).

48. **DSL-to-AETHER-agent translator** — Convert Selenium/Cypress/test DSLs into QA agent knowledge bases. DSL logic file becomes KB for AETHER QA agent. Standalone microSaaS for companies with existing test infrastructure. Two markets: native AETHER QA agents (auto-generated from recordings) and DSL-to-Agent translators (for existing test suites).

---

## Composability & Modularity

49. **Input → Process → Output contract** — Every capsule must be I/O agnostic. Same capsule works as: standalone (user query → response), service (API call → API response), MCP server (MCP request → MCP response), feature brick (data pipeline in → data pipeline out). Core pipeline (distill → augment → generate → review) never changes; only the I/O adapter changes. Design every capsule as if it will be wrapped in multiple contexts. Don't hardcode UI assumptions, don't assume synchronous execution, don't lock in single I/O protocol.

---

## UI Architecture & Edge Personalization

50. **DAI Pulse integration** — 4-node state machine (reflex → deliberation → complete → ghost). Reflex path fires CSS stream bursts in sub-10ms, under 1KB payload. Already exists in prior codebase. Needs to be mapped into current minimal AETHER core or documented as integration layer. DAI Pulse is how the CSS stream "bursts" fire — it's the heartbeat mechanism.

51. **CSS Stream + Adobe EDS integration** — CSS Stream exists in code, sourced from global design system. Use Adobe EDS (Edge Delivery Services) blocks, dismantled into simplified markup that AETHER agents project through. EDS tokens (CSS variables, semantic classes) are the render-target-agnostic design layer. One agent DNA → UI5, React, mobile, terminal. Design system swap = token remap, not component rebuild.

52. **Edge personalization without Adobe Target** — AETHER agents replace Adobe Target for real-time personalization. Agent sits on edge, receives CJA/Alloy.js behavioral signals directly, runs DAI Pulse, fires CSS stream bursts, adapts experience in real-time. No server-side decisioning round-trip. No audience sync delays. Agent IS the personalization engine — handles both intelligence (KG-grounded) and UI (CSS burst) adjustments. Jump ahead of Adobe EDS publishing, go directly to edge execution.

53. **Behavioral signal ingestion** — Adobe CJA (Customer Journey Analytics), Alloy.js (Adobe Web SDK), and Adobe Experience ecosystem as primary signal sources. Also Google Analytics, Segmenta impulses, user behavioral events. All channels normalize to DAI pulse intent events. Agent reacts to journey stage, device context, behavioral velocity, environmental cues without explicit user queries. Ambient intelligence layer.

---

## Feature Brick Registry & Meta-Agent Composition (FUTURE STATE)

54. **Feature brick registry** — Formalized catalog of composable function bricks. Each brick: id, source_type (skill_md, dsl, api, native), source_path, KG snapshot, I/O schema, dependencies. Feature bricks = microSaaS (sellable individually or bundled). An AETHER capsule is built FROM feature bricks. Registry enables: (a) matrix — A2A communication between brick-capsules, (b) morph — combine multiple bricks into new stamped agent with merged capabilities. Brick dependency resolution via topological sort. DSL composition rules determine which bricks combine for specific problem signatures. AEC evolves from validation ("did this agent hallucinate?") to generative architecture ("what agent should exist?"). Agent breeding, not just agent building.

55. **GHOST state protocol** — When AEC fails below threshold, agent returns `[GHOST] Unable to verify answer` with confidence 0.0. Don't guess. Don't hallucinate. Ghost. This is the "don't guess" principle enforced at the protocol level. Verify GHOST is implemented in current aec.py or add it.

---

*Items are numbered for reference. Priority and sequencing TBD after core build is complete.*
