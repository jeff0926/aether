# AEC Concept Layer 1 — Compiled Deterministic Matching (v2)
## Build Spec for Claude Code Agent

**What:** Add concept-level statement matching to AEC using COMPILED token patterns from KG node labels. The KG compiles into detector functions at load time. Runtime matching is set intersection, not similarity computation.
**Where:** New file `aec_concept.py` in project root. Integrated into `aec.py` review flow.
**Constraint:** Python stdlib only. No new dependencies. Same score format: `grounded / (grounded + ungrounded)`.

**Key architectural principle (from cross-LLM research):** Don't match text against nodes at runtime. Compile nodes into detectors at load time. `O(statements)` execution, not `O(statements × nodes)` comparison. The KG becomes a program, not a database.

---

## Context

Read these files first:
- `aec.py` — Current AEC implementation (deterministic gate, verify function, split_statements, _extract_values)
- `kg.py` — KG loading, node access, stats
- Reference KG: `examples/frontend-design-v1.0.0-ff6ab491/frontend-design-v1.0.0-ff6ab491-kg.jsonld` (73 nodes, typed)

**The problem:** AEC extracts numbers/dates/names, matches against KG properties. Works for factual agents. Fails for skill agents because skill KGs contain Rules, Techniques, AntiPatterns — none of which are numbers or dates. Statements like "Use CSS variables for consistency" classify as Persona and get skipped.

**The fix:** Compile KG node labels into token pattern sets at capsule load. Before classifying a statement as Persona, run set intersection against compiled patterns. Fast, deterministic, no LLM.

---

## New File: `aec_concept.py`

~200-250 lines. Contains:

### Constants

```python
import re
from collections import Counter

STOPWORDS = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
             'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
             'it', 'its', 'this', 'that', 'these', 'those', 'not', 'no', 'do', 'does',
             'did', 'has', 'have', 'had', 'will', 'would', 'could', 'should', 'may',
             'can', 'if', 'then', 'than', 'so', 'as', 'from', 'into', 'up', 'out',
             'about', 'over', 'such', 'each', 'every', 'all', 'any', 'both', 'few',
             'more', 'most', 'other', 'some', 'very', 'just', 'also', 'like', 'use',
             'using', 'used'}
```

### 1. `tokenize(text: str) -> set`

Standard tokenizer used everywhere. Consistent.

```python
def tokenize(text: str) -> set:
    """Extract content words as lowercase set, minus stopwords."""
    return set(re.findall(r'\b\w+\b', text.lower())) - STOPWORDS
```

### 2. `dice_bigram(s1: str, s2: str) -> float`

Secondary similarity check for ambiguous cases only. Not the primary matching method.

```python
def dice_bigram(s1: str, s2: str) -> float:
    """Sørensen-Dice coefficient using word bigrams. Secondary check."""
    def bigrams(text):
        words = re.findall(r'\b\w+\b', text.lower())
        if len(words) < 2:
            return Counter()
        return Counter(f"{words[i]} {words[i+1]}" for i in range(len(words) - 1))
    bg1, bg2 = bigrams(s1), bigrams(s2)
    intersection = sum((bg1 & bg2).values())
    total = sum(bg1.values()) + sum(bg2.values())
    return (2 * intersection) / total if total > 0 else 0.0
```

### 3. `compile_kg(kg_nodes: list) -> dict`

**THE CORE FUNCTION.** Compiles the entire KG into executable detector structures at load time. Called ONCE when capsule loads.

```python
# Type-specific configuration
TYPE_CONFIG = {
    'rules':        {'match_threshold': 0.50, 'weight': 1.0},
    'techniques':   {'match_threshold': 0.55, 'weight': 1.0},
    'antipatterns': {'match_threshold': 0.40, 'weight': 1.0},
    'concepts':     {'match_threshold': 0.30, 'weight': 0.5},
    'tools':        {'match_threshold': 0.60, 'weight': 0.3},
    'traits':       {'match_threshold': 0.70, 'weight': 0.2},
}

def compile_kg(kg_nodes: list) -> dict:
    """
    Compile KG into executable detector structures.
    Called ONCE at capsule load. All runtime matching uses the compiled output.
    
    Returns:
        {
            'detectors': [
                {
                    'node_id': str,
                    'label': str,
                    'node_type': str,       # 'rules', 'techniques', etc.
                    'patterns': set,         # compiled token set from label
                    'pattern_count': int,    # how many content tokens
                    'threshold': float,      # match threshold for this type
                    'weight': float,         # scoring weight for this type
                    'node': dict,            # original node for reference
                },
                ...
            ],
            'blacklist': set,               # compiled anti-pattern forbidden tokens
            'blacklist_map': dict,          # token → node_id mapping for violation attribution
        }
    """
    detectors = []
    blacklist = set()
    blacklist_map = {}  # token → {'node_id': ..., 'label': ...}
    
    for node in kg_nodes:
        ntype = node.get('@type', '')
        label = node.get('rdfs:label', '')
        node_id = node.get('@id', '')
        if not label or not node_id:
            continue
        
        # Classify node type
        if 'Rule' in ntype:
            node_type = 'rules'
        elif 'AntiPattern' in ntype:
            node_type = 'antipatterns'
        elif 'Technique' in ntype:
            node_type = 'techniques'
        elif 'Concept' in ntype:
            node_type = 'concepts'
        elif 'Tool' in ntype:
            node_type = 'tools'
        elif 'Trait' in ntype:
            node_type = 'traits'
        else:
            continue
        
        config = TYPE_CONFIG.get(node_type, {'match_threshold': 0.5, 'weight': 0.5})
        
        # COMPILE: Extract content tokens from label
        patterns = tokenize(label)
        
        detectors.append({
            'node_id': node_id,
            'label': label,
            'node_type': node_type,
            'patterns': patterns,
            'pattern_count': len(patterns),
            'threshold': config['match_threshold'],
            'weight': config['weight'],
            'node': node,
        })
        
        # COMPILE: Anti-pattern blacklist
        if node_type == 'antipatterns':
            # Extract specific terms from parentheses: "Overused fonts (Inter, Roboto)" → {inter, roboto}
            paren_terms = re.findall(r'\(([^)]+)\)', label)
            for match in paren_terms:
                for term in re.split(r'[,/]', match):
                    term = term.strip().lower()
                    if len(term) > 2:
                        blacklist.add(term)
                        blacklist_map[term] = {'node_id': node_id, 'label': label}
            # Also add significant words from label
            for word in patterns:
                if len(word) > 3:
                    blacklist.add(word)
                    if word not in blacklist_map:
                        blacklist_map[word] = {'node_id': node_id, 'label': label}
    
    return {
        'detectors': detectors,
        'blacklist': blacklist,
        'blacklist_map': blacklist_map,
    }
```

### 4. `check_violation(stmt_tokens: set, compiled: dict) -> dict | None`

Fast anti-pattern check. Set intersection against pre-compiled blacklist.

```python
def check_violation(stmt_tokens: set, compiled: dict) -> dict | None:
    """Check if statement tokens hit the anti-pattern blacklist. O(1) per token."""
    hits = stmt_tokens & compiled['blacklist']
    if not hits:
        return None
    
    # Find best matching anti-pattern node
    node_scores = {}
    for hit in hits:
        mapped = compiled['blacklist_map'].get(hit)
        if mapped:
            nid = mapped['node_id']
            node_scores[nid] = node_scores.get(nid, 0) + 1
    
    if not node_scores:
        return None
    
    best_id = max(node_scores, key=node_scores.get)
    best_node = compiled['blacklist_map'].get(list(hits)[0], {})
    
    return {
        'node_id': best_id,
        'label': best_node.get('label', ''),
        'hits': list(hits),
        'type': 'antipattern_violation',
    }
```

### 5. `match_statement(stmt_tokens: set, statement: str, compiled: dict) -> dict`

**The main runtime function.** Primary: set intersection. Secondary: Dice for ambiguous range.

```python
def match_statement(stmt_tokens: set, statement: str, compiled: dict) -> dict:
    """
    Match a single statement against compiled KG detectors.
    
    Primary: set intersection (O(1) per detector)
    Secondary: Dice bigram (only when set overlap is in ambiguous range)
    
    Returns:
        {
            'category': 'concept_grounded' | 'antipattern_violation' | 'concept_persona',
            'matches': [...],
            'violation': {...} or None,
            'ambiguous': [...]  # candidates for Layer 2 LLM check
        }
    """
    # Step 1: Anti-pattern violation check (highest priority, fastest)
    violation = check_violation(stmt_tokens, compiled)
    if violation:
        return {
            'category': 'antipattern_violation',
            'matches': [],
            'violation': violation,
            'ambiguous': [],
        }
    
    # Step 2: Run compiled detectors via set intersection
    matches = []
    ambiguous = []
    
    for detector in compiled['detectors']:
        if detector['pattern_count'] == 0:
            continue
        
        # PRIMARY: Set intersection
        overlap = stmt_tokens & detector['patterns']
        coverage = len(overlap) / detector['pattern_count']
        
        if coverage >= detector['threshold']:
            # High confidence match
            matches.append({
                'node_id': detector['node_id'],
                'label': detector['label'],
                'node_type': detector['node_type'],
                'coverage': round(coverage, 3),
                'overlap_tokens': list(overlap),
                'weight': detector['weight'],
                'method': 'compiled_pattern',
            })
        elif coverage >= detector['threshold'] * 0.5:
            # Ambiguous range — secondary Dice check
            dice = dice_bigram(statement, detector['label'])
            if dice >= 0.3:
                ambiguous.append({
                    'node_id': detector['node_id'],
                    'label': detector['label'],
                    'node_type': detector['node_type'],
                    'coverage': round(coverage, 3),
                    'dice': round(dice, 3),
                    'weight': detector['weight'],
                    'node': detector['node'],
                    'method': 'dice_ambiguous',
                })
    
    # Step 3: Determine category
    if matches:
        strong = [m for m in matches if m['weight'] >= 0.5]
        if strong:
            return {
                'category': 'concept_grounded',
                'matches': sorted(matches, key=lambda m: m['coverage'], reverse=True),
                'violation': None,
                'ambiguous': ambiguous,
            }
    
    return {
        'category': 'concept_persona',
        'matches': matches,
        'violation': None,
        'ambiguous': sorted(ambiguous, key=lambda a: a.get('dice', 0), reverse=True)[:3],
    }
```

### 6. `concept_verify(response_text: str, kg_nodes: list, compiled: dict = None) -> dict`

Top-level function. Accepts pre-compiled KG or compiles on the fly.

```python
from aec import split_statements

def concept_verify(response_text: str, kg_nodes: list, compiled: dict = None) -> dict:
    """
    Run concept-level AEC on a response.
    
    If compiled dict is provided (from capsule load), uses it directly.
    Otherwise compiles on the fly (for standalone verify).
    """
    if compiled is None:
        compiled = compile_kg(kg_nodes)
    
    statements = split_statements(response_text)
    
    grounded = 0
    ungrounded = 0
    persona = 0
    details = []
    gaps = []
    
    for stmt in statements:
        stmt_tokens = tokenize(stmt)
        result = match_statement(stmt_tokens, stmt, compiled)
        
        if result['category'] == 'concept_grounded':
            grounded += 1
            top = result['matches'][0]
            details.append({
                'statement': stmt,
                'category': 'grounded',
                'method': f"concept:{top['node_type']}",
                'matched_node': top['node_id'],
                'matched_label': top['label'],
                'coverage': top['coverage'],
                'overlap_tokens': top['overlap_tokens'],
            })
        elif result['category'] == 'antipattern_violation':
            ungrounded += 1
            v = result['violation']
            details.append({
                'statement': stmt,
                'category': 'ungrounded',
                'method': 'antipattern_violation',
                'matched_node': v['node_id'],
                'matched_label': v['label'],
                'violation_terms': v['hits'],
            })
            gaps.append({
                'text': f"VIOLATION: '{', '.join(v['hits'])}' matches antipattern '{v['label']}'",
                'node_id': v['node_id'],
            })
        else:
            persona += 1
            details.append({
                'statement': stmt,
                'category': 'persona',
                'method': 'no_concept_match',
                'ambiguous_candidates': [
                    {'node_id': a['node_id'], 'dice': a.get('dice', 0)} 
                    for a in result.get('ambiguous', [])
                ],
            })
    
    total = grounded + ungrounded
    score = grounded / total if total > 0 else 1.0
    
    return {
        'score': round(score, 4),
        'grounded_statements': grounded,
        'ungrounded_statements': ungrounded,
        'persona_statements': persona,
        'total_statements': grounded + ungrounded + persona,
        'details': details,
        'gaps': gaps,
        'method': 'concept_compiled',
    }
```

---

## Integration into `aec.py`

Modify `verify()` to call concept matching when factual AEC classifies too many statements as Persona.

```python
# In verify() after standard AEC processing:

has_typed_nodes = any(
    node.get('@type', '') and any(t in node.get('@type', '') 
    for t in ('Rule', 'AntiPattern', 'Technique', 'Concept', 'Tool'))
    for node in kg_nodes
)

factual_persona_ratio = persona_count / total_statements if total_statements > 0 else 0

if has_typed_nodes and factual_persona_ratio > 0.6:
    from aec_concept import concept_verify, compile_kg
    compiled = compile_kg(kg_nodes)  # Compile once
    concept_result = concept_verify(response_text, kg_nodes, compiled)
    
    # Merge: factual AEC results for statements it classified as Grounded/Ungrounded
    # Concept results for statements factual AEC called Persona
    result = merge_factual_and_concept(factual_result, concept_result)
```

**The `merge_factual_and_concept()` function:**
- Statements factual AEC classified as Grounded/Ungrounded → keep (deterministic gate is final on facts)
- Statements factual AEC classified as Persona → use concept classification
- Recalculate score from merged counts

---

## Capsule Load Optimization

In `aether.py` Capsule class, compile the KG at load time:

```python
class Capsule:
    def __init__(self, path, llm_fn=None):
        # ... existing init ...
        
        # Compile KG for concept AEC (only if KG has typed nodes)
        from aec_concept import compile_kg
        from kg import load_kg, get_nodes
        kg = load_kg(self.files['kg_path'])
        nodes = get_nodes(kg)
        self._compiled_kg = compile_kg(nodes) if self._has_typed_nodes(nodes) else None
    
    def _has_typed_nodes(self, nodes):
        return any(
            node.get('@type', '') and any(t in node.get('@type', '') 
            for t in ('Rule', 'AntiPattern', 'Technique', 'Concept', 'Tool'))
            for node in nodes
        )
```

Then pass `self._compiled_kg` through to the review stage. KG compiles once at load, all queries use the compiled version.

---

## Test Cases

### Test 1: Compiled Pattern Match — Rule
```bash
python cli.py verify "Use CSS variables for consistency" -r examples/frontend-design-v1.0.0-ff6ab491/frontend-design-v1.0.0-ff6ab491-kg.jsonld
```
Expected: **Grounded** — compiled patterns from `rule:use_css_variables` match via set intersection

### Test 2: Compiled Pattern Match — Technique
```bash
python cli.py verify "Implement staggered reveals using animation-delay" -r examples/frontend-design-v1.0.0-ff6ab491/frontend-design-v1.0.0-ff6ab491-kg.jsonld
```
Expected: **Grounded** — compiled patterns from `technique:staggered_reveals` match

### Test 3: Anti-Pattern Blacklist Violation
```bash
python cli.py verify "Use Inter for the body text" -r examples/frontend-design-v1.0.0-ff6ab491/frontend-design-v1.0.0-ff6ab491-kg.jsonld
```
Expected: **Ungrounded** — "inter" hits compiled blacklist from `antipattern:inter_roboto_arial`

### Test 4: Pure Persona
```bash
python cli.py verify "Your typography should feel handcrafted" -r examples/frontend-design-v1.0.0-ff6ab491/frontend-design-v1.0.0-ff6ab491-kg.jsonld
```
Expected: **Persona** — no pattern match, no violation

### Test 5: Full Pipeline with Compiled KG
```bash
python cli.py run examples/frontend-design-v1.0.0-ff6ab491 "How should I approach typography for a luxury brand landing page?" --provider anthropic --report full
```
Expected: Mixed grounded/persona with meaningful scores, not "all persona" like before

### Test 6: Scholar Agent Unchanged
```bash
python cli.py run examples/jefferson "When was Jefferson born?" --provider anthropic --report full
```
Expected: Identical to before. Concept matching doesn't activate (persona ratio low).

### Test 7: Compilation Performance
```python
import time
from aec_concept import compile_kg
from kg import load_kg, get_nodes
kg = load_kg('examples/frontend-design-v1.0.0-ff6ab491/frontend-design-v1.0.0-ff6ab491-kg.jsonld')
nodes = get_nodes(kg)
start = time.time()
compiled = compile_kg(nodes)
print(f"Compile time: {(time.time()-start)*1000:.2f}ms")
print(f"Detectors: {len(compiled['detectors'])}")
print(f"Blacklist tokens: {len(compiled['blacklist'])}")
```
Expected: <2ms compile time, 73 detectors, ~15-20 blacklist tokens

---

## Quality Checks

1. `aec_concept.py` has zero external dependencies (stdlib only)
2. `compile_kg()` runs once per capsule load, not per query
3. Runtime matching is set intersection, not Dice computation (Dice is secondary only)
4. Existing `verify()` behavior unchanged for scholar agents
5. Concept matching activates only when persona_ratio > 0.6 AND KG has typed nodes
6. Anti-pattern violations are deterministic (no LLM)
7. Details include overlap_tokens for explainability
8. Ambiguous candidates (Dice 0.3-0.7) are tagged for Layer 2 LLM checking
9. All existing tests still pass
10. Report output shows concept matches with node IDs, labels, and method
