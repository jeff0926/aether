# AEC Concept Layer 3 — Compiled Edge Policy Traversal (v2)
## Build Spec for Claude Code Agent

**What:** Compile KG edges into composed policy checker functions at load time. Runtime traversal is function execution, not graph querying.
**Where:** Extend `aec_concept.py` with compiled edge policies.
**Depends on:** Layers 1 and 2 must be working first.
**Constraint:** Python stdlib only. 1-hop traversal only in v1. Three edge types only.

**Key principle:** Just like Layer 1 compiles nodes into pattern detectors, Layer 3 compiles edges into policy functions. `concept:typography → avoids → antipattern:inter_roboto_arial` becomes a single callable that checks: "Is this about typography? If yes, does it contain Inter/Roboto/Arial?"

---

## Context

Layer 1 answers: "Does this statement mention something in the KG?" (compiled pattern match)
Layer 2 answers: "Does this statement comply with a specific node?" (type-driven LLM check)
Layer 3 answers: "Does this statement violate a COMPOSED POLICY spanning connected nodes?" (compiled edge execution)

---

## Three Edge Types (v1)

| Edge | Meaning | Compiled Policy Logic |
|------|---------|----------------------|
| `skill:avoids` | Source forbids target | `if source_patterns ∩ tokens AND target_blacklist ∩ tokens → VIOLATION` |
| `skill:requires` | Source depends on target | Log if source matched but target absent from full response (informational v1) |
| `skill:contradicts` | Mutually exclusive | `if source_patterns ∩ tokens AND target_patterns ∩ tokens → CONTRADICTION` |

---

## Extend `compile_kg()` 

Add edge policy compilation to the existing `compile_kg()` function from Layer 1. 

**Add to the return dict:**

```python
def compile_kg(kg_nodes: list) -> dict:
    """
    Extended: Also compiles edge policies into executable checkers.
    """
    # ... existing detector and blacklist compilation from Layer 1 ...
    
    # BUILD: Node lookup for edge resolution
    node_lookup = {node.get('@id', ''): node for node in kg_nodes if node.get('@id')}
    
    # BUILD: Compiled edge policies
    edge_policies = []
    
    EDGE_PREDICATES = {
        'skill:avoids': 'avoids',
        'skill:requires': 'requires',
        'skill:contradicts': 'contradicts',
    }
    
    for node in kg_nodes:
        source_id = node.get('@id', '')
        source_label = node.get('rdfs:label', '')
        source_patterns = tokenize(source_label)
        
        if not source_id or not source_patterns:
            continue
        
        for prop_key, edge_type in EDGE_PREDICATES.items():
            targets = node.get(prop_key)
            if not targets:
                continue
            if isinstance(targets, str):
                targets = [targets]
            
            for target_id in targets:
                if not isinstance(target_id, str):
                    continue
                target_node = node_lookup.get(target_id)
                if not target_node:
                    continue
                
                target_label = target_node.get('rdfs:label', '')
                target_patterns = tokenize(target_label)
                
                # Extract blacklist tokens from target (for avoids edges)
                target_blacklist = set()
                if edge_type == 'avoids':
                    paren_terms = re.findall(r'\(([^)]+)\)', target_label)
                    for match in paren_terms:
                        for term in re.split(r'[,/]', match):
                            term = term.strip().lower()
                            if len(term) > 2:
                                target_blacklist.add(term)
                    target_blacklist |= {w for w in target_patterns if len(w) > 3}
                
                edge_policies.append({
                    'source_id': source_id,
                    'source_label': source_label,
                    'source_patterns': source_patterns,
                    'target_id': target_id,
                    'target_label': target_label,
                    'target_patterns': target_patterns,
                    'target_blacklist': target_blacklist,
                    'edge_type': edge_type,
                })
    
    return {
        'detectors': detectors,           # from Layer 1
        'blacklist': blacklist,            # from Layer 1
        'blacklist_map': blacklist_map,    # from Layer 1
        'edge_policies': edge_policies,    # NEW: Layer 3
        'node_lookup': node_lookup,        # NEW: Layer 3
    }
```

---

## `execute_edge_policies(stmt_tokens: set, matched_node_ids: list, compiled: dict) -> list`

**The core runtime function.** Executes compiled edge policies. No graph querying — just iterates pre-compiled policy structs.

```python
def execute_edge_policies(stmt_tokens: set, matched_node_ids: list, compiled: dict) -> list:
    """
    Execute compiled edge policies for matched nodes.
    
    For each edge policy where the source node was matched by Layer 1/2:
      - avoids: check if statement also contains target's forbidden tokens → VIOLATION
      - contradicts: check if statement also matches target patterns → CONTRADICTION
      - requires: log if target is absent (informational in v1)
    
    Returns: List of violation dicts
    """
    violations = []
    matched_set = set(matched_node_ids)
    
    for policy in compiled['edge_policies']:
        # Only fire policies where source node was matched by Layer 1/2
        if policy['source_id'] not in matched_set:
            continue
        
        if policy['edge_type'] == 'avoids':
            # Check if statement contains target's forbidden tokens
            hits = stmt_tokens & policy['target_blacklist']
            if hits:
                violations.append({
                    'type': 'edge_avoids_violation',
                    'source': policy['source_id'],
                    'source_label': policy['source_label'],
                    'target': policy['target_id'],
                    'target_label': policy['target_label'],
                    'path': f"{policy['source_id']} --avoids--> {policy['target_id']}",
                    'evidence': list(hits),
                    'severity': 'high',
                    'explanation': (
                        f"Statement addresses '{policy['source_label']}' "
                        f"but contains '{', '.join(hits)}' which is avoided per "
                        f"'{policy['target_label']}'"
                    ),
                })
        
        elif policy['edge_type'] == 'contradicts':
            # Check if statement matches BOTH source and target
            target_overlap = stmt_tokens & policy['target_patterns']
            coverage = len(target_overlap) / len(policy['target_patterns']) if policy['target_patterns'] else 0
            if coverage > 0.4:
                violations.append({
                    'type': 'edge_contradicts_violation',
                    'source': policy['source_id'],
                    'source_label': policy['source_label'],
                    'target': policy['target_id'],
                    'target_label': policy['target_label'],
                    'path': f"{policy['source_id']} --contradicts--> {policy['target_id']}",
                    'evidence': list(target_overlap),
                    'severity': 'medium',
                    'explanation': (
                        f"Statement matches '{policy['source_label']}' "
                        f"which contradicts '{policy['target_label']}'"
                    ),
                })
        
        elif policy['edge_type'] == 'requires':
            # Informational only in v1 — log but don't score
            # Future: check if target technique/rule is present in full response
            pass
    
    return violations
```

---

## Integration into `concept_verify()`

Update `concept_verify()` to execute edge policies after Layer 1/2 matching:

```python
def concept_verify(response_text: str, kg_nodes: list, compiled: dict = None, llm_fn=None) -> dict:
    """Full concept-level AEC with all three layers."""
    if compiled is None:
        compiled = compile_kg(kg_nodes)
    
    statements = split_statements(response_text)
    
    grounded = 0
    ungrounded = 0
    persona = 0
    details = []
    gaps = []
    edge_violations = []
    
    for stmt in statements:
        stmt_tokens = tokenize(stmt)
        
        # Layer 1: Compiled pattern matching
        result = match_statement(stmt_tokens, stmt, compiled)
        
        # Layer 3: Execute compiled edge policies on matched nodes
        matched_ids = [m['node_id'] for m in result.get('matches', [])]
        if matched_ids and compiled.get('edge_policies'):
            e_violations = execute_edge_policies(stmt_tokens, matched_ids, compiled)
            if e_violations:
                edge_violations.extend(e_violations)
                ungrounded += 1
                top_v = e_violations[0]
                details.append({
                    'statement': stmt,
                    'category': 'ungrounded',
                    'method': f"edge:{top_v['type']}",
                    'path': top_v['path'],
                    'evidence': top_v['evidence'],
                    'explanation': top_v['explanation'],
                    'severity': top_v['severity'],
                })
                gaps.append({
                    'text': top_v['explanation'],
                    'node_id': top_v['target'],
                    'violation_type': top_v['type'],
                })
                continue  # Edge violation overrides — don't double-count
        
        # Layer 2: Type-driven LLM check (for ambiguous/persona results)
        # Only if llm_fn provided and result has ambiguous candidates
        if result['category'] == 'concept_persona' and llm_fn and result.get('ambiguous'):
            # Layer 2 logic from Layer 2 spec
            # ... type_driven_check() ...
            pass
        
        # Standard Layer 1 classification
        if result['category'] == 'concept_grounded':
            grounded += 1
            top = result['matches'][0]
            details.append({
                'statement': stmt,
                'category': 'grounded',
                'method': f"concept:{top['node_type']}",
                'matched_node': top['node_id'],
                'matched_label': top['label'],
                'coverage': top['coverage'],
            })
        elif result['category'] == 'antipattern_violation':
            ungrounded += 1
            v = result['violation']
            details.append({
                'statement': stmt,
                'category': 'ungrounded',
                'method': 'antipattern_blacklist',
                'matched_node': v['node_id'],
                'matched_label': v['label'],
                'violation_terms': v['hits'],
            })
            gaps.append({
                'text': f"VIOLATION: '{', '.join(v['hits'])}' matches antipattern '{v['label']}'",
                'node_id': v['node_id'],
            })
        else:
            persona += 1
            details.append({
                'statement': stmt,
                'category': 'persona',
                'method': 'no_concept_match',
            })
    
    total = grounded + ungrounded
    score = grounded / total if total > 0 else 1.0
    
    return {
        'score': round(score, 4),
        'grounded_statements': grounded,
        'ungrounded_statements': ungrounded,
        'persona_statements': persona,
        'total_statements': grounded + ungrounded + persona,
        'details': details,
        'gaps': gaps,
        'edge_violations': edge_violations,
        'method': 'concept_3layer_compiled',
    }
```

---

## Report Enhancement

Add edge violation section to ASCII report:

```
╔═══ EDGE POLICY VIOLATIONS ════════════════════════════════════════════════╗
│  concept:typography --avoids--> antipattern:inter_roboto_arial            │
│  Evidence: "inter" found in statement                                     │
│  Severity: HIGH                                                           │
│  Explanation: Statement addresses 'Typography' but contains 'inter'      │
│               which is avoided per 'Overused fonts (Inter, Roboto...)'   │
╚════════════════════════════════════════════════════════════════════════════╝
```

---

## Test Cases

### Test 8: Compiled Edge Violation
"For typography, I recommend using the clean Inter font"
KG: `concept:typography → skill:avoids → antipattern:inter_roboto_arial`
Layer 1 matches `concept:typography` via patterns. Layer 3 fires avoids policy, finds "inter" in blacklist.
Expected: **Ungrounded** via edge policy, explanation shows full path.

### Test 9: Compiled Edge — No Violation
"For typography, I recommend Playfair Display"
Same edge exists but "Playfair" not in target blacklist.
Expected: **Grounded** (concept match, edge policy fires but no hit)

### Test 10: Contradicts Edge
"Use predictable grid layouts for consistency"
KG: `rule:break_conventional_patterns → skill:contradicts → antipattern:cookie_cutter_design`
Expected: **Ungrounded** via contradicts policy

### Test 11: Multi-Violation Response
"Build me a landing page with Inter font and purple gradients on white background"
Expected: Multiple violations from both blacklist AND edge policies. Low score.

### Test 12: Scholar Agent Unchanged
Jefferson queries produce identical results. No edge policies in factual KGs.

### Test 13: Compilation Performance
```python
compiled = compile_kg(nodes)
print(f"Edge policies compiled: {len(compiled['edge_policies'])}")
```
Expected: 10-20 policies for 73-node KG, <1ms compile time

---

## Performance Budget

- `compile_kg()` edge compilation: <1ms additional (runs once at load)
- `execute_edge_policies()` per statement: <0.5ms (iterate list, set intersection)
- Total Layer 3 for 6 statements: <3ms
- Zero LLM calls — entirely deterministic
- Combined Layers 1+3: <5ms total

---

## Quality Checks

1. Edge policies compile at load time alongside node detectors — one `compile_kg()` call does both
2. Only three edge types: `avoids`, `requires`, `contradicts`
3. `requires` is informational only (logged, not scored in v1)
4. Edge violations override Layer 1 grounded classification
5. Scholar agents unaffected (no typed edges)
6. Explanations include full path and evidence tokens
7. All Layer 1 and Layer 2 tests still pass
8. Performance stays under 5ms for Layers 1+3 combined
