# AEC Concept Layer 2 — Type-Driven Verification
## Build Spec for Claude Code Agent

**What:** Add type-specific verification logic where the KG node's `@type` determines HOW to verify a statement against it.
**Where:** Extend `aec_concept.py` with type operators. Modify LLM integration.
**Depends on:** Layer 1 must be working first.
**Constraint:** Python stdlib + existing `llm.py`. No new dependencies.

---

## Context

Layer 1 answers: "Does this statement mention something in the KG?" (lexical matching)
Layer 2 answers: "Does this statement COMPLY WITH what the KG node says?" (type-driven logic)

The difference:
- Layer 1: "Use Playfair Display" matches nothing (no node with that label) → Persona
- Layer 2: "Use Playfair Display" is checked against `rule:avoid_generic_fonts` → LLM determines Playfair is NOT a generic font → **Grounded** (follows the rule)

Layer 2 runs ONLY on statements that Layer 1 classified as ambiguous (Dice 0.3-0.7) or Persona. High-confidence Layer 1 matches (Dice > 0.7) and anti-pattern blacklist violations stay as-is.

---

## Type Operator Registry

Add to `aec_concept.py`:

### `TYPE_OPERATORS` — Maps @type to verification strategy

```python
TYPE_OPERATORS = {
    'skill:Rule': {
        'verification_question': 'Was this rule followed or violated?',
        'strategy': 'compliance',  # Check follow vs violate
        'llm_prompt_template': (
            'You are a strict compliance evaluator.\n\n'
            'RULE: "{label}"\n'
            'STATEMENT: "{statement}"\n\n'
            'Does the statement FOLLOW, VIOLATE, or have NO RELATION to the rule?\n\n'
            'Reasoning steps:\n'
            '1. What does the rule require or forbid?\n'
            '2. What does the statement do?\n'
            '3. Is there direct compliance or violation?\n\n'
            'If the statement is merely "good advice" but not explicitly supported by the rule, classify as UNRELATED.\n\n'
            'Return ONLY one JSON object:\n'
            '{{"classification": "FOLLOW"|"VIOLATE"|"UNRELATED", "reasoning": "one sentence"}}'
        ),
    },
    'skill:AntiPattern': {
        'verification_question': 'Was this pattern avoided or present?',
        'strategy': 'violation_detect',  # Presence = bad
        'llm_prompt_template': (
            'You are a strict violation detector.\n\n'
            'FORBIDDEN PATTERN: "{label}"\n'
            'STATEMENT: "{statement}"\n\n'
            'Does the statement USE or RECOMMEND what the forbidden pattern describes?\n\n'
            'If the statement explicitly uses, recommends, or includes elements described '
            'in the forbidden pattern, classify as VIOLATES.\n'
            'If the statement avoids or does not mention the forbidden elements, classify as CLEAN.\n'
            'If there is no connection, classify as UNRELATED.\n\n'
            'Return ONLY one JSON object:\n'
            '{{"classification": "VIOLATES"|"CLEAN"|"UNRELATED", "reasoning": "one sentence"}}'
        ),
    },
    'skill:Technique': {
        'verification_question': 'Was this technique applied?',
        'strategy': 'application',  # Check if technique is being used
        'llm_prompt_template': (
            'You are a strict technique evaluator.\n\n'
            'TECHNIQUE: "{label}"\n'
            'STATEMENT: "{statement}"\n\n'
            'Does the statement APPLY, REFERENCE, or have NO RELATION to this technique?\n\n'
            'APPLY means the statement describes using this technique or recommends it.\n'
            'REFERENCE means it mentions the technique in passing.\n'
            'UNRELATED means no meaningful connection.\n\n'
            'Return ONLY one JSON object:\n'
            '{{"classification": "APPLY"|"REFERENCE"|"UNRELATED", "reasoning": "one sentence"}}'
        ),
    },
    'skill:Concept': {
        'verification_question': 'Is this topic addressed?',
        'strategy': 'relevance',  # Check if statement is about this concept
        # Concepts don't get LLM checks — too broad, too likely to false-positive
        # Layer 1 keyword coverage handles concepts deterministically
        'llm_prompt_template': None,
    },
    'skill:Tool': {
        'verification_question': 'Is this tool referenced correctly?',
        'strategy': 'usage',
        'llm_prompt_template': None,  # Tools handled by Layer 1 name matching
    },
    'skill:Trait': {
        'verification_question': 'Is persona consistent?',
        'strategy': 'tone',
        'llm_prompt_template': None,  # Traits stay as persona — they define tone, not facts
    },
}
```

### Key design decisions in the operators:
- **Only Rules, AntiPatterns, and Techniques get LLM checks.** Concepts, Tools, and Traits are handled deterministically or classified as persona.
- **Each prompt forces structured JSON output** with classification + reasoning.
- **Each prompt has a "generosity guard"** — "if merely good advice but not explicitly supported, classify as UNRELATED."
- **AntiPattern prompts check for presence** (violation detection), not absence.

---

## New Functions

### `get_type_operator(node_type: str) -> dict`

```python
def get_type_operator(node_type: str) -> dict | None:
    """Get the verification operator for a node type."""
    for type_key, operator in TYPE_OPERATORS.items():
        if type_key in node_type:
            return operator
    return None
```

### `llm_classify_statement(statement: str, node: dict, llm_fn) -> dict`

```python
def llm_classify_statement(statement: str, node: dict, llm_fn) -> dict:
    """
    Use LLM to classify statement against a specific KG node.
    Only called when Layer 1 is ambiguous (Dice 0.3-0.7).
    
    Returns: {'classification': str, 'reasoning': str, 'node_id': str}
    """
    node_type = node.get('@type', '')
    operator = get_type_operator(node_type)
    
    if not operator or not operator.get('llm_prompt_template'):
        return {'classification': 'UNRELATED', 'reasoning': 'No LLM operator for this type', 'node_id': node.get('@id', '')}
    
    prompt = operator['llm_prompt_template'].format(
        label=node.get('rdfs:label', ''),
        statement=statement,
    )
    
    try:
        result = llm_fn(prompt)
        text = result.get('text', result) if isinstance(result, dict) else str(result)
        
        # Parse JSON from response
        parsed = _extract_json_block(text)  # Reuse from ingest.py or implement simple version
        if isinstance(parsed, dict):
            classification = parsed.get('classification', 'UNRELATED').upper()
            reasoning = parsed.get('reasoning', '')
            
            # Normalize classification to our categories
            if classification in ('FOLLOW', 'APPLY', 'REFERENCE', 'CLEAN'):
                category = 'grounded'
            elif classification in ('VIOLATE', 'VIOLATES'):
                category = 'ungrounded'
            else:
                category = 'persona'
            
            return {
                'classification': classification,
                'category': category,
                'reasoning': reasoning,
                'node_id': node.get('@id', ''),
                'node_label': node.get('rdfs:label', ''),
                'method': f'llm_type:{node_type}',
            }
    except Exception:
        pass
    
    return {'classification': 'UNRELATED', 'category': 'persona', 'reasoning': 'LLM call failed', 'node_id': node.get('@id', '')}
```

### `type_driven_check(statement: str, layer1_result: dict, kg_index: dict, llm_fn) -> dict`

```python
def type_driven_check(statement: str, layer1_result: dict, kg_index: dict, llm_fn) -> dict:
    """
    Layer 2: Type-driven verification for ambiguous Layer 1 results.
    
    Only runs when:
    - Layer 1 classified as 'concept_persona' (no match found)
    - OR Layer 1 found matches in the 0.3-0.7 Dice range (ambiguous)
    
    Selects top candidate nodes from Layer 1 and runs type-specific LLM checks.
    """
    if not llm_fn:
        # No LLM available — return Layer 1 result as-is
        return layer1_result
    
    # Collect candidate nodes for LLM checking
    candidates = []
    
    # From Layer 1 ambiguous matches
    for match in layer1_result.get('matches', []):
        if 0.3 <= match.get('dice', 0) <= 0.7:
            candidates.append(match)
    
    # If Layer 1 found nothing, try broader matching against Rules and AntiPatterns
    if not candidates and layer1_result['category'] == 'concept_persona':
        for node_type in ['rules', 'antipatterns', 'techniques']:
            for entry in kg_index.get(node_type, []):
                dice = dice_bigram(statement, entry['label'])
                coverage = keyword_coverage(statement, entry['label'])
                if dice > 0.15 or coverage > 0.2:  # Very broad — let LLM decide
                    candidates.append({
                        'node_id': entry['@id'],
                        'label': entry['label'],
                        'node_type': node_type,
                        'dice': dice,
                        'coverage': coverage,
                        'node': entry['node'],
                    })
        # Keep top 3 candidates only
        candidates = sorted(candidates, key=lambda c: c.get('dice', 0), reverse=True)[:3]
    
    if not candidates:
        return layer1_result  # Nothing to check
    
    # Run LLM classification against top candidates
    best_result = None
    for candidate in candidates:
        node = candidate.get('node', candidate)
        if isinstance(node, dict) and '@type' not in node:
            # Reconstruct node from kg_index
            for ntype, nodes in kg_index.items():
                for n in nodes:
                    if n['@id'] == candidate['node_id']:
                        node = n['node']
                        break
        
        llm_result = llm_classify_statement(statement, node, llm_fn)
        
        if llm_result['category'] == 'grounded':
            best_result = llm_result
            break  # First grounded match wins
        elif llm_result['category'] == 'ungrounded' and not best_result:
            best_result = llm_result  # Violation found
    
    if best_result:
        return {
            'category': best_result['category'],
            'matches': layer1_result.get('matches', []),
            'violation': best_result if best_result['category'] == 'ungrounded' else None,
            'llm_result': best_result,
        }
    
    return layer1_result
```

---

## Integration: Update `concept_match_statement`

Modify the function from Layer 1 to optionally invoke Layer 2:

```python
def concept_match_statement(statement: str, kg_index: dict, blacklist: set, llm_fn=None) -> dict:
    """
    Match a statement against typed KG nodes.
    Layer 1: Deterministic lexical matching (always runs)
    Layer 2: Type-driven LLM verification (only for ambiguous/persona results)
    """
    # Layer 1 (unchanged from Layer 1 spec)
    layer1_result = _layer1_match(statement, kg_index, blacklist)
    
    # Layer 2: Only if Layer 1 was inconclusive AND LLM is available
    if layer1_result['category'] == 'concept_persona' and llm_fn:
        return type_driven_check(statement, layer1_result, kg_index, llm_fn)
    
    # Layer 1 high-confidence match or violation — return as-is
    return layer1_result
```

## Integration: Pass `llm_fn` Through

The `verify()` function in `aec.py` needs to accept an optional `llm_fn` parameter and pass it through to `concept_verify()`. The pipeline's `review()` stage already has access to the LLM function — pipe it through.

---

## Update Report Output

In `report.py`, when concept matching is active, show the method used:

```
├─── Statement Analysis ──────────────────────────────────────────────┤
│  # Statement                             Category     Method       │
│  ─── ──────────────────────────────────── ──────────── ──────────── │
│  1   Use CSS variables for consistency   Grounded     concept:rule │
│  2   Implement staggered reveals...      Grounded     concept:tech │
│  3   Use Inter for body text             Ungrounded   antipattern  │
│  4   Choose Playfair Display...          Grounded     llm_type:Rule│
│  5   Your typography should feel...      Persona      concept_none │
```

---

## Test Cases (Layer 2 specific)

### Test 7: Implicit Rule Compliance (requires LLM)
```bash
python cli.py run examples/frontend-design-v1.0.0-ff6ab491 "Use Playfair Display for your headlines" --provider anthropic
```
Expected: **Grounded** via LLM — Playfair Display is not a generic font, so it follows `rule:avoid_generic_fonts`

### Test 8: Implicit Violation (requires LLM)
```bash
python cli.py run examples/frontend-design-v1.0.0-ff6ab491 "Use a simple, clean Arial layout" --provider anthropic
```
Expected: **Ungrounded** via LLM — Arial is explicitly listed in `antipattern:inter_roboto_arial` AND violates `rule:avoid_generic_fonts`

### Test 9: No LLM Fallback
```bash
python cli.py run examples/frontend-design-v1.0.0-ff6ab491 "Use Playfair Display for your headlines" --provider stub
```
Expected: **Persona** — stub LLM can't do type-driven classification, falls back to Layer 1 which has no lexical match

### Test 10: Scholar Agent Unaffected
```bash
python cli.py run examples/jefferson "When was Jefferson born?" --provider anthropic
```
Expected: Same result as before Layer 2. Concept matching should not activate (factual AEC handles it).

---

## Performance Budget

- Layer 1: <3ms (unchanged)
- Layer 2 LLM calls: 0-3 per response (only ambiguous statements)
- Each LLM call: ~1-3 seconds
- Total worst case: ~10 seconds (3 ambiguous statements × 3 candidates × 1 LLM call)
- Typical case: ~3 seconds (1-2 LLM calls)

---

## Quality Checks

1. Type operators only fire for Rules, AntiPatterns, and Techniques (not Concepts/Tools/Traits)
2. LLM prompts force JSON output with classification + reasoning
3. LLM "generosity guard" is in every prompt ("if merely good advice, classify UNRELATED")
4. Scholar agents completely unaffected
5. Layer 1 high-confidence matches (Dice > 0.7) never go to LLM
6. Anti-pattern blacklist violations never go to LLM (deterministic is final)
7. Report shows which method produced each classification
8. All Layer 1 tests still pass
