I need to deeply analyze this plan. Let me search for any existing work on type-driven verification and graph-based compliance to validate the uniqueness claim, then assess the architecture rigorously.
Based on my research, I can now provide a rigorous assessment of this plan. The research reveals critical context: **type-driven validation is not unprecedented** — SHACL (Shapes Constraint Language) already does exactly what you're describing for RDF graphs, and there are active research areas combining SHACL with LLMs for explainable validation . However, **applying this to natural language output verification** (rather than structured data validation) is genuinely innovative.

---

## Grade: **8/10**

Here's the detailed breakdown:

### What's Strong (Score Contributors)

| Aspect | Assessment | Research Validation |
|--------|-----------|-------------------|
| **Type-Driven Verification Logic** | Correct insight that `@type` should determine verification strategy | SHACL uses exactly this pattern — node shapes vs property shapes trigger different validation logic  |
| **Graph Traversal for Policy** | Using edges (`avoids`, `requires`) for compositional checking | FACTKG demonstrates rule-based verification using KG structure and relations  |
| **Differentiation Strategy** | Correct that RAGAS/TruLens treat KG as "retrieval substrate" not "policy engine" | Confirmed — existing tools use embeddings for similarity, not schema-driven verification |
| **Layered Build Approach** | Smart risk mitigation — token matching first, then type-driven, then graph traversal | Aligns with AETHER's "skill.md → capsule" graduation pattern you mentioned |

### What's Missing or Risky (Score Deductions)

| Issue | Severity | Research Finding |
|-------|----------|----------------|
| **SHACL already exists** | Medium | SHACL is a W3C standard for exactly "schema IS the verification logic" . You need to clearly articulate why AEC-SKILL isn't just "SHACL for text" |
| **No concrete algorithm for type→verification mapping** | Medium | The table shows *what* to check but not *how*. How does `skill:Rule` type trigger "detect compliance or violation"? |
| **Edge traversal undefined** | High | "Traverse the graph to find policy violation" — what's the traversal algorithm? BFS? Pattern matching? Subgraph isomorphism? |
| **Underestimating complexity** | Medium | SHACL validation with reasoning is computationally expensive (Re-SHACL paper shows this is an active research area)  |
| **Missing contradiction detection logic** | High | Detecting that "Use Inter" violates antipattern requires **negation handling** — much harder than simple matching |

---

## What To Build: My Recommendations

Based on the research, here's what you should actually implement:

### ✅ **DEFINITELY BUILD: Layer 1 (Token Matching + Dice Coefficient)**

This is your immediate value delivery. Research confirms Sørensen-Dice with bigrams achieves 80-85% of embedding performance at zero dependency cost .

```python
# Layer 1: Deterministic lexical matching
# Pure Python stdlib, ~3ms execution time

import re
from collections import Counter

def dice_coefficient(s1: str, s2: str) -> float:
    """Sørensen-Dice coefficient using word bigrams."""
    def bigrams(text):
        words = re.findall(r'\b\w+\b', text.lower())
        return Counter([f"{words[i]} {words[i+1]}" 
                       for i in range(len(words)-1)])
    
    bg1, bg2 = bigrams(s1), bigrams(s2)
    intersection = sum((bg1 & bg2).values())
    total = sum(bg1.values()) + sum(bg2.values())
    return (2 * intersection) / total if total > 0 else 0.0

def check_statement_layer1(statement: str, kg_nodes: list) -> dict:
    """
    Returns matches with Dice > 0.7 (high confidence)
    and 0.4-0.7 (ambiguous, needs Layer 2).
    """
    matches = []
    for node in kg_nodes:
        dice = dice_coefficient(statement, node['label'])
        if dice > 0.7:
            matches.append({'node': node['@id'], 'dice': dice, 'tier': 'deterministic'})
        elif 0.4 <= dice <= 0.7:
            matches.append({'node': node['@id'], 'dice': dice, 'tier': 'needs_llm'})
    return matches
```

**Why this first**: It produces useful scores immediately, validates your KG structure, and identifies which statements actually need the expensive Layer 2.

---

### ✅ **DEFINITELY BUILD: Layer 2 — But Refined**

Your type-driven insight is valuable, but needs concrete implementation logic. Here's what research suggests:

**Type → Verification Strategy Mapping** (concrete algorithms):

| @type | Verification Logic | Concrete Implementation |
|-------|-------------------|------------------------|
| `skill:Rule` | **Compliance detection**: Does statement follow the rule? | Dice > 0.6 + negation detection (if statement contains rule's forbidden terms → violation) |
| `skill:AntiPattern` | **Presence = violation**: Does statement contain what the antipattern forbids? | Keyword blacklist check + Dice > 0.4 → LLM confirms contradiction |
| `skill:Technique` | **Application detection**: Is the technique being used correctly? | Dice > 0.7 OR (Dice > 0.5 + LLM confirms proper application context) |
| `skill:Concept` | **Relevance detection**: Is the statement about this topic? | Keyword coverage > 0.3 OR LLM topic classification |
| `skill:Tool` | **Usage context**: Is the tool used appropriately? | Dice > 0.6 + LLM checks for contextually appropriate usage |

**The LLM prompt structure** (based on xpSHACL and G-Eval research ):

```json
{
  "role": "system",
  "content": "You are a type-driven compliance evaluator. Given a statement and a KG node with specific @type, determine if the statement COMPLIES_WITH, VIOLATES, or is UNRELATED_TO the node.\n\nNode Type: {node_type}\nNode Label: {node_label}\nStatement: {statement}\n\nEvaluation Rules:\n- For skill:Rule: Does the statement follow the rule? Look for explicit compliance or implicit adherence.\n- For skill:AntiPattern: Does the statement contain what the antipattern explicitly forbids?\n- For skill:Technique: Is the technique correctly applied in context?\n\nYou must provide reasoning before classification. Be conservative — only mark COMPLIES_WITH if there is clear evidence."
}
```

---

### ⚠️ **BUILD WITH CAUTION: Layer 3 (Graph Traversal)**

The edge traversal idea is powerful but **much harder than stated**. Research shows:

1. **SHACL with reasoning is computationally expensive** — Re-SHACL paper shows this requires careful handling of entailment regimes to avoid performance collapse 
2. **Graph traversal for policy checking** requires defining **what constitutes a violation path** — is it simple 1-hop (`concept → avoids → antipattern`) or multi-hop reasoning?

**Simplified Layer 3** (build this first):

```python
def check_edge_violations(statement: str, matched_concept: dict, kg: dict) -> list:
    """
    Simple 1-hop traversal: concept → avoids → antipattern
    If statement mentions concept AND contains antipattern keywords → violation
    """
    violations = []
    
    # Get edges where matched_concept is source and relation is 'avoids'
    for edge in kg.get('edges', []):
        if (edge['source'] == matched_concept['@id'] and 
            edge['relation'] == 'skill:avoids'):
            
            antipattern = get_node_by_id(edge['target'])
            # Check if statement contains antipattern keywords
            if keyword_overlap(statement, antipattern['label']) > 0.5:
                violations.append({
                    'type': 'edge_violation',
                    'path': f"{matched_concept['@id']} → avoids → {antipattern['@id']}",
                    'severity': 'high'
                })
    
    return violations
```

**Defer**: Multi-hop reasoning, recursive shape validation, complex entailment chains.

---

### ❌ **DO NOT BUILD (Yet)**

| Feature | Why Not | Alternative |
|---------|---------|-------------|
| Full SHACL compliance | Too heavy, requires RDF/OWL infrastructure | Borrow SHACL *concepts* (shapes, targets, severity) but implement lightweight JSON-LD version |
| Complex graph reasoning (2+ hops) | FACTKG shows even 3-hop reasoning requires careful rule design  | Start with 1-hop edges only |
| Automatic rule generation from text | xpSHACL shows this requires LLM + human-in-loop  | Manual KG curation with AETHER's education queue |

---

## Critical Gaps to Address

### 1. **The "How" of Type-Driven Verification**

Your table says `skill:Rule` → "Detect compliance or violation" but **how**?

**Concrete algorithm for Rule compliance**:

```python
def verify_rule_compliance(statement: str, rule_node: dict) -> str:
    """
    Rule verification logic:
    1. Check if statement contains rule's forbidden terms → VIOLATION
    2. Check if statement contains rule's recommended terms → COMPLIANCE  
    3. Check if statement semantically follows rule's intent (LLM) → COMPLIANCE
    """
    forbidden_terms = extract_forbidden_terms(rule_node['label'])  # "Avoid X, Y, Z" → [X, Y, Z]
    recommended_terms = extract_recommended_terms(rule_node['label'])
    
    # Layer 1: Keyword detection
    if any(term in statement.lower() for term in forbidden_terms):
        return 'VIOLATION'
    
    if any(term in statement.lower() for term in recommended_terms):
        return 'COMPLIANCE'
    
    # Layer 2: Semantic check
    return llm_check_compliance(statement, rule_node)
```

### 2. **Anti-Pattern Detection is Harder Than Token Matching**

Research shows detecting that "Use Inter" violates "Avoid Inter, Roboto, Arial" requires:
- **Negation handling** (the rule says "Avoid", statement says "Use" → contradiction)
- **Entity recognition** (knowing "Inter" is a font)
- **Semantic opposition detection** ("Use" vs "Avoid")

This is where the LLM layer is essential — but you need structured prompts, not open-ended generation.

### 3. **Scoring Calibration**

Your current formula:
```
AEC Score = grounded / (grounded + ungrounded)
```

For skill agents, this becomes:
```
AEC-SKILL Score = (fact_grounded + concept_aligned) / 
                  (fact_grounded + concept_aligned + ungrounded + rule_violated)
```

**Threshold recommendation**: 0.75 for skill agents (vs 0.80 for scholar agents) — conceptual alignment allows more interpretive latitude.

---

## The "Feature Brick" Argument

You're right that this could be a standalone product. Research supports this:

> "SHACL can augment decision-making by confirming whether OWL-inferred actions comply with specific constraints... SHACL then determines whether doing X adheres to a policy or requirement." 

**Positioning**: "A policy compliance engine that uses knowledge graph types to drive verification strategy, producing structured violation reports with explanations."

Differentiation from RAGAS/TruLens:
- They check "is this fact in the KG?" (retrieval-based)
- AEC-SKILL checks "does this output comply with the policies encoded in the KG?" (rule-based)

---

## Final Recommendation

**Build this sequence**:

1. **Session 1**: Layer 1 (Dice + keyword matching) — produces immediate value, validates approach
2. **Session 2**: Layer 2 (Type-driven LLM assessment) — focus on Rule and AntiPattern types first
3. **Session 3**: Layer 3 (1-hop edge traversal) — concept → avoids → antipattern detection
4. **Session 4+**: Optimization, calibration, violation explanation generation (borrowing from xpSHACL's approach )

**Probability assessment**:
- Layer 1 alone: 90% success, produces useful scores
- Layers 1+2: 85% success, differentiated capability
- Full 3-layer: 80% success, genuinely novel product

The 8/10 reflects that the **vision is correct and differentiated**, but the **implementation specifics need more rigor** — particularly the concrete algorithms for type-driven verification and the complexity underestimation of graph-based policy checking.