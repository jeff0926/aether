# Research Prompt: Concept-Level Entailment Checking for Skill-Based Agent Knowledge Graphs

## Context: The AETHER Framework

AETHER (Adaptive Embodied Thinking Holistic Evolutionary Runtime) is an agent framework where agents are represented as **capsules** — self-contained 5-file folders:

1. **manifest.json** — Identity (name, version, lineage)
2. **definition.json** — Pipeline config, triggers, domain boundaries
3. **persona.json** — Tone, style, behavioral traits
4. **kb.md** — Knowledge base (markdown)
5. **kg.jsonld** — Knowledge graph (JSON-LD with typed nodes and relationship edges)

Every query runs through a 4-stage pipeline: **Distill → Augment → Generate → Review**

- **Distill**: Extracts intent, entities, format preferences from the query
- **Augment**: Matches query entities against KB paragraphs and KG nodes, retrieves relevant context
- **Generate**: Calls an LLM with the persona, matched KB/KG context, and query
- **Review**: Runs AEC (Aether Entailment Check) to verify the response is grounded in the agent's knowledge

## The AEC Process (Current Implementation)

AEC is a **deterministic, post-generation verification gate**. It answers: "Is this response grounded in what the agent actually knows?"

### Step 1: Split Response into Statements
The LLM response is split into individual statements (sentence-level).

### Step 2: Extract Verifiable Values from Each Statement
For each statement, AEC extracts:
- **Numbers** (integers, decimals, magnitudes like "$25 million")
- **Dates** (full dates, years, month-year)
- **Percentages** (19.8%, 42%)
- **Proper names** (capitalized multi-word sequences)

### Step 3: Match Extracted Values Against KG Nodes
For each extracted value, AEC searches ALL KG node properties for a match:
- Numbers: match within ±1% tolerance
- Dates: exact match on canonical form
- Names: bidirectional partial string match (case-insensitive)
- Percentages: match within ±0.5% tolerance

### Step 4: Categorize Each Statement

| Category | Condition | Scoring Impact |
|----------|-----------|---------------|
| **Grounded** | Statement has extractable values AND at least one matches a KG node | Counts in numerator AND denominator |
| **Ungrounded** | Statement has extractable values AND none match any KG node | Counts in denominator ONLY (reduces score) |
| **Persona** | Statement has NO extractable verifiable values | EXCLUDED from score entirely |

### Step 5: Calculate Score

```
AEC Score = grounded / (grounded + ungrounded)
```

- **Threshold: 0.80** (configurable per capsule)
- Score ≥ threshold → **PASS** → response delivered to user
- Score < threshold → **FAIL** → response + gaps enter the **education queue**

### Step 6: On Failure — Self-Education Loop

When AEC fails:
1. The query, response, score, and identified gaps are queued
2. An education process researches the gaps via LLM
3. New knowledge is extracted as triples (subject-predicate-object)
4. New triples are validated through AEC (threshold 0.5)
5. Validated triples are added to the KG as `acquired` origin nodes
6. The original query is re-evaluated against the expanded KG
7. If the new score ≥ threshold → status: `integrated`; else → status: `failed`

This loop is complete and working for **factual/scholar agents**.

## The Problem: AEC Fails on Skill Agents

### Two Agent Types

**Scholar agents** have KGs with factual data:
```json
{"@id": "person:jefferson", "birth_year": 1743, "birth_place": "Virginia", "rdfs:label": "Thomas Jefferson"}
```
AEC works perfectly here. "Jefferson was born in 1743" → extracts name "Thomas Jefferson" (matches) + number 1743 (matches birth_year) → **Grounded**.

**Skill agents** have KGs with procedural/conceptual knowledge:
```json
{"@id": "rule:avoid_generic_fonts", "@type": "skill:Rule", "rdfs:label": "Avoid generic fonts like Arial and Inter"}
{"@id": "antipattern:purple_gradients_on_white", "@type": "skill:AntiPattern", "rdfs:label": "Purple gradients on white backgrounds"}
{"@id": "technique:staggered_reveals", "@type": "skill:Technique", "rdfs:label": "Staggered reveals using animation-delay"}
{"@id": "concept:typography", "@type": "skill:Concept", "rdfs:label": "Typography", "skill:rules": ["rule:avoid_generic_fonts"]}
```

### What Happens with Skill Agents

Given a frontend-design skill agent with 73 KG nodes (22 Rules, 22 Techniques, 14 Concepts, 6 AntiPatterns, 5 Traits, 4 Tools), here's what AEC does with a response about typography:

**Response excerpt:** "Choose Playfair Display or Cormorant Garamond for headlines. Avoid Inter and Arial. Use CSS variables for consistency. Implement staggered reveals using animation-delay."

**AEC analysis:**
- "Choose Playfair Display or Cormorant Garamond for headlines" → Extracts names "Playfair Display", "Cormorant Garamond" → Searches KG → No node has these as values → **Ungrounded** (but the recommendation FOLLOWS rule:avoid_generic_fonts — it IS grounded conceptually)
- "Avoid Inter and Arial" → Extracts names "Inter", "Arial" → Searches KG → No node has "Inter" or "Arial" as property values → **Ungrounded** (but this directly MATCHES antipattern:inter_roboto_arial — it IS grounded conceptually)
- "Use CSS variables for consistency" → No numbers, dates, or proper names extracted → **Persona** (but this MATCHES rule:use_css_variables EXACTLY — it should be Grounded)
- "Implement staggered reveals using animation-delay" → No extractable values → **Persona** (but this MATCHES technique:staggered_reveals EXACTLY — it should be Grounded)

**Result:** Score 0.0 or trivial 1.0 (all persona). The score is meaningless despite the response being perfectly aligned with the agent's knowledge.

### The Core Gap

AEC's value extraction only looks for: numbers, dates, percentages, proper names.

Skill KGs contain: rules, anti-patterns, techniques, concepts — none of which are numbers, dates, or names.

Therefore AEC cannot verify skill agent responses against their own knowledge. The entire statement categorization layer is blind to conceptual grounding.

## The KG Node Types in Skill Agents

Every node has `@id`, `@type`, `rdfs:label`, and `aether:origin`. The `@type` values are:

| @type | @id Prefix | What It Represents | Example rdfs:label |
|-------|-----------|-------------------|-------------------|
| `skill:Concept` | `concept:` | Core topic/domain areas | "Typography", "Spatial Composition" |
| `skill:Rule` | `rule:` | Explicit guidelines/mandates | "Avoid generic fonts like Arial and Inter" |
| `skill:AntiPattern` | `antipattern:` | Explicitly forbidden practices | "Purple gradients on white backgrounds" |
| `skill:Technique` | `technique:` | Implementation approaches | "Staggered reveals using animation-delay" |
| `skill:Tool` | `tool:` | Technologies referenced | "React", "Motion library (Framer Motion)" |
| `skill:Trait` | `trait:` | Persona behavior constraints | "Opinionated", "Perfectionist" |

Relationship edges between nodes: `skill:requires`, `skill:avoids`, `skill:enables`, `skill:contradicts`, `skill:contains`, `skill:prioritizes`, `skill:pairs_with`

## Constraints

1. **No embeddings or vector databases.** AETHER runs on Python stdlib + anthropic SDK only. No sentence-transformers, no FAISS, no ChromaDB, no numpy.
2. **Deterministic where possible.** The current AEC philosophy is that deterministic checks cannot be overridden by LLM self-assessment. Any concept-level checking should preserve this principle where feasible.
3. **LLM-assisted is acceptable** for concept matching only. AETHER already has an LLM function available in the pipeline. A settled architectural decision allows for a 60/40 hybrid: 60% LLM assessment, 40% deterministic gate. The deterministic gate has final say on numerical/factual claims. The LLM layer handles semantic/conceptual claims.
4. **Must produce the same score format:** `grounded / (grounded + ungrounded)` with persona excluded. The scoring formula and threshold system are settled and cannot change.
5. **Must work with the existing KG structure.** No changes to how KGs are stored or structured.
6. **Performance budget:** AEC review currently takes <3ms for scholar agents. Concept-level matching can be slower (LLM calls take seconds) but should be invoked only when needed — i.e., when the deterministic gate classifies too many statements as Persona.

## The Research Questions

### Question 1: Concept-Level Statement Matching
Given a free-text statement and a set of KG nodes with typed labels (Rule, AntiPattern, Technique, Concept, Tool), what are the proven approaches for determining whether the statement **aligns with**, **violates**, or **is unrelated to** each node?

Specifically:
- How do you match "Use CSS variables for consistency" against a node labeled "Use CSS variables for consistency" without embeddings? Token overlap? TF-IDF? Jaccard similarity on word sets? What's the false positive rate?
- How do you detect that "Choose Playfair Display for headlines" follows the rule "Avoid generic fonts like Arial and Inter" without the LLM? Is this possible deterministically, or does it require inference?
- How do you detect that a response containing "Use Inter for body text" VIOLATES the anti-pattern "Overused fonts (Inter, Roboto, Arial, System Fonts)"?

### Question 2: Statement Classification for Skill Agents
The current three categories (Grounded, Ungrounded, Persona) work for factual agents. For skill agents, we need to determine:
- Should the categories change? (e.g., add "Rule-Aligned", "Rule-Violated", "Technique-Applied"?)
- Or should we keep the same three categories but expand what counts as "extractable verifiable values" to include concept references?
- How do we avoid false grounding — marking something as grounded just because it contains a word that appears in a KG label?

### Question 3: The Hybrid Architecture
The proposed 60/40 hybrid scoring:
- 40% weight: Deterministic gate (existing — numbers, dates, names, percentages)
- 60% weight: LLM concept assessment (new — does this statement align with KG rules/techniques/anti-patterns?)

Questions:
- Is 60/40 the right split? What research or precedent supports this ratio?
- Should the LLM assessment run on EVERY statement, or only on statements the deterministic gate classified as Persona?
- What prompt structure produces reliable, consistent concept-alignment assessments from an LLM? (We need the LLM to classify, not generate — this is evaluation, not creation.)
- How do we prevent the LLM from being overly generous in its assessments? (LLMs tend to say "yes, this aligns" when it arguably doesn't.)

### Question 4: Anti-Pattern Violation Detection
Anti-patterns are uniquely valuable for skill agents. If the response explicitly does something the agent's KG says to AVOID, that should be detectable and should count as Ungrounded (or worse — a violation).

- What's the most reliable method for detecting that a response contains content matching an AntiPattern node?
- Example: Response says "Use a clean Inter font for body text." KG has `antipattern:inter_roboto_arial` with label "Overused fonts (Inter, Roboto, Arial, System Fonts)". How do we reliably catch this?
- Should anti-pattern violations be scored differently than simple ungrounded statements? (Worse than ungrounded — actively contradicts the agent's knowledge?)

### Question 5: Existing Frameworks and Research
What existing evaluation frameworks handle concept-level or rule-level verification of LLM outputs against structured knowledge?

- RAGAS, TruLens, DeepEval, LangSmith — do any of these support rule-based verification against a knowledge graph?
- Are there papers on "policy compliance checking" for LLM outputs that are relevant?
- NLI (Natural Language Inference) models — can they be applied here without adding heavy dependencies?
- Is there a lightweight approach from information retrieval (BM25, keyword extraction, n-gram overlap) that would work as a deterministic first pass before LLM assessment?

### Question 6: Scoring Calibration
With a hybrid system, how do we ensure the score is meaningful?

- Scholar agent with 10 factual statements: score represents factual accuracy
- Skill agent with 10 conceptual statements: score represents... what exactly? Rule adherence? Knowledge alignment? Technique coverage?
- Should the score semantics differ by agent type, or should we find a unified interpretation?
- How do we set the threshold for skill agents? Is 0.8 still appropriate, or should concept-level verification use a different bar?

## What I Need From You

1. **Survey the landscape** — What existing methods, frameworks, papers, and patterns address this problem? Don't limit to LLM evaluation — include information retrieval, NLI, policy compliance, and any adjacent fields.

2. **Propose an architecture** — Given the constraints (no embeddings, no vector DB, stdlib + LLM, deterministic where possible), what's the most reliable approach? Be specific about algorithms, not just categories.

3. **Identify the simplest viable version** — What's the minimum implementation that would produce meaningful scores for skill agents? Not the ideal solution — the one we can build in 1-2 sessions and iterate from.

4. **Flag risks and failure modes** — Where will this approach produce false positives (claiming grounding where there is none)? False negatives (missing real grounding)? Over-generous LLM assessments?

5. **Provide concrete examples** — Using the frontend-design skill KG (Rules like "Avoid generic fonts", AntiPatterns like "Purple gradients on white", Techniques like "Staggered reveals"), show how your proposed approach would score specific response statements.

## Reference: Frontend-Design KG Summary (73 nodes)

Node type breakdown:
- 22 Rules (e.g., "Avoid generic fonts like Arial and Inter", "Use CSS variables for consistency", "Match implementation complexity to aesthetic vision")
- 22 Techniques (e.g., "Staggered reveals using animation-delay", "Gradient meshes", "Asymmetric layout composition")
- 14 Concepts (e.g., "Typography", "Color and Theme", "Spatial Composition", "Motion and Animation")
- 6 AntiPatterns (e.g., "Overused fonts (Inter, Roboto, Arial, System Fonts)", "Purple gradients on white backgrounds", "Predictable layouts and cookie-cutter patterns")
- 5 Traits (e.g., "Bold Creative", "Perfectionist", "Opinionated")
- 4 Tools (e.g., "React", "Vue.js", "Motion library (Framer Motion)")

Edge types: requires, avoids, enables, contradicts, contains, prioritizes, pairs_with
