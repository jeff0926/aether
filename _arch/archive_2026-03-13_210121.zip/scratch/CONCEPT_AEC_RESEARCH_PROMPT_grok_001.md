Solution: Hybrid AEC (40% deterministic + 60% LLM NLI, per research precedents in TruLens/LangSmith custom judges and NLI papers for rule compliance).
Deterministic gate (stdlib, <1ms):

Keep current value extraction.
Add Jaccard similarity (word-set overlap) on statement vs. every KG rdfs:label/@id. Threshold ≥0.25 = match.
Match Rule/Technique/Concept/Tool/Trait → Grounded.
Match AntiPattern → Ungrounded (violation).

LLM gate (only on remaining Persona statements):
Few-shot NLI prompt on top-3 lexical candidates (or all if <73 nodes):
"Premise: [KG label]. Hypothesis: [statement]. Output JSON: {'classification': 'align'|'violate'|'unrelated'}."
Align → Grounded; violate → Ungrounded. Strict examples + "only if explicitly supported" prevent generosity.
Score unchanged: grounded / (grounded + ungrounded). Threshold 0.8. Invoke LLM only post-deterministic failure.
Simplest v1 (1 session): Lexical Jaccard only (no LLM).
Landscape: RAGAS/TruLens/LangSmith use LLM judges for policy adherence; arXiv NLI papers (requirements/policy checking) validate entailment; BM25/Jaccard proven lexical baselines (no embeddings). No exact skill-KG match found.
Risks: Lexical false positives (loose overlap), false negatives (paraphrase); LLM over-generous (mitigated by strict prompt).
Frontend examples (same response):

"Choose Playfair Display..." → no lexical match → LLM: aligns with rule:avoid_generic_fonts → Grounded.
"Avoid Inter and Arial" → lexical to antipattern → Ungrounded (or LLM confirms violation if using forbidden).
"Use CSS variables..." → exact label match → Grounded.
"Implement staggered reveals..." → exact technique match → Grounded.

Score now meaningful (previously 0.0).