I read your full document and the problem is very well framed. The short version:

**AEC currently verifies *facts***, but **skill agents express *policies, constraints, and techniques***.
Your extractor (numbers/dates/names) simply cannot see those signals.

The solution is **not a single fix** — it requires a **three-layer verification model** that separates:

1. **Literal grounding** (existing AEC)
2. **Concept alignment** (rule/technique matching)
3. **Policy violation detection** (anti-patterns)

You can implement a **deterministic → heuristic → LLM cascade** that preserves your philosophy.

Below is a research-backed architecture that fits **all your constraints**.

---

# 1. Key Insight From Research Fields

Your problem is already solved in adjacent domains:

| Field                            | Relevant Technique                      |
| -------------------------------- | --------------------------------------- |
| Information Retrieval            | BM25 / TF-IDF / token overlap           |
| Policy compliance                | rule matching + violation detection     |
| NLI (Natural Language Inference) | entailment/contradiction classification |
| RAG evaluation                   | claim-to-knowledge grounding            |
| static code analysis             | rule engine pattern matching            |

Frameworks like
RAGAS,
TruLens, and
DeepEval

all ultimately reduce grounding to:

**Claim → retrieve candidate knowledge → evaluate alignment**

You already have:

* claims (statements)
* knowledge (KG nodes)

What you're missing is **retrieval + alignment**.

---

# 2. The Architecture That Fits AETHER

You should implement a **4-stage Concept Grounding Engine (CGE)** inside AEC.

```
AEC
 ├─ Stage 1: Deterministic factual gate (existing)
 ├─ Stage 2: Deterministic concept retrieval (new)
 ├─ Stage 3: Deterministic policy violation check (new)
 └─ Stage 4: LLM semantic alignment (fallback)
```

LLM runs **only if deterministic stages are inconclusive**.

---

# 3. Stage 2 — Deterministic Concept Retrieval

This is **the most important addition**.

You must detect when a statement is *about* a KG concept.

The simplest working approach:

### Token Set Similarity

For every statement:

```
normalize(text):
  lowercase
  remove stopwords
  stem
```

Example

```
"Use CSS variables for consistency"

tokens:
{use, css, variable, consistency}
```

Now compare with node labels.

Node:

```
rule:use_css_variables
label: "Use CSS variables for consistency"
```

Tokens:

```
{css, variable, consistency}
```

### Jaccard Similarity

```
score = intersection / union
```

```
{css, variable, consistency} ∩ {use, css, variable, consistency}
= 3

union = 4

score = 0.75
```

Threshold:

```
>= 0.5 → candidate match
```

This works **shockingly well** for rule labels.

No external libs needed.

---

# 4. Detecting Technique Mentions

Techniques usually contain **unique tokens**.

Example node

```
technique:staggered_reveals
label: "Staggered reveals using animation-delay"
```

Statement

```
Implement staggered reveals using animation-delay
```

Token overlap:

```
{staggered, reveal, animation-delay}
```

Score:

```
3/4 ≈ 0.75
```

→ **Grounded**

---

# 5. Anti-Pattern Violation Detection

Anti-patterns require **inverse logic**.

Example node:

```
antipattern:inter_roboto_arial
label:
"Overused fonts (Inter, Roboto, Arial, System Fonts)"
```

Create a **token blacklist** from labels.

```
inter
roboto
arial
system-font
```

Then scan statements.

```
if token in blacklist:
    violation
```

Example:

```
Use Inter for body text
```

→ violation detected.

This is **deterministic and fast**.

---

# 6. Detecting Rule Compliance Without Explicit Words

Example problem you raised:

```
Rule:
Avoid generic fonts like Arial and Inter

Statement:
Use Playfair Display
```

This is **implicit compliance**.

Deterministic logic cannot reliably infer this.

Here you use the **LLM fallback**.

---

# 7. LLM Alignment Layer

Use LLM **only for statements that:**

```
no deterministic match
AND
no violation
AND
not persona
```

Prompt structure:

```
You are a strict evaluator.

Statement:
"Choose Playfair Display for headlines"

Knowledge Rule:
"Avoid generic fonts like Arial and Inter"

Question:
Does the statement FOLLOW, VIOLATE, or NOT RELATE to the rule?

Answer only:
FOLLOW
VIOLATE
UNRELATED
```

Important:

**Never ask open questions.**
Use **forced classification**.

---

# 8. Your Score Categories Should NOT Change

Keep:

```
Grounded
Ungrounded
Persona
```

Map internally:

| Detection              | Category   |
| ---------------------- | ---------- |
| rule match             | Grounded   |
| technique match        | Grounded   |
| concept mention        | Grounded   |
| anti-pattern violation | Ungrounded |
| unrelated              | Ungrounded |
| style/persona          | Persona    |

Your scoring formula remains valid.

---

# 9. Deterministic Retrieval Algorithm

Implementation pseudocode:

```
for statement in statements:

  tokens = normalize(statement)

  matches = []

  for node in KG:

      node_tokens = normalize(node.label)

      score = jaccard(tokens, node_tokens)

      if score >= 0.5:
          matches.append(node)

  if matches:
      grounded += 1
      continue

  if detect_antipattern(tokens):
      ungrounded += 1
      continue

  mark_for_llm(statement)
```

---

# 10. When LLM Runs

Only for **unresolved statements**.

Then:

```
for candidate_nodes:

   classify(statement vs node)
```

Decision logic:

```
if any FOLLOW:
   grounded

if any VIOLATE:
   ungrounded

else:
   persona
```

---

# 11. Performance

Typical skill response:

```
6 statements
```

Deterministic stages:

```
<2 ms
```

LLM calls:

```
0-2 statements usually
```

Total runtime:

```
2-6 seconds
```

Which matches your acceptable budget.

---

# 12. Why Your 60/40 Split Is Not Ideal

Your proposal:

```
60% LLM
40% deterministic
```

I strongly recommend instead:

```
80% deterministic
20% LLM
```

Reason:

LLMs **over-approve**.

Deterministic grounding should dominate.

---

# 13. False Positive Protection

You asked how to avoid:

> grounding just because words overlap

Add **type weighting**.

Example:

```
Rule tokens weight: 1.0
Technique tokens weight: 1.0
Concept tokens weight: 0.5
Tool tokens weight: 0.3
```

Then require:

```
score * weight >= 0.5
```

Concepts alone cannot ground statements.

---

# 14. Example Scoring (Your Typography Case)

### Statement

```
Use CSS variables for consistency
```

Matches:

```
rule:use_css_variables
```

Result:

```
Grounded
```

---

### Statement

```
Implement staggered reveals using animation-delay
```

Matches:

```
technique:staggered_reveals
```

Result:

```
Grounded
```

---

### Statement

```
Choose Playfair Display for headlines
```

Deterministic:

```
no match
```

LLM:

```
Rule: Avoid generic fonts
Result: FOLLOW
```

Result:

```
Grounded
```

---

### Statement

```
Use Inter for body text
```

Blacklist hit:

```
inter
```

Matches anti-pattern:

```
Overused fonts
```

Result:

```
Ungrounded
```

---

# 15. Minimal Version You Can Build in 1 Session

Implement only:

### 1️⃣ Tokenization

```
split
lowercase
remove stopwords
```

### 2️⃣ Jaccard similarity

### 3️⃣ Anti-pattern token list

### 4️⃣ LLM fallback classifier

That's it.

No TF-IDF needed initially.

---

# 16. Biggest Failure Modes

### 1. Overlapping language

Example:

```
concept: Typography
```

Everything mentions typography.

Solution:

```
Concept nodes cannot ground statements alone.
```

---

### 2. Multi-rule statements

Example:

```
Use CSS variables and staggered reveals
```

Solution:

Split statements by conjunctions.

---

### 3. LLM generosity

Fix:

Require **confidence classification**.

```
FOLLOW_STRONG
FOLLOW_WEAK
UNRELATED
VIOLATE
```

Only strong counts.

---

# 17. One Radical Improvement (Highly Recommended)

Add a **Rule Pattern Field** to nodes.

Example:

```
rule:use_css_variables

pattern:
["css variable", "--var(", "var("]
```

Now detection becomes trivial.

This dramatically improves deterministic matching.

---

# 18. The Deeper Insight

AEC for scholars verifies **truth**.

AEC for skill agents verifies **policy compliance**.

So the score semantics become:

```
Grounded = Response follows agent doctrine
```

Not factual correctness.

This is actually **more powerful**.

---

# 19. Final Architecture

```
STATEMENT
   │
   ▼
FACT EXTRACTION (existing)
   │
   ▼
CONCEPT TOKEN MATCH (Jaccard)
   │
   ▼
ANTI-PATTERN DETECTOR
   │
   ▼
LLM ALIGNMENT CHECK
   │
   ▼
CATEGORY
```

---

# 20. Bottom Line

Your AEC system is **already 70% correct**.

You only need to add:

1. **Token similarity retrieval**
2. **Anti-pattern detection**
3. **LLM rule alignment fallback**

This keeps:

* deterministic philosophy
* KG structure
* scoring formula
* Python-only environment

---

If you'd like, I can also show you something **much more powerful** that would dramatically improve AETHER:

A technique used in **static code analyzers** that could make **skill agents 10× more reliable** than standard RAG systems.

It's a **"Rule Execution Engine"** instead of just a knowledge graph.
