# AETHER Dashboard — Build Prompt for Claude Code

**What:** Single-file diagnostic dashboard for the AETHER framework  
**Where:** `dashboard.py` in project root (`C:\Users\I820965\dev\aether\`)  
**Constraint:** Python stdlib only. No Flask, no FastAPI, no npm. Zero new dependencies.

---

## Context

Read these files first:
- `AETHER_MEMORY_PHASE_0-2_2026-03-09.md` — Full framework reference
- `IGNORE/daily/AETHER_SYSTEM_REPORT_2026-03-09.md` — Latest test results (142 tests, 139 passed)
- `tests/test_exhaustive.py` — The test suite the Force Test button should execute

For visual reference: `capsules/skill_lab.html` (from aether-RD) shows the AETHER design language — dark theme, compact panes, monospace, status badges, neon accents on dark. Match this aesthetic. Do NOT fork the file. Build fresh.

---

## Run Command

```bash
python dashboard.py                  # Starts on port 8864
python dashboard.py --port 9000      # Custom port
```

Opens `http://localhost:8864` in browser. Serves a single HTML page with embedded CSS/JS. All data loaded via JSON API endpoints served by the same Python process.

---

## Architecture

**Single file: `dashboard.py`** (~400-600 lines Python + embedded HTML/CSS/JS)

**Server:** `http.server.HTTPServer` from stdlib  
**API pattern:** GET `/api/{endpoint}` returns JSON  
**Frontend:** Embedded HTML string with vanilla JS (no React, no build step)  
**Port:** 8864 (864 Zeros)

---

## API Endpoints

| Endpoint | Method | Returns |
|----------|--------|---------|
| `/` | GET | Dashboard HTML page |
| `/api/capsules` | GET | All capsules with metadata (name, version, KB size, KG nodes, queue stats) |
| `/api/kg/<folder>` | GET | KG nodes + edges for visualization (nodes colored by origin type) |
| `/api/aec` | POST | AEC verify result. Body: `{"capsule": "folder-name", "text": "text to verify"}` |
| `/api/queue/<folder>` | GET | Education queue items and stats for a capsule |
| `/api/test` | GET | Runs `tests/test_exhaustive.py`, returns results JSON |
| `/api/metrics` | GET | Codebase metrics (files, line counts, module health) |

**Implementation notes:**
- Import aether modules directly (aec, aether, kg, education, habitat, llm, stamper). They're all in the project root.
- Capsules live in `examples/` directory. Iterate subdirectories.
- For `/api/test`, use `subprocess.run()` to execute `tests/test_exhaustive.py`. Timeout at 120 seconds.
- For `/api/kg/<folder>`, build the required files path using `aether.get_required_files(folder_name)`.
- Use `from kg import load_kg, get_nodes, stats as kg_stats` for KG data.
- Use `from aec import verify` for AEC lab.
- Use `from education import get_queue, queue_stats` for education queue.

---

## Dashboard Layout

**Header bar:** Logo ("AETHER DASHBOARD"), subtitle ("Operational Diagnostics | KG Explorer | AEC Lab"), right-side stats (capsule count, total KG nodes, pending education items).

**Sidebar (left, ~220px):** Capsule registry. One card per capsule showing name, version, KG node count, education queue pending count. Click to select. Selected capsule drives the KG Explorer, AEC Lab, and Queue panels.

**Main area (right of sidebar):** Tab bar with 5 tabs. Content panel below.

### Tab 1: Overview

Capsule inventory grid. One card per capsule showing:
- Name, version, ID
- KB size (chars), KG nodes (colored count by origin: core/acquired/deprecated)  
- Education queue: total, pending, integrated, failed
- Overall health indicator (green if queue pending < 3, orange if 3-5, red if > 5)

Also show codebase metrics at bottom: total files, total lines, line count per module.

### Tab 2: KG Explorer

**This is the most important panel.** Two-column layout:

**Left (70%): Graph visualization.** Render KG nodes as circles on an SVG canvas. Color by origin type:
- Core = blue (#58a6ff)
- Acquired = green (#3fb950)
- Updated = orange (#d29922)  
- Deprecated = red (#f85149)
- Provenance = purple (#a371f7)

Draw edges between nodes where a property value references another node's @id. Edge labels show the predicate name. Use a simple force-directed or grid layout (doesn't need to be fancy — clarity over beauty).

Show a legend mapping colors to origin types.

**Right (30%): Node detail panel.** When a node is clicked:
- Show @id, rdfs:label, origin type
- List all properties as key-value pairs
- Highlight the origin badge

Below the detail panel, show a node list (scrollable) with origin dot + label. Click to select in graph.

Show KG stats at top: total nodes, count per origin type.

**Data source:** `/api/kg/<selected-capsule-folder>`

### Tab 3: AEC Lab

Interactive AEC verification tool. Layout:

1. **Capsule selector** — dropdown of all capsules (pre-populated from sidebar selection)
2. **Text input** — textarea for response text to verify
3. **Verify button** — calls POST `/api/aec` with capsule + text
4. **Results display:**
   - Score bar (visual, 0-100%, colored green if pass / red if fail, with threshold marker at 80%)
   - Score number, threshold, pass/fail badge
   - Statement breakdown: each statement shown as a row, colored by category:
     - GROUNDED (green left border)
     - UNGROUNDED (red left border) 
     - PERSONA (purple left border)
   - Gaps list if any ungrounded statements
   - Summary: "3 grounded, 0 ungrounded, 2 persona"

5. **Pre-filled examples** — buttons that fill the textarea with test text:
   - "Jefferson was born on April 13, 1743 in Virginia" (should pass)
   - "Jefferson was born in 1750 in New York" (should fail)
   - "He was a brilliant thinker and visionary" (all persona)

### Tab 4: Force Test

1. **Run Tests button** (prominent, green) — calls `/api/test`
2. **While running:** Show spinner with "Running 142 tests..."
3. **Results display:**
   - Summary cards: Total, Passed, Failed, Pass Rate
   - Results table grouped by category (AEC, KG, Pipeline, Stamper, Education, Habitat, LLM, Report, Integration, Known Issues)
   - Each row: test name, expected, actual, PASS/FAIL status (green/red)
   - Failed tests highlighted and shown first
4. **Last run timestamp**

The test endpoint runs `tests/test_exhaustive.py` via subprocess. Parse the output or the generated report file at `IGNORE/daily/AETHER_SYSTEM_REPORT_2026-03-09.md` to display structured results.

### Tab 5: Education Queue

Per-capsule education queue viewer. Shows:
- Stats: total, pending, researching, validated, integrated, failed
- Item list with: record ID, query (truncated), AEC score (colored: <0.5 red, 0.5-0.8 orange, >0.8 green), status badge, timestamp
- Click item to expand: full query, full response (truncated), gaps list

---

## Design Specifications

**Theme:** Dark mode matching AETHER tooling aesthetic. Reference the CSS variables from skill_lab.html:

```css
--bg-dark: #0d1117;
--bg-panel: #161b22;
--border: #30363d;
--text: #c9d1d9;
--text-dim: #8b949e;
--accent: #58a6ff;
--green: #3fb950;
--orange: #d29922;
--red: #f85149;
--purple: #a371f7;
--cyan: #56d4dd;
```

**Typography:** Monospace — "Cascadia Code", "Fira Code", "JetBrains Mono", monospace. All-caps labels at 9-10px. Body text at 11-12px. Numbers bold.

**Interactions:**
- Capsule sidebar click → selects capsule → KG Explorer and AEC Lab auto-update
- Tab switching → show/hide panels
- KG node click → show properties in detail panel
- AEC verify → POST request → render results inline
- Force test → show spinner → render results when done

**Responsive:** Don't worry about mobile. This is a developer tool.

---

## Quality Checks

After building, verify:
1. `python dashboard.py` starts without errors
2. Browser opens to http://localhost:8864
3. Capsule sidebar loads all capsules from `examples/`
4. KG Explorer shows nodes colored by origin for the jefferson capsule (51 nodes)
5. AEC Lab returns results when verifying "Jefferson was born in 1743" against jefferson capsule
6. Force Test button runs and displays results
7. Education Queue shows pending items for scholar-buffett (4 pending)
8. No external dependencies added to the project
9. Single file — `dashboard.py` — nothing else created
10. Dashboard can be deleted without affecting any other file in the project

---

## File Placement

```
C:\Users\I820965\dev\aether\
├── dashboard.py          ← NEW (this file)
├── aec.py
├── aether.py
├── cli.py
├── education.py
├── habitat.py
├── kg.py
├── llm.py
├── report.py
├── stamper.py
└── ...
```

---

## What NOT to Build

- No authentication
- No database
- No WebSocket (simple request/response is fine)
- No external CSS/JS files
- No npm, no node, no build step
- No persistent state — dashboard reads live from capsule files every request
- No modification endpoints — this is read-only + test execution

