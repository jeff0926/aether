# AETHER Exhaustive System Test — Claude Code Prompt

**Purpose:** Run every testable surface of the AETHER framework and produce a detailed diagnostic report.
**When:** Before Phase 3 planning. We need ground truth on what works, what's broken, and what's missing.
**Output:** A markdown report saved to `IGNORE/daily/AETHER_SYSTEM_REPORT_2026-03-09.md`

---

## Instructions for Claude Code

Read the memory document first: `AETHER_MEMORY_PHASE_0-2_2026-03-09.md`

Then create and execute a Python test script (`tests/test_exhaustive.py`) that runs ALL of the following tests. Do NOT use pytest. Use simple asserts and try/except blocks. Capture ALL results — passes AND failures — into a structured report.

**Critical:** Use `provider="stub"` for all pipeline tests unless explicitly testing LLM integration. We're testing the framework, not spending API credits.

---

## TEST CATEGORIES

### 1. MODULE IMPORT & SELF-TEST (All 10 files)

For each module, verify it imports cleanly and its `__main__` block logic works:

```python
# Test every module imports without error
import aec
import aether
import cli
import education
import habitat
import kg
import llm
import report
import stamper
```

Run each module's built-in self-test by executing its `__main__` block logic inline (don't shell out — call the functions directly).

### 2. AEC VERIFICATION (aec.py) — 15+ test cases

```python
from aec import verify, split_statements, _extract_values, deterministic_gate

# 2.1 Statement splitting
test_split_basic = split_statements("First sentence. Second sentence. Third sentence.")
# Expect 3 statements

test_split_abbreviations = split_statements("Mr. Smith went to Washington. He met Dr. Jones.")
# Expect 2 statements (abbreviations protected)

test_split_empty = split_statements("")
# Expect []

test_split_short = split_statements("Hi.")
# Expect [] (< 10 chars filtered)

# 2.2 Value extraction
test_extract_numbers = _extract_values("The cost was 1,743 dollars")
# Should find (1743.0, "number")

test_extract_year = _extract_values("Born in 1743")
# Should find ("1743", "date")

test_extract_full_date = _extract_values("Born on April 13, 1743")
# Should find ("1743-04-13", "date")

test_extract_percentage = _extract_values("Growth was 19.8%")
# Should find (19.8, "percentage")

test_extract_name = _extract_values("Thomas Jefferson was president")
# Should find ("Thomas Jefferson", "name")

test_extract_magnitude = _extract_values("Revenue was $25 million")
# Should find magnitude extraction — THIS IS A KNOWN ISSUE (deferred item 5.6)
# Document whether it extracts 25000000 or just 25

test_extract_magnitude_billion = _extract_values("Market cap is $373.3 billion")
# Same — document actual behavior

# 2.3 Deterministic gate
test_gate_match = deterministic_gate("Jefferson was born in 1743", [
    {"@id": "person:jefferson", "birth_year": 1743}
])
# Expect matched=True

test_gate_no_match = deterministic_gate("Jefferson was born in 1750", [
    {"@id": "person:jefferson", "birth_year": 1743}
])
# Expect matched=False

test_gate_no_values = deterministic_gate("He was a brilliant thinker", [
    {"@id": "person:jefferson", "birth_year": 1743}
])
# Expect method="no_values" (persona statement)

test_gate_empty_kg = deterministic_gate("Born in 1743", [])
# Expect matched=False, method="no_input"

# 2.4 Full verify
test_verify_grounded = verify(
    "Thomas Jefferson was born on April 13, 1743 in Virginia. He authored the Declaration of Independence in 1776.",
    [
        {"@id": "person:jefferson", "rdfs:label": "Thomas Jefferson", "birth_year": 1743, "birth_date": "1743-04-13"},
        {"@id": "doc:declaration", "year": 1776, "author": "Thomas Jefferson"},
    ]
)
# Document: score, passed, grounded count, ungrounded count, persona count

test_verify_mixed = verify(
    "Jefferson was born in 1743. He was a brilliant thinker. He died in 1850.",
    [{"@id": "person:jefferson", "birth_year": 1743, "death_year": 1826}]
)
# 1850 should be ungrounded (actual death year 1826). Document score.

test_verify_all_persona = verify(
    "He was a brilliant thinker and visionary leader who inspired millions.",
    [{"@id": "person:jefferson", "birth_year": 1743}]
)
# All persona = should pass (score defaults to 1.0 when no verifiable statements)

test_verify_empty_response = verify("", [{"@id": "test"}])
# Should handle gracefully

test_verify_numeric_tolerance = verify(
    "The value was 99.5",
    [{"@id": "test", "value": 100}]
)
# 1% tolerance — should this match? Document actual behavior.
```

### 3. KNOWLEDGE GRAPH (kg.py)

```python
from kg import load_kg, get_nodes, query_nodes, add_knowledge, add_acquired
from kg import mark_deprecated, mark_updated, get_nodes_by_origin, save_kg, stats, EMPTY_KG

# 3.1 Load/create
test_empty_kg = load_kg("nonexistent_path.jsonld")
# Should return empty graph, not crash

# 3.2 Add knowledge with all 5 origin types
kg = {"@context": EMPTY_KG["@context"].copy(), "@graph": [
    {"@id": "test:core1", "rdfs:label": "Core Node", "value": 100}
]}
kg = add_knowledge(kg, {"subject": "Fact A", "predicate": "relates_to", "object": "X", "confidence": 0.9}, origin="acquired")
kg = add_knowledge(kg, {"subject": "Source Doc", "predicate": "url", "object": "http://example.com"}, origin="provenance")
test_stats_after_add = stats(kg)
# Expect: core=1, acquired=1, provenance=1

# 3.3 Mark operations
kg = mark_deprecated(kg, "test:core1", reason="outdated")
test_deprecated = get_nodes_by_origin(kg, "deprecated")
# Expect 1 deprecated node

kg = mark_updated(kg, "test:core1", {"value": 150})
test_updated_value = [n for n in get_nodes(kg) if n.get("@id") == "test:core1"][0]["value"]
# Expect 150

# 3.4 Query nodes
test_query = query_nodes(kg, ["Core"])
# Should match "Core Node" by label

test_query_empty = query_nodes(kg, [])
# Should return []

# 3.5 Invalid origin
try:
    add_knowledge(kg, {"subject": "X", "predicate": "Y", "object": "Z"}, origin="invalid")
    test_invalid_origin = "FAIL — should have raised ValueError"
except ValueError:
    test_invalid_origin = "PASS"

# 3.6 Save and reload
import tempfile, os
with tempfile.NamedTemporaryFile(suffix=".jsonld", delete=False, mode='w') as f:
    save_kg(kg, f.name)
    reloaded = load_kg(f.name)
    test_reload = len(get_nodes(reloaded)) == len(get_nodes(kg))
    os.unlink(f.name)
```

### 4. CAPSULE & PIPELINE (aether.py)

```python
from aether import Capsule, validate_folder, generate_id, get_required_files

# 4.1 Validate all 4 example capsules
for capsule_dir in ["examples/jefferson", "examples/scholar-buffett",
                     "examples/aether-validator-v1.0.0-d5a16071",
                     "examples/test-agent-v1.0.0-24f8476e"]:
    missing = validate_folder(capsule_dir)
    # Document missing files per capsule

# 4.2 Load each capsule
for capsule_dir in ["examples/jefferson", "examples/scholar-buffett",
                     "examples/aether-validator-v1.0.0-d5a16071",
                     "examples/test-agent-v1.0.0-24f8476e"]:
    try:
        cap = Capsule(capsule_dir)
        # Record: id, name, version, KB size, KG node count
    except Exception as e:
        # Record failure

# 4.3 Run pipeline with stub LLM on each capsule
from llm import make_llm_fn
stub_fn = make_llm_fn(provider="stub")

test_queries = {
    "examples/jefferson": "When was Thomas Jefferson born?",
    "examples/scholar-buffett": "How much did Berkshire pay for See's Candies?",
    "examples/test-agent-v1.0.0-24f8476e": "What is Aether?",
}

for capsule_dir, query in test_queries.items():
    cap = Capsule(capsule_dir, llm_fn=stub_fn)
    ctx = cap.run(query)
    # Record per capsule:
    #   - distilled intent, entities
    #   - augment KB matches, KG matches
    #   - generated response length
    #   - review AEC score, passed, grounded/ungrounded/persona counts
    #   - telemetry: total_ms, stage breakdown
    #   - whether education queue was triggered

# 4.4 Validator capsule (generate disabled)
cap = Capsule("examples/aether-validator-v1.0.0-d5a16071", llm_fn=stub_fn)
ctx = cap.run("Validate this text")
# Record: should skip generate stage, review should still run

# 4.5 generate_id format
test_id = generate_id("Test Agent", "1.0.0")
# Verify format: {slug}-v{version}-{uid8}
import re
test_id_format = bool(re.match(r'^[a-z0-9-]+-v\d+\.\d+\.\d+-[a-f0-9]{8}$', test_id))

# 4.6 Pipeline stage toggling
# Test that disabling stages in definition.json actually skips them
```

### 5. STAMPER (stamper.py)

```python
from stamper import stamp_empty, stamp_from_source, validate_capsule, restamp
import tempfile

with tempfile.TemporaryDirectory() as tmp:
    # 5.1 Stamp empty capsule
    path = stamp_empty("Test Agent", tmp)
    test_stamp_valid = validate_capsule(path)["valid"]
    # Should be True, all 5 files present

    # 5.2 Verify file naming convention
    files = [f.name for f in path.iterdir()]
    test_files_prefixed = all(f.startswith(path.name) for f in files)

    # 5.3 Stamp from markdown source
    # Create a temp .md file
    md_file = Path(tmp) / "test_kb.md"
    md_file.write_text("# Test Knowledge\n\nSome content here.")
    path2 = stamp_from_source("KB Agent", str(md_file), tmp)
    test_source_kb = (path2 / f"{path2.name}-kb.md").read_text()
    # Should contain "Some content here"

    # 5.4 Stamp from JSON-LD source
    jsonld_file = Path(tmp) / "test_kg.jsonld"
    jsonld_file.write_text('{"@context": {}, "@graph": [{"@id": "test"}]}')
    path3 = stamp_from_source("KG Agent", str(jsonld_file), tmp)
    # KG should contain the test node

    # 5.5 Restamp with lineage
    path4 = restamp(path, "1.1.0")
    manifest = json.loads((path4 / f"{path4.name}-manifest.json").read_text())
    test_lineage = "previous_id" in manifest and "previous_version" in manifest
    # Should track lineage

    # 5.6 Validate invalid folder
    test_invalid = validate_capsule(Path(tmp) / "nonexistent")
    # Should return valid=False
```

### 6. EDUCATION QUEUE (education.py)

```python
from education import queue_failure, get_queue, get_pending, update_status
from education import queue_stats, get_oldest_pending, _parse_json_response, _build_research_prompt

import tempfile

with tempfile.TemporaryDirectory() as tmp:
    capsule = Path(tmp) / "test-capsule"
    capsule.mkdir()

    # 6.1 Queue a failure
    aec_result = {
        "score": 0.4, "threshold": 0.8, "passed": False,
        "gaps": [{"text": "Wrong date", "reason": "values_not_in_kg"}]
    }
    record = queue_failure(capsule, "Test query", "Test response", aec_result)
    test_queue_record = record["status"] == "pending" and record["aec_score"] == 0.4

    # 6.2 Get pending
    pending = get_pending(capsule)
    test_pending_count = len(pending) == 1

    # 6.3 Update status
    update_status(capsule, record["id"], "researching")
    test_status_change = get_queue(capsule)[0]["status"] == "researching"

    # 6.4 Queue stats
    stats = queue_stats(capsule)
    test_stats = stats["total"] == 1 and stats["researching"] == 1

    # 6.5 Get oldest pending (should be None since we changed status)
    queue_failure(capsule, "Query 2", "Response 2", aec_result)
    oldest = get_oldest_pending(capsule)
    test_oldest = oldest is not None and oldest["query"] == "Query 2"

    # 6.6 Parse JSON response (research output parsing)
    test_parse_clean = _parse_json_response('[{"subject": "A", "predicate": "B", "object": "C"}]')
    test_parse_markdown = _parse_json_response('```json\n[{"subject": "A", "predicate": "B", "object": "C"}]\n```')
    test_parse_garbage = None
    try:
        _parse_json_response("This is not JSON at all")
        test_parse_garbage = "FAIL — should have raised"
    except:
        test_parse_garbage = "PASS"

    # 6.7 Build research prompt
    prompt = _build_research_prompt([{"text": "Jefferson was born in 1750"}])
    test_prompt_contains = "Jefferson" in prompt and "JSON" in prompt
```

### 7. HABITAT (habitat.py)

```python
from habitat import Habitat

h = Habitat()

# 7.1 Register capsules
h.register("agent-001", {"name": "Agent One", "scent_subscriptions": ["topic.a", "topic.b"]})
h.register("agent-002", {"name": "Agent Two", "scent_subscriptions": ["topic.b", "topic.c*"]})

test_list = len(h.list_capsules()) == 2

# 7.2 Exact route
test_route_exact = h.route("topic.a")  # Should return ["agent-001"]

# 7.3 Wildcard route
test_route_wildcard = h.route("topic.cats")  # Should match "topic.c*" → ["agent-002"]

# 7.4 Multi-match route
test_route_multi = h.route("topic.b")  # Should return both agents

# 7.5 No match
test_route_none = h.route("unknown.topic")  # Should return []

# 7.6 Gap detection
test_gap = h.detect_gaps("unknown.topic")  # Should be True

# 7.7 Broadcast
result = h.broadcast("topic.a", {"data": "test"})
test_broadcast = len(result["recipients"]) > 0

# 7.8 Stats
test_stats = h.stats()["capsules"] == 2

# 7.9 Unregister
h.unregister("agent-001")
test_unregister = len(h.list_capsules()) == 1

# 7.10 Log
test_log = len(h.get_log()) > 0
```

### 8. LLM (llm.py)

```python
from llm import call_llm, make_llm_fn, estimate_cost

# 8.1 Stub provider
result = call_llm("Hello world", provider="stub")
test_stub = "text" in result and result["cost"] == 0.0

# 8.2 make_llm_fn returns callable
fn = make_llm_fn(provider="stub")
result = fn("Test prompt")
test_fn = isinstance(result, dict) and "text" in result

# 8.3 Unknown provider
result = call_llm("Hello", provider="fake_provider")
test_unknown = "Error" in result["text"] or "Unknown" in result["text"]

# 8.4 Cost estimation
cost = estimate_cost("claude-sonnet-4-20250514", 1000, 500)
test_cost = cost > 0

# 8.5 Missing API key handling (don't actually call API)
# Just verify it doesn't crash
result = call_llm("Hello", provider="anthropic", api_key="invalid_key_test")
test_api_error = "Error" in result["text"] or result["tokens_in"] == 0
```

### 9. REPORT (report.py)

```python
# Test report generation doesn't crash with mock data
from report import print_report
import io, sys

# Capture stdout
old_stdout = sys.stdout
sys.stdout = buffer = io.StringIO()

# Use mock data (from report.py's own __main__ block)
mock_ctx = {
    "input": "What is Aether?",
    "distilled": {"intent": "query", "entities": ["Aether"], "brevity": False, "format": None},
    "augmented": {"kb": ["Test para"], "kg": [{"@id": "test", "rdfs:label": "Test"}]},
    "generated": "Aether is a framework.",
    "review": {"passed": True, "aec": {"score": 0.85, "threshold": 0.8, "passed": True,
               "grounded_statements": 2, "ungrounded_statements": 0, "persona_statements": 1}},
    "telemetry": {"total_ms": 1234.5, "stages": {
        "distill": {"time_ms": 0.5, "entities_extracted": 1},
        "augment": {"time_ms": 1.2, "kb_matches": 1, "kg_matches": 1},
        "generate": {"time_ms": 1230.0, "prompt_chars": 150, "tokens_in": 50, "tokens_out": 100},
        "review": {"time_ms": 0.3},
    }}
}
mock_aec = mock_ctx["review"]["aec"]

class MockCapsule:
    id = "test-agent-v1.0.0-abc12345"
    name = "Test Agent"
    version = "1.0.0"
    files = {
        "manifest": {"id": "test-agent", "name": "Test Agent", "version": "1.0.0"},
        "persona": {"tone": "professional", "style": "concise"},
        "definition": {"review": {"threshold": 0.8}},
        "kb": "# Test\n\nContent.",
        "kg": {"@graph": [{"@id": "test", "rdfs:label": "Test"}]},
    }

try:
    print_report(mock_ctx, mock_aec, MockCapsule())
    test_report = "PASS"
except Exception as e:
    test_report = f"FAIL: {e}"

report_output = buffer.getvalue()
sys.stdout = old_stdout

test_report_has_header = "AETHER" in report_output
test_report_has_score = "Score" in report_output or "score" in report_output
test_report_length = len(report_output)
```

### 10. CAPSULE FILE INTEGRITY

For each example capsule, verify:
```python
# 10.1 All 5 files present and parseable
# 10.2 manifest.json has "id" and "version"
# 10.3 definition.json has "pipeline" section
# 10.4 persona.json parses as valid JSON
# 10.5 kb.md is non-empty
# 10.6 kg.jsonld has "@graph" array
# 10.7 All filenames match folder name prefix
# 10.8 KG node count per capsule
# 10.9 KB character count per capsule
# 10.10 Education queue status per capsule (if exists)
```

### 11. CROSS-MODULE INTEGRATION

```python
# 11.1 Full pipeline: Capsule.run() → AEC verify → education queue
# Run jefferson capsule with stub, verify AEC runs, check if queue triggered

# 11.2 AEC → Education → KG round-trip
# Queue a fake failure, verify it appears in pending, verify education prompt builds correctly

# 11.3 Stamp → Load → Run → Verify cycle
# Stamp a new capsule, load it, run a query, verify it completes without error

# 11.4 Habitat → Route → Capsule lookup
# Register capsules in habitat, route a topic, verify correct capsules matched
```

### 12. KNOWN ISSUES VERIFICATION

Explicitly test and document the status of these known bugs:
```python
# 12.1 Magnitude extraction: Does "$25 million" extract as 25000000? (Deferred item 5.6)
# 12.2 Augment top-3 cutoff: Does a relevant paragraph get missed? (Known bug #3)
# 12.3 Name matching looseness: Does "Thomas" match "Thomas Jefferson"? (Deferred item 3)
# 12.4 Buffett AEC score: What does the Buffett capsule actually score on its own KG?
# 12.5 Jefferson education queue: Are there existing pending items? What are their scores?
```

---

## REPORT FORMAT

Generate the report as markdown with these sections:

```markdown
# AETHER System Diagnostic Report
## Generated: 2026-03-09 [timestamp]
## Framework Version: Phase 2

### Executive Summary
- Total tests: N
- Passed: N
- Failed: N
- Warnings: N (known issues confirmed)

### Module Health
| Module | Import | Self-Test | Notes |
|--------|--------|-----------|-------|

### AEC Verification Tests
| Test | Expected | Actual | Status |
|------|----------|--------|--------|

### Knowledge Graph Tests
[same format]

### Capsule & Pipeline Tests
[For each capsule: load status, pipeline results, AEC score, telemetry]

### Stamper Tests
[same format]

### Education Queue Tests
[same format]

### Habitat Tests
[same format]

### LLM Tests
[same format]

### Report Generator Tests
[same format]

### Cross-Module Integration
[same format]

### Known Issues Status
| Issue | Deferred Item | Status | Details |
|-------|---------------|--------|---------|
| Magnitude extraction | 5.6 | CONFIRMED/FIXED | actual behavior |
| Augment top-3 | #3 | CONFIRMED/FIXED | actual behavior |
| Name matching | 3 | CONFIRMED/FIXED | actual behavior |

### Capsule Inventory
| Capsule | Files | KB Size | KG Nodes | Education Queue | AEC Score (stub) |
|---------|-------|---------|----------|-----------------|-------------------|

### Codebase Metrics
- Total Python files: N
- Total lines: N (count actual lines per file)
- External dependencies: [list]
- Python version required: 3.11+

### Recommendations
[Based on test results, what should be fixed first]
```

Save the report to: `IGNORE/daily/AETHER_SYSTEM_REPORT_2026-03-09.md`

---

## EXECUTION NOTES

- Run from the project root: `C:\Users\I820965\dev\aether`
- Use `provider="stub"` for all pipeline tests
- Do NOT call actual LLM APIs unless explicitly testing API connectivity
- Capture ALL output — don't skip failing tests
- If a test crashes, catch the exception and record it as a failure with the traceback
- Count actual lines per file using `wc -l` equivalent
- The report should be self-contained — someone reading it should understand the full system state without additional context
