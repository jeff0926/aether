# AETHER: A Self-Verifying Agent Framework Using Knowledge Graph-Grounded Entailment Checking

**Adaptive Embodied Thinking Holistic Evolutionary Runtime**

---

**Version:** 1.0
**Date:** March 2026
**Status:** Phase 1 Complete — Core Framework

---

## Abstract

This paper presents AETHER (Adaptive Embodied Thinking Holistic Evolutionary Runtime), a minimal agent framework that addresses the fundamental challenge of distinguishing between knowledge-grounded and persona-generated content in large language model (LLM) outputs. The framework introduces a capsule-based agent architecture where each agent is defined as a self-contained folder of five files — manifest, definition, persona, knowledge base, and knowledge graph — and runs queries through a four-stage pipeline: Distill, Augment, Generate, and Review. The Review stage employs the Aether Entailment Check (AEC), a deterministic verification gate that evaluates LLM responses against the knowledge graph subgraph used during generation. AEC categorizes each statement in a response as grounded, ungrounded, or persona-contributed, producing a quantitative score representing the proportion of verifiable claims traceable to the agent's knowledge. The framework was implemented in 1,147 lines of Python using only the standard library, with no external frameworks, vector databases, or embedding models. Empirical testing against a Thomas Jefferson Scholar Agent demonstrated precise discrimination across three grounding scenarios: full grounding (AEC score 1.0), partial knowledge gap (0.6), and severe knowledge gap (0.111). Framework processing overhead averaged 0.27 milliseconds across all tests, with 100% of user-perceived latency attributable to the LLM API. The results validate that knowledge grounding and verification can be achieved through structural entity matching against knowledge graph data rather than through text similarity methods, which were found to fail consistently on paraphrased and numerically approximate content in prior experimental work.

---

## 1. Introduction

### 1.1 The Attribution Problem

The deployment of AI agents in specialized applications — education, enterprise advisory, compliance, research — requires a clear understanding of response provenance. When an agent generates a response, the output is a synthesis of two sources: structured knowledge retrieved from the agent's knowledge base, and generative content produced by the underlying LLM from its training data. This dual nature creates a fundamental attribution problem: without a mechanism to distinguish between grounded and generated content, it is impossible to determine whether an agent is providing verified information or plausible-sounding hallucinations.

This problem is particularly acute in high-stakes domains where factual accuracy is not merely desirable but legally or professionally required. A certification preparation agent that generates study materials must ground its content in verified source material. A financial advisory agent must base its recommendations on documented data. A compliance agent must cite specific regulations. In each case, the proportion of the response attributable to verified knowledge versus LLM-generated inference is a critical quality metric.

### 1.2 Limitations of Existing Approaches

Current agent frameworks address grounding primarily through Retrieval-Augmented Generation (RAG), where relevant documents are retrieved from a vector store and provided as context for LLM generation. While RAG improves factual accuracy compared to ungrounded generation, it does not solve the attribution problem. The LLM may selectively use, paraphrase, extend, or ignore the retrieved context. Post-generation verification is typically limited to semantic similarity comparisons between the response and the retrieved documents.

Experimental testing conducted across five prototype implementations totaling approximately 55,000 lines of code revealed that text-based similarity methods — including cosine similarity on embeddings, TF-IDF matching, and string comparison — fail systematically on three categories of content:

- **Numerical approximation:** "The S&P 500 returns about 10%" versus "The S&P 500 has historically returned an average of 10% annually" produces low similarity scores despite conveying the same fact, because surface-level text differs significantly.
- **Paraphrased content:** LLMs routinely restructure and rephrase retrieved content, producing semantically equivalent but textually different outputs that score poorly on string and embedding comparisons.
- **Unit and format variation:** "72 degrees" versus "72°F" fails text matching despite representing identical information.

These failures are not edge cases. They represent the normal behavior of LLMs when generating from context. Any verification system based on text similarity will systematically undercount grounding, producing false negatives that either trigger unnecessary remediation or undermine trust in the verification mechanism itself.

### 1.3 Contribution

AETHER addresses the attribution problem through three contributions:

1. **The capsule model:** A self-contained agent definition consisting of five files in a folder, providing the agent with identity (manifest), behavior (definition), personality (persona), unstructured knowledge (knowledge base), and structured knowledge (knowledge graph). This model treats agent creation as a graduation process: a simple skill file can function independently, and is promoted to a full capsule only when the use case warrants it.

2. **The Aether Entailment Check (AEC):** A deterministic verification gate that evaluates LLM responses against the knowledge graph subgraph used during generation. Instead of comparing response text to knowledge base text, AEC extracts verifiable values (numbers, dates, names, percentages) from each statement in the response and matches them against flattened KG node values. This structural comparison is immune to the paraphrasing, approximation, and formatting issues that defeat text-based similarity.

3. **A minimal implementation:** The complete framework is implemented in 1,147 lines of Python using only the standard library. No vector databases, embedding models, or external frameworks are required. The implementation demonstrates that knowledge grounding and verification do not require heavyweight infrastructure.

---

## 2. Background and Related Work

### 2.1 Retrieval-Augmented Generation

Retrieval-Augmented Generation (RAG) augments LLM generation with retrieved context from external knowledge stores. The standard RAG pipeline embeds queries and documents into a shared vector space, retrieves the most similar documents, and provides them as context for generation. GraphRAG extends this approach by retrieving structured subgraphs from knowledge graphs rather than flat document chunks, achieving significantly higher accuracy — 86.31% compared to 32.74%–75.89% for traditional vector RAG — and supporting multi-hop queries across interconnected relationships.

AETHER builds on the GraphRAG insight that structured knowledge representation enables more precise retrieval and verification than vector-based approaches. However, AETHER diverges from traditional RAG in a critical way: the knowledge graph is used not only for retrieval (during the Augment stage) but also as the verification substrate (during the Review stage). The same subgraph that grounds the LLM's generation also serves as the reference for post-generation entailment checking.

### 2.2 LLM Output Attribution

Attribution methods for LLM outputs fall into several categories:

- **Feature attribution:** Identifies which input features (prompt tokens, retrieved context) most influenced specific output tokens. Primarily diagnostic; does not produce a quantitative grounding score.
- **Prompt-based detection:** Instructs the LLM to self-classify its statements as grounded or hallucinated by comparing against provided context. Subject to the same biases and hallucination patterns as the generation itself — the LLM cannot objectively evaluate its own output.
- **Semantic similarity detection:** Generates embeddings for response sentences and context, computing similarity scores. Fails on paraphrasing, numerical approximation, and format variation as documented in Section 1.2.
- **Factual consistency metrics:** Evaluates atomic facts against a ground truth source using metrics such as FactScore, Exact Match (EM), and Precision/Recall/F1. Requires a structured ground truth and may be overly rigid (EM) or miss semantic nuances.
- **Consistency across samples:** Generates multiple responses for the same query; high variance suggests hallucination (SelfCheckGPT). Indirect indicator that does not attribute to specific sources.

AETHER's AEC process combines elements of factual consistency metrics with a structural approach. Rather than evaluating free-text statements against free-text context (which requires semantic interpretation), AEC evaluates extracted values against structured KG node data (which requires only type-aware comparison). This eliminates the interpretation layer where existing methods fail.

### 2.3 Self-Improving Agent Systems

The concept of agents that improve through operational feedback has been explored in several paradigms. Automated Design of Agentic Systems (ADAS) proposes meta-agents that iteratively program, evaluate, and refine new agents. The ReAct paradigm implements reasoning-action loops where agents update their context through observation. Iterative refinement techniques systematically improve solutions through successive approximations.

AETHER's AEC process incorporates a self-education mechanism (implemented as a stub in Phase 1, with full implementation planned for Phase 2) where responses that fail the grounding threshold enter an asynchronous education queue. The system researches the identified knowledge gaps, validates new knowledge through AEC, and integrates it into the knowledge graph's "acquired" zone — distinct from the immutable "core" zone containing original source material. This design ensures that self-education cannot corrupt foundational knowledge while allowing the agent's capabilities to expand through use.

---

## 3. Architecture

### 3.1 The Capsule Model

An AETHER agent is defined as a **capsule** — a directory containing exactly five files that collectively specify the agent's identity, behavior, knowledge, and personality. The capsule is self-contained and portable: copying the directory copies the complete agent.

| File | Purpose | Format | Mutability |
|------|---------|--------|------------|
| `{name}-manifest.json` | Identity: unique ID, name, version, creation date, lineage | JSON | Updated on restamp only |
| `{name}-definition.json` | Behavior: agent type, domain boundaries, pipeline config, AEC gates and thresholds | JSON | Configurable |
| `{name}-persona.json` | Personality: tone, style, interaction traits, character description, constraints | JSON | Configurable |
| `{name}-kb.md` | Unstructured knowledge: the agent's domain content in markdown | Markdown | Immutable (core) |
| `{name}-kg.jsonld` | Structured knowledge: entities, relationships, and provenance in JSON-LD | JSON-LD | Core zone immutable; acquired zone mutable |

The file naming convention prefixes all files with the agent's folder name, ensuring that files are identifiable outside their directory context. The manifest includes a unique identifier generated from the agent name, version, and timestamp: `{slug}-v{version}-{uid8}`.

#### 3.1.1 The Graduation Model

The capsule model is designed as a graduation path rather than an all-or-nothing architecture:

1. **Stage 1 — Skill file:** A single markdown file (e.g., a Claude skill.md) that defines what an agent does. Functional without any framework.
2. **Stage 2 — Stamped capsule:** When the skill proves reliable, it is stamped into a capsule with the additional files the configuration requires. The original skill file becomes the KB.
3. **Stage 3 — AEC-validated:** The capsule runs with AEC verification. Failures are logged and feed the education queue.
4. **Stage 4 — KG-projected:** The proven agent's capabilities are projected into the knowledge graph for orchestrator discovery and multi-agent composition.

Complexity increases only when value justifies it. A developer writing a skill file is already on Stage 1.

#### 3.1.2 Stamping and Versioning

Capsules are created through a stamping process that generates the folder structure and populates files with either defaults or source material. The stamper accepts markdown files as KB input, JSON-LD files as KG input, and JSON files as definition input. Each stamp produces a unique folder name with an embedded version and hash:

```
jefferson-v1.0.0-a3f7c2d1/
├── jefferson-v1.0.0-a3f7c2d1-manifest.json
├── jefferson-v1.0.0-a3f7c2d1-definition.json
├── jefferson-v1.0.0-a3f7c2d1-persona.json
├── jefferson-v1.0.0-a3f7c2d1-kb.md
└── jefferson-v1.0.0-a3f7c2d1-kg.jsonld
```

Restamping creates a new versioned copy with lineage tracking in the manifest (`previous_version`, `previous_id`). The original capsule is never modified.

### 3.2 The Pipeline

Every query is processed through a four-stage sequential pipeline. Each stage receives a shared context dictionary, adds its results, and passes it forward. No stage has side effects outside the context dictionary except Generate, which makes a single external LLM API call.

#### Stage 1: Distill

**Purpose:** Extract structured intent from unstructured input.

**Operations:**
- Intent classification (query, instruction, comparison, creation, general) via keyword matching
- Named entity extraction via regex-based capitalized word detection
- Format constraint detection (list, table, JSON)
- Brevity flag detection

**Output:** `ctx["distilled"]` containing intent, entities list, format preference, and brevity flag.

**Design rationale:** The distill stage uses simple keyword and regex patterns rather than NLP models. This is a deliberate trade-off: zero-dependency entity extraction is less accurate than NER models but adds zero latency and zero dependencies. For the augment stage's purpose — finding matching KB paragraphs and KG nodes — capitalized word extraction provides sufficient signal.

#### Stage 2: Augment

**Purpose:** Retrieve relevant knowledge context for grounding the LLM generation.

**Operations:**
- KB paragraph search: splits the markdown KB into paragraphs, scores each by entity overlap with the distilled entities, returns the top matches
- KG node search: iterates all KG nodes, performs recursive string matching against node values, returns matching nodes
- Persona assembly: extracts tone and style from the persona file

**Output:** `ctx["augmented"]` containing matched KB paragraphs, matched KG nodes, and persona settings.

**Design rationale:** The augment stage performs exhaustive search rather than indexed retrieval. For knowledge graphs under 100 nodes and knowledge bases under 100 paragraphs, exhaustive search completes in under 0.3 milliseconds. This eliminates the need for vector indices, embedding models, or graph databases while maintaining adequate performance for the target capsule sizes.

#### Stage 3: Generate

**Purpose:** Construct a grounded prompt and obtain an LLM response.

**Operations:**
- Prompt construction: assembles agent name, persona instructions, KB context paragraphs, KG node labels, and the original query into a structured prompt
- LLM invocation: calls the configured LLM provider with the constructed prompt
- Token tracking: records input tokens, output tokens, and estimated cost from the API response

**Output:** `ctx["generated"]` containing the LLM response text; token counts and cost added to `ctx["telemetry"]`.

**Design rationale:** The prompt is constructed to front-load identity and grounding context before the query. KB matches are truncated to 200 characters to manage token count. KG nodes are represented by their labels rather than full JSON to reduce token consumption while preserving entity awareness.

#### Stage 4: Review

**Purpose:** Verify that the generated response is grounded in the knowledge provided during augmentation.

**Operations:**
- Statement splitting: regex-based sentence boundary detection with abbreviation protection
- Value extraction: regex patterns for numbers, percentages, dates (year and full format), and capitalized names
- KG flattening: recursive extraction of all values from all KG nodes into a searchable flat index
- Per-statement matching: type-aware comparison of extracted values against the flat KG index
- Score calculation: ratio of grounded statements to total verifiable statements

**Output:** `ctx["review"]` containing AEC score, pass/fail determination, per-statement categorization, and gap list.

**Design rationale:** The review stage is detailed in Section 3.3.

### 3.3 The Aether Entailment Check (AEC)

#### 3.3.1 Design Principles

AEC is founded on three principles derived from empirical testing:

1. **Structural comparison over textual similarity.** Comparing response text to KB text fails because LLMs paraphrase, approximate, and restructure content. Comparing extracted values to structured KG data succeeds because the comparison is between canonical representations, not surface forms.

2. **The evaluation substrate is the generation substrate.** The KG subgraph used to ground the LLM's generation (retrieved during Augment) is the same subgraph used to verify the response (during Review). This eliminates the need for a separate evaluation knowledge base and ensures that the verification scope exactly matches the generation scope.

3. **The deterministic gate cannot be overridden.** When AEC's deterministic matching determines that a numerical claim does not match any KG node value, that determination is final. No LLM self-assessment or confidence score can override a structural mismatch. This principle addresses the documented failure mode where LLMs assign high confidence to numerically imprecise claims.

#### 3.3.2 Statement Categorization

AEC categorizes each statement in the response into one of three categories:

| Category | Definition | Scoring Impact |
|----------|-----------|---------------|
| **Grounded** | Contains extractable verifiable values (numbers, dates, names, percentages) that match corresponding values in the KG subgraph | Counts as grounded in the score numerator and denominator |
| **Ungrounded** | Contains extractable verifiable values that do not match any KG node value | Counts in the denominator only — reduces the score |
| **Persona** | Contains no extractable verifiable values — qualitative, interpretive, or transitional content | Excluded from the score calculation entirely |

The scoring formula is:

```
AEC Score = grounded / (grounded + ungrounded)
```

Persona statements are excluded because they represent the expected interpretive contribution of the agent's personality. A response that is 60% factual claims and 40% interpretive framing is expected behavior. The AEC score evaluates only whether the factual claims are grounded, not whether the response contains interpretation.

#### 3.3.3 The 80% Threshold

The AEC threshold is set at 0.80 (80%), reflecting an 80/20 design principle: at least 80% of the verifiable content in a response must be traceable to the agent's knowledge graph. The remaining 20% allows for legitimate LLM contributions such as synthesis, contextual framing, and reasonable inference from provided facts.

When a response scores below the threshold, it indicates that the agent generated verifiable claims from its training data rather than from its knowledge base. The response may be factually correct — the agent was "guessing correctly" — but it was not operating within the boundaries of its verified knowledge. This distinction is critical for trust: a correct guess today may be an incorrect guess tomorrow, while a grounded response is as reliable as the knowledge it draws from.

#### 3.3.4 Deterministic Gate Implementation

The deterministic gate extracts and matches four types of verifiable values:

| Value Type | Extraction Pattern | Matching Logic |
|-----------|-------------------|----------------|
| **Numbers** | Integer and decimal patterns with comma grouping (e.g., `1743`, `3,000`, `3.14`) | Numeric comparison with 1% tolerance (`abs(value - kv) <= abs(kv * 0.01) + 0.001`) |
| **Percentages** | Digits followed by `%`, `percent`, or `pct` | Numeric comparison of the percentage value |
| **Dates** | Four-digit years (1700–2099); full dates normalized to ISO format (`April 13, 1743` → `1743-04-13`) | String comparison of normalized representation |
| **Names** | Capitalized word sequences excluding common pronouns and articles | Case-insensitive partial string matching against all KG string values |

The KG flattening process recursively extracts all values from all nodes into a flat `{key: [values]}` dictionary, enabling O(n×m) matching where n is the number of extracted values and m is the number of KG values. For typical subgraphs of 5–30 nodes, this completes in under 0.05 milliseconds.

#### 3.3.5 Knowledge Graph Zones

The knowledge graph maintains two distinct zones to ensure that self-education cannot corrupt foundational knowledge:

| Zone | Origin | Mutability | Metadata |
|------|--------|-----------|----------|
| **Core** | Original source material at stamp time | Immutable | No `aether:origin` tag or `aether:origin: "core"` |
| **Acquired** | AEC self-education loop | Prunable | `aether:origin: "acquired"`, `aether:confidence`, `aether:acquired_date`, `aether:aec_trigger` |

Core nodes are never modified by any automated process. Acquired nodes carry full provenance metadata and can be pruned if their reinforcement score degrades. This separation provides an audit trail, enables rollback, and ensures that hallucinations introduced through the education process are always identifiable and removable.

---

## 4. Implementation

### 4.1 Framework Composition

The AETHER framework consists of seven Python source files totaling 1,147 lines of code:

| File | Lines | Responsibility |
|------|-------|---------------|
| `aether.py` | 263 | Capsule class, pipeline runner, ID generation, folder validation |
| `aec.py` | 244 | Statement splitting, value extraction, KG flattening, deterministic matching, score calculation |
| `kg.py` | 145 | JSON-LD loading, node querying, core/acquired zone management, KG persistence |
| `stamper.py` | 130 | Empty capsule creation, source-based stamping, validation, restamping with lineage |
| `habitat.py` | 134 | Capsule registry, topic-based routing with wildcard support, gap detection, message logging |
| `llm.py` | 103 | LLM API wrapper (Anthropic, OpenAI, stub), .env loading, token tracking, cost estimation |
| `cli.py` | 128 | Command-line interface: stamp, run, validate, info subcommands |

### 4.2 Dependencies

The framework requires only the Python 3.11+ standard library for core functionality. The `anthropic` and `openai` SDKs are optional dependencies required only for LLM API calls. A built-in stub provider enables full pipeline testing without any external dependencies or API keys.

### 4.3 Design Constraints

The implementation adheres to five design constraints established at the outset:

1. **No file exceeds 300 lines.** If a file grows beyond this limit, it is doing too much and must be decomposed.
2. **No frameworks.** No Pydantic, no async/await, no CBOR serialization, no dependency injection. Configuration is loaded as plain dictionaries via `json.load()`.
3. **No vector operations.** No embedding models, no cosine similarity, no numpy. Knowledge retrieval uses keyword matching and entity overlap scoring.
4. **Capsule is a folder.** The framework reads directories. There is no database, no registry server, no external state store.
5. **If it is not needed to create, stamp, run, or improve a capsule, it does not exist.**

### 4.4 Test Agent: Thomas Jefferson Scholar Agent

The framework was validated using a Thomas Jefferson Scholar Agent constructed from a deep research paper generated through a structured prompt template (Deep Research Prompt v2.0). The research paper was generated using Gemini Deep Research and covered Jefferson's biography, the drafting of the Declaration of Independence, his diplomatic residency in France (1784–1789), published works, philosophical frameworks, controversies, and legacy.

The capsule was constructed by decomposing the research output into the five capsule files:

| File | Content | Size |
|------|---------|------|
| `jefferson-manifest.json` | Agent identity and version | 462 bytes |
| `jefferson-definition.json` | Scholar type, 9 authoritative domains, 3 AEC gates | 1,215 bytes |
| `jefferson-persona.json` | Formal/academic tone, 6 interaction traits, 5 character traits | 1,526 bytes |
| `jefferson-kb.md` | 85 paragraphs of deep research content | 28,810 bytes |
| `jefferson-kg.jsonld` | 43 graph nodes, 37 relationship triples, 13 registered entities | 16,939 bytes |

Total capsule size: 48,952 bytes (47.8 KB).

The knowledge graph includes entity types spanning Person (10 nodes), Location (6), Work (7), Organization (3), Event (3), Concept (5), TimePeriod (1), and Role (5), with relationship predicates including AUTHORED, BORN_IN, TRAVELED_TO, SERVED_AS, COLLABORATED_WITH, INFLUENCED, FOUNDED, MARRIED, ADVOCATED, WITNESSED, SUCCEEDED, and DERIVED_FROM.

---

## 5. Results

### 5.1 Experimental Design

Three queries were selected to test the full spectrum of grounding scenarios:

| Query | Expected Outcome | Rationale |
|-------|-----------------|-----------|
| "When was Thomas Jefferson born?" | Full grounding | All verifiable claims (date, location, name) exist in the KG |
| "What were the key disagreements between Thomas Jefferson and Alexander Hamilton?" | Partial grounding failure | Alexander Hamilton is not in the KG; Jefferson-related claims will ground, Hamilton-related claims will not |
| "What happened during the Louisiana Purchase and how much did it cost?" | Severe grounding failure | KG has only one node with two data points (year: 1803, cost: $15M); detailed content will be LLM-generated |

All queries were run against the Thomas Jefferson Scholar Agent using Claude Sonnet (claude-sonnet-4-20250514) as the LLM provider.

### 5.2 Run 1: Full Grounding (PASS)

**Query:** "When was Thomas Jefferson born?"

| Metric | Value |
|--------|-------|
| AEC Score | 1.000 |
| Threshold | 0.800 |
| Result | PASS |
| Total Statements | 4 |
| Grounded | 4 |
| Ungrounded | 0 |
| Persona | 0 |
| Persona Ratio | 0.0% |

**Augment Retrieval:** 4 KB paragraphs matched (of 85 searched), 6 KG nodes matched (of 43 searched).

**Tokens:** 847 input, 282 output, 1,129 total.

**Timing:** 389ms total (0.1ms Aether, 389ms LLM).

**Analysis:** All four statements contained verifiable values that matched KG nodes. "April 13, 1743" matched `birth_date: 1743-04-13`; "1743" matched `birth_year: 1743`; "Virginia" and "Shadwell" matched location nodes. The high input token count (847) reflects the rich grounding context provided by the augment stage, which found both relevant KB paragraphs and multiple KG nodes.

### 5.3 Run 2: Partial Knowledge Gap (FAIL)

**Query:** "What were the key disagreements between Thomas Jefferson and Alexander Hamilton?"

| Metric | Value |
|--------|-------|
| AEC Score | 0.600 |
| Threshold | 0.800 |
| Result | FAIL |
| Total Statements | 11 |
| Grounded | 6 |
| Ungrounded | 4 |
| Persona | 1 |
| Persona Ratio | 9.1% |

**Augment Retrieval:** 3 KB paragraphs matched, 5 KG nodes matched.

**Tokens:** 189 input, 490 output, 679 total.

**Timing:** 15,597ms total (0.3ms Aether, 15,597ms LLM).

**Analysis:** Statements referencing Jefferson-related entities (strict constructionism, agrarian republic, yeoman farmers, France, republican ideals) were grounded against existing KG nodes. Statements referencing Hamilton-related entities (national bank, federal assumption of state debts, protective tariffs, British ties) were ungrounded because Alexander Hamilton has no node in the KG. The LLM generated historically accurate content about Hamilton entirely from its training data. The response is factually correct but 40% of its verifiable content is not traceable to the agent's knowledge.

**Gap Identification:** The AEC gap list identified four missing knowledge areas: Alexander Hamilton as a Person entity, the National Bank as a Concept, federal debt assumption as a policy event, and 1790s foreign policy context.

### 5.4 Run 3: Severe Knowledge Gap (FAIL)

**Query:** "What happened during the Louisiana Purchase and how much did it cost?"

| Metric | Value |
|--------|-------|
| AEC Score | 0.111 |
| Threshold | 0.800 |
| Result | FAIL |
| Total Statements | 10 |
| Grounded | 1 |
| Ungrounded | 8 |
| Persona | 1 |
| Persona Ratio | 10.0% |

**Augment Retrieval:** 0 KB paragraphs matched, 1 KG node matched.

**Tokens:** 46 input, 336 output, 382 total.

**Timing:** 11,109ms total (0.4ms Aether, 11,108ms LLM).

**Analysis:** The augment stage found zero relevant KB paragraphs and only one KG node (`event:louisiana_purchase` with `year: 1803` and `cost: "15 million dollars"`). The LLM received a 46-token prompt — essentially no grounding context — and generated a detailed, accurate response almost entirely from its training data. Only the "$15 million" claim matched the KG. All other verifiable claims (Napoleon, Robert Livingston, James Monroe, $10 million initial offer, $11.25 million direct payment, $3.75 million assumed debts, 828,000 square miles, three cents per acre, fifteen states) were historically correct but ungrounded.

**Gap Identification:** The AEC gap list identified eight missing knowledge areas, providing a precise curriculum for self-education.

### 5.5 Cross-Run Analysis

#### 5.5.1 Input Token Correlation

A strong inverse correlation was observed between input token count and AEC failure:

| Run | Tokens In | KB Matches | KG Matches | AEC Score |
|-----|-----------|------------|------------|-----------|
| 1 (birth) | 847 | 4/85 | 6/43 | 1.000 |
| 2 (Hamilton) | 189 | 3/85 | 5/43 | 0.600 |
| 3 (Louisiana) | 46 | 0/85 | 1/43 | 0.111 |

Input token count directly reflects the volume of grounding context retrieved during augmentation. A low token count indicates that the augment stage found little relevant knowledge, which predicts that the LLM will generate from training data rather than from provided context. This metric could serve as a predictive trigger for AEC failure, potentially enabling pre-generation intervention such as augmenting the query, expanding the subgraph, or flagging the response as potentially ungrounded before the LLM is even invoked.

#### 5.5.2 Framework Performance

| Metric | Run 1 | Run 2 | Run 3 | Average |
|--------|-------|-------|-------|---------|
| Aether processing time | 0.1ms | 0.3ms | 0.4ms | 0.27ms |
| LLM API time | 389ms | 15,597ms | 11,108ms | 9,031ms |
| Aether as % of total | 0.02% | 0.002% | 0.004% | 0.009% |

The framework performs 19 distinct operations — file parsing, intent classification, entity extraction, KB search (85 paragraphs), KG search (43 nodes), prompt construction, response splitting, value extraction, KG flattening, per-statement matching, score calculation, and gap identification — in under 0.5 milliseconds. This demonstrates that knowledge grounding and deterministic verification add zero practical overhead to the agent pipeline.

#### 5.5.3 Cost Analysis

At Claude Sonnet pricing ($3/million input tokens, $15/million output tokens):

| Run | Input Cost | Output Cost | Total Cost |
|-----|-----------|-------------|------------|
| 1 (birth) | $0.0025 | $0.0042 | $0.007 |
| 2 (Hamilton) | $0.0006 | $0.0074 | $0.008 |
| 3 (Louisiana) | $0.0001 | $0.0050 | $0.005 |

Average cost per query: $0.007. Projected daily cost at 1,000 queries/day: $7. Monthly: $210. At these price points, continuous AEC verification and background self-education loops are economically viable for production deployments.

---

## 6. Discussion

### 6.1 Structural Verification vs. Textual Similarity

The results demonstrate that structural entity matching against knowledge graph data provides reliable verification where text-based methods fail. The deterministic gate correctly identified "April 13, 1743" as matching KG node `birth_date: 1743-04-13` despite format differences — a comparison that would produce low scores in embedding-based similarity. Similarly, "$15 million" was correctly matched to the string value "15 million dollars" through numeric extraction and tolerance-based comparison.

The key insight is that verification should operate at the value level, not the text level. An LLM's response about a date does not need to textually match the knowledge base entry about that date. It needs to contain the same date value, regardless of formatting, surrounding prose, or sentence structure. By extracting values and comparing structurally, AEC sidesteps the fundamental limitation of text-based verification.

### 6.2 The Persona Exclusion

The decision to exclude persona statements from the AEC score proved critical for accurate grounding measurement. In Run 1, all four statements contained verifiable values. However, typical LLM responses include qualitative, interpretive, and transitional content that contains no extractable values. Without the persona exclusion, such statements would count as ungrounded and artificially deflate the score.

The persona ratio metric (reported but not scored) provides an additional diagnostic dimension. A consistently high persona ratio may indicate that the agent's knowledge base is too sparse for the queries it receives, causing the LLM to generate more interpretive filler. This metric could inform KB expansion priorities.

### 6.3 Limitations

**Entity extraction coverage.** The current regex-based extraction handles numbers, dates, percentages, and capitalized names. It does not extract or verify relationships between entities (e.g., "Jefferson authored the Declaration" — the AUTHORED relationship is not checked, only the entity names). Relationship verification would require a more sophisticated matching algorithm that compares extracted subject-predicate-object triples against KG edges.

**Name matching precision.** The bidirectional partial string matching used for names ("Thomas" matches "Thomas Jefferson") may produce false positive grounding. A statement mentioning "Thomas Paine" would incorrectly match against "Thomas Jefferson" through the partial match. Multi-token name matching with minimum overlap thresholds would improve precision.

**Cross-statement coreference.** Each statement is evaluated independently. "Jefferson was born in 1743. He authored the Declaration in 1776." — in the second statement, "He" refers to Jefferson, but the entity extraction yields only "Declaration" and "1776." Coreference resolution would improve recall for pronoun-heavy responses.

**Scope of deterministic verification.** AEC verifies that extracted values exist in the KG. It does not verify that the relationship between values in the statement matches the relationship in the KG. A statement claiming "Jefferson was born in 1776" would be scored as grounded because both "Jefferson" and "1776" exist in the KG, even though the relationship is incorrect. Relationship-aware verification is planned for Phase 2.

### 6.4 Generalizability

The capsule model and AEC process are domain-agnostic. The Thomas Jefferson Scholar Agent demonstrates the framework with historical content, but the same architecture applies to any domain where an agent's knowledge can be represented as a knowledge graph with typed entities and verifiable values. Financial advisory agents (with numerical claims about prices, returns, and ratios), compliance agents (with regulatory citations and dates), technical documentation agents (with version numbers, configuration values, and API specifications), and medical information agents (with dosages, frequencies, and diagnostic criteria) all produce responses with extractable verifiable values that can be matched against structured knowledge.

---

## 7. Conclusion

AETHER demonstrates that the AI agent attribution problem — distinguishing between knowledge-grounded and persona-generated content — can be solved through deterministic structural matching rather than probabilistic text similarity. The framework achieves this in 1,147 lines of Python with zero framework dependencies, processing 19 verification operations in under 0.5 milliseconds.

The capsule model provides a clean architectural pattern for self-contained agents that carry their own identity, knowledge, personality, and verification rules. The graduation from skill file to stamped capsule to AEC-validated agent to KG-projected capability mirrors the natural progression of software from prototype to production.

The empirical results across three grounding scenarios confirm that AEC correctly discriminates between fully grounded responses (1.0), partially grounded responses (0.6), and severely ungrounded responses (0.111), while the persona exclusion mechanism prevents qualitative content from distorting the grounding measurement.

Phase 1 establishes the core framework. Phase 2 will implement the self-education queue (where AEC failures generate curriculum for autonomous knowledge acquisition), the LLM self-scoring layer (adding a 60/40 hybrid with the deterministic gate), relationship-aware verification, and a visual dashboard for pipeline inspection and KG exploration.

---

## 8. Future Work

### 8.1 Phase 2: Self-Education Loop

The AEC education queue will process failed prompt-response pairs asynchronously. For each failure, the system will extract the specific knowledge gaps, conduct targeted research, validate the new knowledge through AEC, and integrate it into the KG's acquired zone with full provenance metadata. The education loop transforms failures from error reports into learning opportunities.

### 8.2 Phase 2: Hybrid Scoring

The 60/40 hybrid scoring model will combine the deterministic gate (40% weight, mandatory) with an LLM self-scoring layer (60% weight, optional). The LLM will be prompted to classify each statement as KB_GROUNDED or PERSONA_GENERATED given the KG subgraph context. The deterministic gate retains veto power: if it detects a value mismatch, the LLM's self-assessment cannot override.

### 8.3 Phase 2: Platform Export

Capsules will be exportable to multiple platform-specific formats including GitHub agent.md, Claude skill.md, OpenAI assistant definitions, and A2A agent cards. The capsule remains the canonical format; exports are one-way projections.

### 8.4 Phase 2: Dashboard

A browser-based dashboard served via `aether serve` will provide KG visualization (D3.js force-directed graph), pipeline execution inspection, AEC statement-level analysis, habitat topology, and test execution. Single HTML file, SSE for live updates, no framework dependencies.

### 8.5 Phase 3: Multi-Agent Composition

The habitat registry, pheromone routing, and gap detection mechanisms provide the foundation for multi-agent orchestration. An orchestrating agent reads the habitat registry to route queries to appropriate agents, detects gaps when no agent handles a topic, and triggers capsule creation to fill identified capability gaps.

---

## Appendix A: Complete File Inventory

| File | Lines | Imports | Purpose |
|------|-------|---------|---------|
| `aether.py` | 263 | json, re, hashlib, pathlib, time | Capsule class, 4-stage pipeline, ID generation |
| `aec.py` | 244 | re, json | Statement splitting, value extraction, deterministic gate |
| `kg.py` | 145 | json, pathlib, datetime | JSON-LD loading, zone management, persistence |
| `stamper.py` | 130 | json, shutil, pathlib, datetime, aether | Capsule creation, validation, restamping |
| `habitat.py` | 134 | datetime | Registry, routing, gap detection, message logging |
| `llm.py` | 103 | os, pathlib | API wrappers, .env loading, cost estimation |
| `cli.py` | 128 | argparse, json, pathlib | CLI subcommands |
| **Total** | **1,147** | | |

## Appendix B: Thomas Jefferson Scholar Agent — Knowledge Graph Statistics

| Entity Type | Count | Example Entities |
|-------------|-------|-----------------|
| Person | 10 | Thomas Jefferson, John Adams, Benjamin Franklin, John Locke, Sally Hemings |
| Work | 7 | Declaration of Independence, Notes on the State of Virginia, Garden Book |
| Location | 6 | Monticello, France, Paris, Virginia, Philadelphia, Nîmes |
| Role | 5 | President, Minister to France, Secretary of State, Vice President, Governor |
| Concept | 5 | Natural Rights, Agrarianism, Separation of Church and State, Strict Constructionism, Virginia Dynasty |
| Organization | 3 | University of Virginia, College of William and Mary, Continental Congress |
| Event | 3 | American Revolution, French Revolution, Louisiana Purchase |
| TimePeriod | 1 | Age of Enlightenment |
| **Total Nodes** | **43** | |
| **Total Triples** | **37** | |
| **Registered Entities** | **13** | |

---

*AETHER v0.1.0 — Adaptive Embodied Thinking Holistic Evolutionary Runtime*
*Phase 1 Complete — Core Framework*
*March 2026*
