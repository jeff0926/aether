# AETHER Architecture Reference

**Adaptive Embodied Thinking Holistic Evolutionary Runtime**

---

**Version:** 0.1.0 (Phase 1)
**Date:** March 2026
**Status:** Core Framework Complete

---

## 1. System Overview

AETHER is a 7-file Python framework for creating, stamping, running, and improving knowledge-grounded AI agents. Each agent is a self-contained directory (capsule) with 5 files. The framework processes queries through a 4-stage pipeline with deterministic post-generation verification.

### 1.1 Architecture Diagram

```
                         ┌──────────────────────────────┐
                         │         cli.py (128)          │
                         │    stamp │ run │ validate     │
                         └────┬─────┴──┬──┴──────┬──────┘
                              │        │         │
                    ┌─────────┘        │         └──────────┐
                    ▼                  ▼                    ▼
           ┌────────────────┐  ┌─────────────────┐  ┌──────────────┐
           │ stamper.py     │  │  aether.py      │  │ habitat.py   │
           │ (130)          │  │  (263)          │  │ (134)        │
           │                │  │                 │  │              │
           │ stamp_empty()  │  │ Capsule class   │  │ Habitat class│
           │ stamp_from()   │  │ run() pipeline  │  │ register()   │
           │ restamp()      │  │ distill()       │  │ route()      │
           │ validate()     │  │ augment()       │  │ broadcast()  │
           └────────┬───────┘  │ generate()      │  │ detect_gaps()│
                    │          │ review()        │  └──────────────┘
                    │          └──┬──────┬───────┘
                    │             │      │
                    │     ┌───────┘      └────────┐
                    │     ▼                       ▼
                    │  ┌──────────────┐    ┌────────────────┐
                    │  │  llm.py      │    │   aec.py       │
                    │  │  (103)       │    │   (244)        │
                    │  │              │    │                │
                    │  │ call_llm()   │    │ verify()       │
                    │  │ make_llm_fn()│    │ deterministic_ │
                    │  └──────────────┘    │   gate()       │
                    │                      │ split_         │
                    │                      │   statements() │
                    │                      └────────────────┘
                    │
                    ▼
              ┌──────────────┐
              │   kg.py      │
              │   (145)      │
              │              │
              │ load_kg()    │
              │ query_nodes()│
              │ add_acquired()│
              │ save_kg()    │
              └──────────────┘
```

### 1.2 Dependency Graph

```
cli.py
  ├── aether.py (Capsule, validate_folder, get_required_files)
  ├── stamper.py (stamp_empty, stamp_from_source, validate_capsule)
  ├── llm.py (make_llm_fn)
  ├── kg.py (load_kg, stats)
  └── aec.py (verify)

stamper.py
  └── aether.py (generate_id, REQUIRED_SUFFIXES)

aether.py ← no internal dependencies
aec.py ← no internal dependencies
kg.py ← no internal dependencies
habitat.py ← no internal dependencies
llm.py ← no internal dependencies
```

No circular dependencies. `aether.py`, `aec.py`, `kg.py`, `habitat.py`, and `llm.py` are leaf modules with zero internal imports.

---

## 2. File Specifications

### 2.1 aether.py (263 lines)

**Purpose:** Core capsule class and pipeline runner.

**Imports:** `json`, `re`, `hashlib`, `pathlib.Path`, `time`

#### Constants

```python
REQUIRED_SUFFIXES = {
    "manifest": "-manifest.json",
    "definition": "-definition.json",
    "persona": "-persona.json",
    "kb": "-kb.md",
    "kg": "-kg.jsonld",
}
```

#### Functions

| Function | Signature | Returns | Description |
|----------|-----------|---------|-------------|
| `get_required_files` | `(folder_name: str) -> dict` | `dict[str, str]` | Maps file keys to filenames using folder name as prefix |
| `generate_id` | `(name: str, version: str = "1.0.0") -> str` | `str` | Generates `{slug}-v{version}-{uid8}` from name + version + timestamp |
| `validate_folder` | `(path: str \| Path) -> list[str]` | `list[str]` | Returns list of missing required files |

#### Class: Capsule

```python
Capsule(path: str | Path, llm_fn: callable = None)
```

**Properties:**

| Property | Type | Source |
|----------|------|--------|
| `id` | `str` | `manifest["id"]` |
| `name` | `str` | `manifest["name"]` or `id` |
| `version` | `str` | `manifest["version"]` |
| `path` | `Path` | Constructor argument |
| `files` | `dict` | All 5 loaded files |

**Methods:**

| Method | Signature | Returns | Description |
|--------|-----------|---------|-------------|
| `run` | `(input_text: str) -> dict` | Context dict | Executes full 4-stage pipeline |
| `distill` | `(ctx: dict) -> dict` | Updated ctx | Extracts intent, entities, format, brevity |
| `augment` | `(ctx: dict) -> dict` | Updated ctx | Searches KB paragraphs and KG nodes |
| `generate` | `(ctx: dict) -> dict` | Updated ctx | Builds prompt, calls LLM |
| `review` | `(ctx: dict) -> dict` | Updated ctx | Basic length/grounding check |

**Context Dictionary Schema:**

```python
ctx = {
    "input": str,                    # Original query
    "distilled": {
        "intent": str,               # query|instruction|comparison|creation|general
        "entities": list[str],       # Extracted capitalized words
        "brevity": bool,             # True if brief/short/concise detected
        "format": str | None,        # list|table|json|None
    },
    "augmented": {
        "kb": list[str],             # Matched KB paragraphs (max 3)
        "kg": list[dict],            # Matched KG nodes (max 5)
        "persona": {
            "tone": str,
            "style": str,
        },
    },
    "generated": str,                # LLM response text
    "review": {
        "grounded": bool,
        "length_ok": bool,
        "passed": bool,
    },
    "meta": {
        "capsule_id": str,
        "version": str,
    },
    "telemetry": {
        "start": float,              # time.time()
        "total_ms": float,
        "stages": {
            "distill": {"time_ms": float, "entities_extracted": int},
            "augment": {"time_ms": float, "kb_matches": int, "kg_matches": int},
            "generate": {"time_ms": float, "prompt_chars": int,
                        "tokens_in": int, "tokens_out": int},
            "review": {"time_ms": float},
        },
    },
}
```

---

### 2.2 aec.py (244 lines)

**Purpose:** Aether Entailment Check — deterministic verification gate.

**Imports:** `re`, `json`

#### Constants

```python
DEFAULT_THRESHOLD = 0.8
```

#### Functions

| Function | Signature | Returns | Description |
|----------|-----------|---------|-------------|
| `split_statements` | `(response: str) -> list[str]` | `list[str]` | Regex sentence splitting with abbreviation protection |
| `deterministic_gate` | `(statement: str, kg_nodes: list[dict]) -> dict` | Gate result dict | Extract values, match against flattened KG |
| `verify` | `(response: str, kg_nodes: list[dict], threshold: float = 0.8) -> dict` | Verification result | Full verification pipeline |

**Internal Functions:**

| Function | Purpose |
|----------|---------|
| `_extract_values(text)` | Extract (original, normalized, type) tuples for numbers, percentages, dates, names |
| `_flatten_kg(kg_nodes)` | Recursively flatten KG nodes into `{key: [values]}` dict |
| `_match_in_kg(value, type, kg_flat, tolerance)` | Check single value against flat KG with type-aware matching |

**Gate Result Schema:**

```python
{
    "matched": bool,
    "entity": str | None,        # First matched value
    "method": str,               # deterministic_number|date|name|percentage|no_values|no_input
    "values_found": int,
    "matches": int,              # Only if matched
}
```

**Verify Result Schema:**

```python
{
    "score": float,              # 0.0 to 1.0
    "threshold": float,          # Default 0.8
    "passed": bool,
    "total_statements": int,
    "grounded_statements": int,
    "ungrounded_statements": int,
    "persona_statements": int,
    "persona_ratio": float,
    "statements": [
        {
            "text": str,
            "grounded": bool | None,    # None for persona
            "method": str,
            "category": str,            # grounded|ungrounded|persona
        }
    ],
    "gaps": [
        {
            "text": str,
            "reason": str,              # values_not_in_kg
        }
    ],
}
```

**Scoring Formula:**

```
score = grounded / (grounded + ungrounded)
```

If all statements are persona (no verifiable values), score defaults to 1.0.

**Numeric Tolerance:**

```python
abs(value - kv_num) <= abs(kv_num * 0.01) + 0.001
```

1% relative tolerance + 0.001 absolute floor for near-zero values.

---

### 2.3 kg.py (145 lines)

**Purpose:** JSON-LD knowledge graph loader with core/acquired zone separation.

**Imports:** `json`, `pathlib.Path`, `datetime`

#### Constants

```python
EMPTY_KG = {
    "@context": {
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "aether": "http://aether.dev/ontology#"
    },
    "@graph": [],
}
```

#### Functions

| Function | Signature | Returns | Description |
|----------|-----------|---------|-------------|
| `load_kg` | `(path: str \| Path) -> dict` | KG dict | Load JSON-LD file; returns empty graph if missing |
| `get_nodes` | `(kg: dict) -> list[dict]` | Node list | Extract nodes from `@graph` or single-node format |
| `query_nodes` | `(kg: dict, entities: list[str]) -> list[dict]` | Matched nodes | Case-insensitive entity search across all node values |
| `add_acquired` | `(kg: dict, triple: dict) -> dict` | Updated KG | Add learned knowledge with provenance metadata |
| `get_core_nodes` | `(kg: dict) -> list[dict]` | Core nodes | Nodes where `aether:origin` is "core" or absent |
| `get_acquired_nodes` | `(kg: dict) -> list[dict]` | Acquired nodes | Nodes where `aether:origin` is "acquired" |
| `save_kg` | `(kg: dict, path: str \| Path) -> None` | None | Write KG to file, pretty-printed |
| `stats` | `(kg: dict) -> dict` | Stats dict | Returns `{total, core, acquired}` counts |

**Triple Input Schema (for `add_acquired`):**

```python
{
    "subject": str,                  # Entity name
    "predicate": str,                # Relationship
    "object": str | any,             # Target value
    "confidence": float,             # 0.0 to 1.0
    "aec_trigger": str,              # What caused the acquisition
}
```

**Acquired Node Metadata:**

```python
{
    "@id": "aether:acquired/{subject_slug}",
    "rdfs:label": str,
    "{predicate}": "{object}",
    "aether:origin": "acquired",
    "aether:confidence": float,
    "aether:acquired_date": str,     # ISO 8601
    "aether:aec_trigger": str,
}
```

---

### 2.4 stamper.py (130 lines)

**Purpose:** Capsule folder factory — create, validate, and version agents.

**Imports:** `json`, `shutil`, `pathlib.Path`, `datetime`, `aether.generate_id`, `aether.REQUIRED_SUFFIXES`

#### Functions

| Function | Signature | Returns | Description |
|----------|-----------|---------|-------------|
| `stamp_empty` | `(name: str, path: str \| Path, version: str = "1.0.0") -> Path` | Capsule path | Create capsule with default files |
| `stamp_from_source` | `(name: str, source_path: str \| Path, output_path: str \| Path, version: str = "1.0.0") -> Path` | Capsule path | Create capsule from source file (.md/.json/.jsonld) |
| `validate_capsule` | `(path: str \| Path) -> dict` | Validation result | Check folder structure and JSON validity |
| `restamp` | `(path: str \| Path, new_version: str) -> Path` | New capsule path | Copy with new version, track lineage |

**Source File Routing:**

| Extension | Target File | Logic |
|-----------|-------------|-------|
| `.md` | `{name}-kb.md` | Direct copy |
| `.jsonld` | `{name}-kg.jsonld` | Parsed and written as JSON |
| `.json` with `@graph`/`@context`/`@id` | `{name}-kg.jsonld` | Detected as JSON-LD |
| `.json` otherwise | `{name}-definition.json` | Merged with defaults |

**Validation Result Schema:**

```python
{
    "valid": bool,
    "missing": list[str],            # Missing filenames
    "errors": list[str],             # Parse errors
}
```

**Restamp Lineage:**

```python
{
    "id": "new-id-v1.1.0-{uid8}",
    "version": "1.1.0",
    "previous_version": "1.0.0",
    "previous_id": "old-id-v1.0.0-{uid8}",
    "restamped": "2026-03-05T..."
}
```

---

### 2.5 habitat.py (134 lines)

**Purpose:** In-memory capsule registry with topic-based message routing.

**Imports:** `datetime`

#### Class: Habitat

```python
Habitat()
```

**Internal State:**

| Attribute | Type | Description |
|-----------|------|-------------|
| `_registry` | `dict[str, dict]` | capsule_id → metadata |
| `_log` | `list[dict]` | Message log (auto-trimmed at 1000 entries) |

**Methods:**

| Method | Signature | Returns | Description |
|--------|-----------|---------|-------------|
| `register` | `(capsule_id: str, metadata: dict) -> None` | None | Add capsule with subscriptions |
| `unregister` | `(capsule_id: str) -> None` | None | Remove capsule |
| `list_capsules` | `() -> list[dict]` | All capsules | Registry dump |
| `get` | `(capsule_id: str) -> dict \| None` | Capsule metadata | Single lookup |
| `route` | `(topic: str, payload: dict = None) -> list[str]` | Matching IDs | Find capsules by topic subscription |
| `broadcast` | `(topic: str, payload: dict) -> dict` | Delivery info | Publish to all subscribers, log entry |
| `detect_gaps` | `(topic: str) -> bool` | `True` if gap | No capsule handles this topic |
| `get_log` | `(limit: int = 50) -> list[dict]` | Log entries | Recent messages |
| `stats` | `() -> dict` | Registry stats | Counts and topic list |

**Routing Logic:**

- Exact match: `"market.analysis"` matches subscription `"market.analysis"`
- Wildcard prefix: `"market.*"` matches any topic starting with `"market."`

**Broadcast Result Schema:**

```python
{
    "topic": str,
    "recipients": list[str],
    "timestamp": str,                # ISO 8601
}
```

---

### 2.6 llm.py (103 lines)

**Purpose:** LLM API wrapper with .env loading and cost estimation.

**Imports:** `os`, `pathlib.Path`

#### Functions

| Function | Signature | Returns | Description |
|----------|-----------|---------|-------------|
| `call_llm` | `(prompt, provider, model, api_key, max_tokens) -> dict` | Response dict | Call LLM, never raises |
| `make_llm_fn` | `(provider, model, api_key) -> callable` | Function | Factory for Capsule-compatible callable |

**Call Result Schema:**

```python
{
    "text": str,                     # Response text or error message
    "tokens_in": int,                # Input tokens (0 for stub/error)
    "tokens_out": int,               # Output tokens (0 for stub/error)
    "model": str,
    "cost": float,                   # Estimated cost in USD
}
```

**Providers:**

| Provider | Default Model | SDK | Error Behavior |
|----------|--------------|-----|----------------|
| `"anthropic"` | `claude-sonnet-4-20250514` | `anthropic` | Returns `[LLM Error: ...]` |
| `"openai"` | `gpt-4o` | `openai` | Returns `[LLM Error: ...]` |
| `"stub"` | N/A | None | Returns `[Stub response for N char prompt]` |

**Cost Estimation:**

```python
COST_PER_1K_TOKENS = {
    "claude-sonnet-4-20250514": {"input": 0.003, "output": 0.015},
    "gpt-4o": {"input": 0.005, "output": 0.015},
}
```

**Environment Loading:**

`_load_env()` runs at import time. Reads `.env` from the project root. Parses `KEY=VALUE` lines, skips comments (`#`) and blank lines. Uses `os.environ.setdefault()` to avoid overriding existing environment variables.

---

### 2.7 cli.py (128 lines)

**Purpose:** Command-line interface for all framework operations.

**Imports:** `argparse`, `json`, `pathlib.Path`, + all other framework modules

#### Commands

**`aether stamp <name>`**

```
Arguments:
  name                 Agent name
  --source FILE        Source file (.md, .json, .jsonld)
  --output DIR         Output directory (default: ./capsules)
  --version VERSION    Version string (default: 1.0.0)
```

Creates a new capsule folder. If `--source` is provided, routes the file to the appropriate capsule component based on extension.

**`aether run <capsule_path> <query>`**

```
Arguments:
  capsule_path         Path to capsule folder
  query                Query string to process
  --provider PROVIDER  LLM provider: anthropic, openai, stub (default: stub)
  --model MODEL        Override default model
  --report full        Print detailed ASCII execution report
```

Loads capsule, creates LLM function, runs 4-stage pipeline, runs AEC verification against augmented KG nodes, prints results including AEC score, statement breakdown, and telemetry.

**`aether validate <capsule_path>`**

```
Arguments:
  capsule_path         Path to capsule folder
```

Checks folder has all required files and all JSON files parse correctly. Reports missing files and parse errors.

**`aether info <capsule_path>`**

```
Arguments:
  capsule_path         Path to capsule folder
```

Displays manifest contents, KG statistics (total/core/acquired nodes), KB size in characters, and individual file sizes in bytes.

---

## 3. Capsule Specification

### 3.1 File Naming Convention

All files within a capsule folder are prefixed with the folder name:

```
{folder-name}/
├── {folder-name}-manifest.json
├── {folder-name}-definition.json
├── {folder-name}-persona.json
├── {folder-name}-kb.md
└── {folder-name}-kg.jsonld
```

### 3.2 Stamped Folder Naming

```
{slug}-v{version}-{uid8}/
```

- `slug`: Agent name, lowercased, special characters replaced with hyphens
- `version`: Semantic version (e.g., 1.0.0)
- `uid8`: First 8 characters of SHA-256 hash of `{name}:{version}:{timestamp}`

### 3.3 manifest.json

```json
{
  "id": "jefferson-v1.0.0-a3f7c2d1",
  "name": "jefferson",
  "version": "1.0.0",
  "created": "2026-03-05T12:00:00",
  "framework_version": "0.1.0",
  "previous_version": null,
  "previous_id": null
}
```

**Required fields:** `id`, `version`
**Optional fields:** `name`, `created`, `framework_version`, `previous_version`, `previous_id`, `source`

### 3.4 definition.json

```json
{
  "agent_type": "Scholar",
  "agent_name": "Thomas Jefferson Scholar Agent",
  "primary_function": "Comprehensive knowledge source on...",
  "domain_boundaries": {
    "authoritative": ["political philosophy", "diplomatic career"],
    "out_of_scope": ["modern politics"]
  },
  "suggested_aec_gates": ["temporal_validation", "entity_matching"],
  "pipeline": {
    "distill": {"enabled": true},
    "augment": {"enabled": true},
    "generate": {"enabled": true},
    "review": {"enabled": true}
  },
  "review": {
    "threshold": 0.8,
    "min_length": 10,
    "max_length": 10000
  }
}
```

**Pipeline stages** can be individually disabled by setting `enabled: false`.

### 3.5 persona.json

```json
{
  "persona_name": "Thomas Jefferson Scholar Agent",
  "tone": "formal",
  "style": "academic",
  "interaction_style_traits": {
    "kind": true,
    "curious": true,
    "analytical": true,
    "witty": false,
    "serious": true,
    "reserved": true
  },
  "persona_keywords": ["scholarly", "precise", "didactic"],
  "persona_description": "...",
  "character_traits": {},
  "constraints": ["factual", "no-speculation"]
}
```

The `tone` and `style` fields are used during prompt construction in the Generate stage.

### 3.6 kb.md

Plain markdown file. Content is split into paragraphs (double newline separated) during the Augment stage. Each paragraph is scored by entity overlap with the distilled entities and the top matches (default 3) are included in the LLM prompt.

No required structure. Any valid markdown content.

### 3.7 kg.jsonld

JSON-LD format with `@context` and `@graph` array:

```json
{
  "@context": {
    "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
    "aether": "http://aether.dev/ontology#"
  },
  "@graph": [
    {
      "@id": "person:thomas_jefferson",
      "@type": "Person",
      "rdfs:label": "Thomas Jefferson",
      "birth_year": 1743,
      "birth_date": "1743-04-13"
    }
  ],
  "knowledge_graph_triples": [],
  "entity_registry": []
}
```

**Node zones:**
- Core: no `aether:origin` tag or `aether:origin: "core"`
- Acquired: `aether:origin: "acquired"` with provenance metadata

**Single-node format** (without `@graph`) is automatically normalized to `@graph` format on load.

---

## 4. Telemetry Specification

Telemetry is recorded in `ctx["telemetry"]` during pipeline execution.

### 4.1 Stage Metrics

| Stage | Metrics |
|-------|---------|
| Distill | `time_ms`, `entities_extracted` |
| Augment | `time_ms`, `kb_matches`, `kg_matches` |
| Generate | `time_ms`, `prompt_chars`, `tokens_in`, `tokens_out` |
| Review | `time_ms` |

### 4.2 Aggregate Metrics

| Metric | Calculation |
|--------|------------|
| `total_ms` | Wall clock time from pipeline start to end |
| `aether_ms` | `total_ms` minus generate `time_ms` |
| `llm_ms` | Generate stage `time_ms` |

### 4.3 Cost Estimation

```python
cost = (tokens_in / 1000 * input_rate) + (tokens_out / 1000 * output_rate)
```

Rates are defined per model in `COST_PER_1K_TOKENS` in `llm.py`.

---

## 5. Error Handling

### 5.1 Principles

- **LLM calls never raise.** `call_llm()` catches all exceptions and returns `[LLM Error: {message}]`.
- **Missing files raise at load time.** `Capsule.__init__()` raises `FileNotFoundError` or `ValueError` for missing or invalid files.
- **AEC handles empty input gracefully.** Empty responses return score 0.0 with `reason: "no_statements"`.
- **KG handles missing files.** `load_kg()` returns an empty graph structure if the file doesn't exist.

### 5.2 Error Propagation

```
Capsule load failure     → Exception raised to caller
Pipeline stage failure   → Exception propagates (no try/catch in pipeline)
LLM call failure         → Error string returned, pipeline continues
AEC verification failure → Low score returned, pipeline continues
KG load failure          → Empty graph returned, augment finds no matches
```

---

## 6. Security Considerations

### 6.1 API Key Management

- Keys stored in `.env` file at project root
- `.env` is in `.gitignore`
- Keys loaded via `os.environ.setdefault()` — existing environment variables take precedence
- Keys are never logged, printed, or included in telemetry

### 6.2 Capsule Integrity

- Core KG nodes are immutable — no automated process modifies them
- Acquired nodes carry provenance metadata for audit
- Restamping creates copies, never modifies originals
- Manifest tracks lineage for version traceability

---

## 7. Performance Characteristics

### 7.1 Measured Performance (Phase 1)

| Operation | Time | Scale |
|-----------|------|-------|
| Capsule load (5 files, 48KB) | < 0.05ms | Per capsule |
| Distill (intent + entities) | < 0.01ms | Per query |
| Augment (85 paragraphs, 43 nodes) | < 0.3ms | Per query |
| AEC verify (10 statements, 43 nodes) | < 0.1ms | Per response |
| Full pipeline (excluding LLM) | < 0.5ms | Per query |

### 7.2 Scaling Considerations

| Component | Current Limit | Scaling Path |
|-----------|--------------|-------------|
| KB paragraphs | Exhaustive search | Index or pre-filter at ~500 paragraphs |
| KG nodes | Exhaustive search | Index at ~500 nodes |
| Habitat registry | In-memory dict | Persistent store at ~10,000 capsules |
| Message log | In-memory list | External log at ~100,000 entries |

---

## 8. Extension Points

### 8.1 Custom LLM Provider

```python
def my_provider(prompt: str, **kwargs) -> str:
    # Custom logic
    return response_text

capsule = Capsule("path/to/agent", llm_fn=my_provider)
```

### 8.2 Custom Pipeline Stages

Subclass `Capsule` and override any stage:

```python
class MyAgent(Capsule):
    def distill(self, ctx):
        # Custom distillation logic
        ctx["distilled"] = {"intent": "custom", "entities": [...]}
        return ctx
```

### 8.3 Custom AEC Gates

Import and extend AEC functions:

```python
from aec import verify, deterministic_gate

def my_verification(response, kg_nodes):
    base_result = verify(response, kg_nodes)
    # Add custom checks
    return base_result
```

### 8.4 Capsule Registration

```python
from habitat import Habitat
from aether import Capsule

h = Habitat()
cap = Capsule("path/to/agent")

h.register(cap.id, {
    "name": cap.name,
    "scent_subscriptions": ["history.*", "politics.founding"],
    "domain_boundaries": cap.files["definition"].get("domain_boundaries", {}),
})

# Route a query
recipients = h.route("history.jefferson")
```

---

*AETHER v0.1.0 — Architecture Reference*
*Phase 1 Complete — March 2026*
