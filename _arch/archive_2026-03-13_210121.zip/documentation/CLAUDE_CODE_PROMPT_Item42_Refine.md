# Claude Code Agent Prompt — Item 42
# aether refine: Session sweep that surfaces KG improvement candidates from queue analysis
# Files touched: education.py (new function), cli.py (new command)
# No other files touched. No new dependencies.

---

## Step 0 — Read Before Writing

Read these files in full before writing a single line of code:
- `education.py` — full file, understand queue structure and all existing functions
- `cli.py` — full file, understand command patterns
- `aec.py` — `split_statements()` function specifically (lines 12–33)
- `education-queue.json` (any capsule that has one) — understand real data shapes

Critical observation from real queue data: most gap statements in persona-heavy
capsules are narrative/emotional phrases that can never be KG-grounded
("that's what I call a sweet deal", "some arm-twisting"). These must be filtered
before proposing KG candidates — otherwise refine proposes noise.

Do not begin implementation until you have read all four.

---

## What to Build

`refine_session()` in `education.py` and `aether refine <capsule>` in `cli.py`.

Refine analyzes the education queue across ALL statuses and surfaces:
1. Recurring factual gaps — subjects that appear repeatedly across failures
2. Unresolved failures — records that hit `failed` status after education attempt
3. KG coverage candidates — factual claims that could be added to strengthen the KG
4. A plain-language summary of what the capsule consistently doesn't know

It does NOT automatically modify the KG. It produces a report and optionally
auto-queues identified candidates into the education loop for validation first.

---

## Part 1 — `education.py`: Add `refine_session()` function

### Function signature

```python
def refine_session(capsule_path: str | Path, n: int = 50, auto_queue: bool = False) -> dict:
```

- `capsule_path` — path to capsule folder
- `n` — number of most recent queue records to analyze (default 50, min 1)
- `auto_queue` — if True, auto-queue identified KG candidates as new pending records
- Returns a `result` dict (shape defined below)

### Step 1 — Load records

Load the queue. Take the `n` most recent records sorted by timestamp descending.
If queue has fewer than `n` records, use all of them.

### Step 2 — Separate persona gaps from factual gaps

For each record, for each gap in `record["gaps"]`:

**Filter as PERSONA (discard) if the gap text:**
- Contains no proper nouns, numbers, dates, or capitalized entities
- Is shorter than 8 words
- Contains hedging/emotional markers: "I", "we", "my", "our", "you", "me",
  "think", "feel", "believe", "smile", "love", "hate", "say", "told",
  "called", "like", "sweet", "wonderful", "beautiful", "great", "best"
- Ends with idiom patterns (subjective superlatives, colloquialisms)

**Keep as FACTUAL if the gap text:**
- Contains a number, dollar amount, date, or year
- Contains a capitalized proper noun (entity name, company, location)
- Describes a concrete relationship: "acquired", "founded", "paid", "born",
  "invested", "cost", "earned", "purchased", "built", "sold"

When in doubt, discard. It is better to miss a candidate than to propose noise.

### Step 3 — Cluster factual gaps by subject

Extract the first capitalized word sequence from each factual gap as the subject.
Group gaps by subject. Count occurrences across records.

Example: "See's Candies generated $2 billion" → subject = "See's Candies"

### Step 4 — Score candidates

For each subject cluster:
- `frequency` — how many records contain a gap with this subject
- `records_affected` — list of record IDs containing this subject gap
- `gap_texts` — all unique gap texts for this subject (deduplicated)
- `status_breakdown` — how many source records are pending / integrated / failed
- `priority` — "high" if frequency >= 3 or any source record is "failed" status,
  "medium" if frequency == 2, "low" if frequency == 1

### Step 5 — Identify unresolved failures

Collect all records where:
- `status == "failed"` AND `reason == "still_below_threshold"`
  (education was attempted but KG still didn't improve enough)

These are the highest-priority items — the education loop tried and couldn't fix them.

### Step 6 — Build and return result dict

```python
result = {
    "capsule_path": str(capsule_path),
    "analyzed": len(records_analyzed),
    "timestamp": datetime.now().isoformat(),
    "persona_gaps_filtered": int,        # count discarded as persona
    "factual_gaps_found": int,           # count kept as factual
    "candidates": [                       # sorted by priority then frequency
        {
            "subject": str,
            "frequency": int,
            "priority": str,             # "high" | "medium" | "low"
            "gap_texts": [str],
            "records_affected": [str],   # record IDs
            "status_breakdown": dict,
        }
    ],
    "unresolved_failures": [             # full records where education failed
        {
            "id": str,
            "query": str,
            "aec_score": float,
            "gaps": [dict],
            "reason": str,
        }
    ],
    "summary": str,                      # plain English, 2–4 sentences
    "auto_queued": int,                  # 0 if auto_queue=False
}
```

### Step 7 — Summary generation (no LLM — pure string construction)

Build `result["summary"]` from the data:

```
f"Analyzed {analyzed} records. Found {len(candidates)} recurring knowledge gap subjects "
f"({persona_gaps_filtered} persona statements filtered). "
f"{len([c for c in candidates if c['priority'] == 'high'])} high-priority candidates identified. "
f"{len(unresolved_failures)} records failed education and remain unresolved."
```

### Step 8 — Auto-queue (only if `auto_queue=True`)

For each "high" priority candidate only:
- Build a synthetic gap record and call `queue_failure()` with:
  - `query`: f"Knowledge gap: {candidate['subject']}"
  - `response`: f"Agent produced ungrounded claims about {candidate['subject']}"
  - `aec_result`: `{"score": 0.0, "threshold": 0.8, "passed": False, "gaps": [{"text": t, "reason": "refine_candidate"} for t in candidate["gap_texts"]]}`
- Increment `result["auto_queued"]`

---

## Part 2 — `cli.py`: Add `refine` command

### Handler function

```python
def cmd_refine(args):
    """Analyze education queue and surface KG improvement candidates."""
```

Logic:
1. Validate capsule exists (`validate_folder`) — print error and return if not
2. Check queue exists — if no `education-queue.json` in capsule folder, print:
   `"No education queue found for this capsule. Run some queries first."`
   and return
3. Call `refine_session(args.capsule, n=args.n, auto_queue=args.auto_queue)`
4. Print the report (format below)

### Report format (print to stdout)

```
AETHER Refine — {capsule_name}
─────────────────────────────────────────
Analyzed:    {analyzed} records
Filtered:    {persona_gaps_filtered} persona gaps (not KG-groundable)
Factual:     {factual_gaps_found} factual gap statements found
Candidates:  {len(candidates)} subjects identified
─────────────────────────────────────────

KG CANDIDATES (by priority):

[HIGH] {subject}  (appears in {frequency} records)
  Gaps: {gap_texts[0]}
        {gap_texts[1] if exists}
  Records: {records_affected}

[MEDIUM] ...
[LOW] ...

─────────────────────────────────────────
UNRESOLVED FAILURES: {count}
{for each: "  {id[:20]}... | score: {aec_score} | {reason}"}

─────────────────────────────────────────
{summary}

{if auto_queued > 0: f"Auto-queued {auto_queued} high-priority candidates for education."}
{if auto_queued == 0 and candidates exist: "Run with --auto-queue to queue high-priority candidates for education."}
```

### Parser registration

```python
p_refine = subparsers.add_parser("refine", help="Analyze queue and surface KG improvement candidates")
p_refine.add_argument("capsule", help="Path to capsule folder")
p_refine.add_argument("--n", type=int, default=50,
    help="Number of recent records to analyze (default: 50)")
p_refine.add_argument("--auto-queue", action="store_true",
    help="Auto-queue high-priority candidates into education loop")
p_refine.set_defaults(func=cmd_refine)
```

---

## Edge Cases — Handle All of These

**Empty queue:** `refine_session()` returns result with all zeros and
summary: `"No records in education queue. Run some queries to populate it."`

**All gaps are persona:** `candidates` is empty list. Summary notes this explicitly.
`"All {n} gap statements were persona-style and not KG-groundable."`

**Single record in queue:** Works normally. n=1 is valid.

**Duplicate gap texts across records:** Deduplicate within each candidate's
`gap_texts` list — same phrase from 3 different records counts as frequency=3
but appears once in gap_texts.

**Subject extraction failure:** If no capitalized sequence found in gap text,
use first 3 words of the gap as the subject key. Do not skip the gap.

---

## Verification Steps

```bash
# Run against scholar-buffett which has a real queue
python cli.py refine examples/scholar-buffett

# Verify output has sections: analyzed, candidates, unresolved
# Verify persona gaps were filtered (scholar-buffett queue is mostly persona)
# Verify no crash on empty queue
python cli.py refine examples/test-agent

# Run with auto-queue
python cli.py refine examples/scholar-buffett --auto-queue

# Verify auto-queued records appear in the queue
python cli.py queue examples/scholar-buffett

# Full test suite — baseline must hold
python -m pytest tests/ -v
# Expected: 355/358 (same 3 pre-existing failures)
```

---

## Done Criteria

- [ ] `refine_session(capsule_path, n=50, auto_queue=False)` in `education.py`
- [ ] Persona gap filter removes emotional/narrative statements
- [ ] Factual gap filter keeps statements with entities, numbers, relationships
- [ ] Candidates clustered by subject with frequency, priority, gap_texts, records_affected
- [ ] Unresolved failures (status=failed, reason=still_below_threshold) surfaced separately
- [ ] Summary is plain English constructed from data — no LLM call
- [ ] auto_queue=True queues only HIGH priority candidates via `queue_failure()`
- [ ] `cmd_refine()` in `cli.py` with formatted report output
- [ ] Handles empty queue, all-persona queue, single record — no crashes
- [ ] `aether refine <capsule> [--n N] [--auto-queue]` registered in `main()`
- [ ] No new files created
- [ ] No new imports beyond stdlib
- [ ] 355/358 baseline maintained
