# Claude Code Prompt — AETHER UI Ψ Layer Build
**Session:** Phase 3 — Item 43
**Commit baseline:** 4904e5c
**Test baseline:** 355/358 (3 pre-existing failures, do not regress)
**Working dir:** C:\Users\I820965\dev\aether

---

## Context

AETHER is a minimal agent framework. Agents are 5-file capsule folders.
Core is 10 Python files, ~1,800 lines, standard library + anthropic SDK only.
No new dependencies are permitted.

You are building the Ψ (UI projection) layer — a design-system-agnostic protocol
for projecting agent cognitive state into any pre-loaded component set via CSS
variable deltas.

**The Ψ layer is:**
- A Python state machine (`ui/dai_pulse.py`) that emits phase events
- A JSON protocol (CVP — CSS-Var Patch Protocol) transported over SSE
- A reference client implementation (`ui/client.js`)
- A default pulse-map (`ui/pulse-map.default.json`)
- Extensions to `stamper.py` (PSI file creation)
- Extensions to `cli.py` (validate IRI cross-reference)
- A protocol specification document (`ui/CVP-SPEC.md`)

**The Ψ layer is NOT:**
- Tied to SAP Fiori, EDS, or any design system (those are reference implementations)
- A component library or rendering engine
- A new external dependency

---

## Architecture Decisions (All Settled — Do Not Re-Litigate)

1. **Optional PSI sidecar** — `{prefix}-psi.jsonld` is a 6th optional capsule file.
   Created by stamper on request. Ignored by pipeline and AEC if absent.
   Present in A2A handoffs when UI projection is enabled.

2. **Native-only v1** — EDS blocks must be pre-loaded in DOM. No lazy hydration.
   Explicit scope constraint, not a limitation.

3. **AETHER owns CVP** — `aether.css-delta` is the output event type.
   No AG-UI or LangGraph native emission from core. Adapters live in separate repo.

4. **JSON-over-SSE** — Binary stream retired. SSE text frames only.

5. **DAI Pulse owns heartbeat** — Liveness is a cognitive state, not transport concern.
   Default: emit every 20s, GHOST threshold at 60s (3× multiplier). Configurable.

6. **Design-system-agnostic** — `pulse-map.json` is the only file that knows
   which design system is in use. AETHER core never sees design system tokens.
   The seam principle: protocol above, implementation below.

---

## File Structure to Create

```
aether/
  ui/
    __init__.py
    dai_pulse.py              ← NEW — cognitive state machine
    pulse-map.default.json    ← NEW — default CSS variable mappings
    client.js                 ← NEW — reference client implementation
    CVP-SPEC.md               ← NEW — protocol specification
```

Plus updates to:
```
  stamper.py    ← PSI file creation, --psi flag support
  cli.py        ← aether validate extended, aether stamp --psi flag
```

---

## Build Specification

### 1. `ui/dai_pulse.py`

A synchronous Python class. No async. No threads. No external dependencies.

```python
class DAIPulse:
    """
    Cognitive state machine for AETHER UI projection.
    Emits CVP (CSS-Var Patch Protocol) events as JSON strings.
    Transport-agnostic — caller handles SSE, WebSocket, or any stream.
    """
```

**Phases (in order):**
- `discovery` — Distill + Augment running
- `deliberation` — Generate running (LLM thinking)
- `validation` — Review/AEC running
- `delivery` — Pipeline complete, response ready
- `ghost` — AEC failed twice, response unverifiable
- `alive` — Heartbeat tick, no state change
- `recovering` — New query arriving after GHOST, before discovery

**State machine rules:**
- Normal flow: `discovery → deliberation → validation → delivery`
- Failure flow: `validation → ghost` (on second AEC failure)
- Recovery flow: `ghost → recovering → discovery` (on new query)
- Heartbeat: emitted from any active phase on configurable interval

**Minimum phase duration:**
- Each phase must display for at least 200ms
- If pipeline moves faster, DAI Pulse holds the phase until minimum elapsed
- Prevents kinetic flicker during fast AEC retry loops

**CVP event format (every emit produces this JSON):**
```json
{
  "type": "aether.css-delta",
  "id": "frame-{hash}",
  "ts": 1712345678901,
  "scope": "document",
  "vars": {
    "--kinetic-tempo": "200ms",
    "--surface-accent": "#FF9800"
  },
  "meta": {
    "phase": "deliberation",
    "capsule": "{capsule-id}",
    "sequence": 42,
    "heartbeat": false,
    "reason": null
  }
}
```

**`reason` field rules:**
- `null` for normal phase transitions
- `"aec_failed_twice"` when entering ghost
- `"new_query"` when entering recovering
- `"heartbeat_timeout"` when client-side GHOST triggered (for documentation only)

**Heartbeat event:**
- `vars: {}` (empty — no CSS changes)
- `meta.heartbeat: true`
- `meta.phase`: current phase name
- Emitted every `AETHER_HEARTBEAT_INTERVAL` seconds (default: 20)

**State snapshot event (on reconnect):**
```json
{
  "type": "aether.state-snapshot",
  "scope": "document",
  "vars": { ...current full CSS state... },
  "meta": { "phase": "deliberation", "sequence": 42 }
}
```
Emitted when caller signals a reconnect (e.g., `pulse.reconnect()`).

**Public interface:**
```python
pulse = DAIPulse(
    capsule_id="scholar-buffett",
    scope="document",                    # CSS selector or "document"
    pulse_map=None,                      # dict — uses default if None
    heartbeat_interval=20,               # seconds
    ghost_threshold_multiplier=3,        # × heartbeat_interval = GHOST timeout
    min_phase_duration_ms=200            # minimum display time per phase
)

pulse.transition("discovery")            # returns CVP event JSON string
pulse.transition("deliberation")         # returns CVP event JSON string
pulse.transition("ghost", reason="aec_failed_twice")
pulse.heartbeat()                        # returns heartbeat CVP event JSON string
pulse.reconnect()                        # returns state-snapshot CVP event JSON string
pulse.current_phase                      # property
pulse.sequence                           # property — current sequence number
```

**Pulse map loading:**
1. Check capsule dir for `pulse-map.json` — use if present
2. Fall back to `aether/ui/pulse-map.default.json`
3. Merge: capsule map overrides defaults per-key, not wholesale

**Integration with `aether.py` pipeline:**
Add DAI Pulse emit points to the existing pipeline stages:
- Before `_distill()` → `pulse.transition("discovery")`
- Before `_generate()` → `pulse.transition("deliberation")`
- Before `_review()` → `pulse.transition("validation")`
- After successful review → `pulse.transition("delivery")`
- After second AEC failure → `pulse.transition("ghost", reason="aec_failed_twice")`

The pipeline only emits if a pulse instance is attached. Default: no pulse attached.
Caller attaches via `capsule.set_pulse(pulse_instance)` or equivalent.
Pipeline runs identically with or without pulse attached.

---

### 2. `ui/pulse-map.default.json`

Design-system-neutral token names. No Fiori tokens. No Carbon tokens.
These variable names are AETHER's own namespace.

```json
{
  "_comment": "AETHER default pulse map. Override per design system via capsule pulse-map.json.",
  "_version": "1.0.0",
  "discovery": {
    "--kinetic-tempo": "400ms",
    "--kinetic-scale": "1.0",
    "--surface-accent": "#2196F3",
    "--surface-opacity": "0.85"
  },
  "deliberation": {
    "--kinetic-tempo": "200ms",
    "--kinetic-scale": "1.0",
    "--surface-accent": "#FF9800",
    "--surface-opacity": "0.90"
  },
  "validation": {
    "--kinetic-tempo": "100ms",
    "--kinetic-scale": "1.0",
    "--surface-accent": "#9C27B0",
    "--surface-opacity": "0.95"
  },
  "delivery": {
    "--kinetic-tempo": "0ms",
    "--kinetic-scale": "1.0",
    "--surface-accent": "#4CAF50",
    "--surface-opacity": "1.0"
  },
  "ghost": {
    "--kinetic-tempo": "600ms",
    "--kinetic-scale": "0.95",
    "--surface-accent": "#9E9E9E",
    "--surface-opacity": "0.60"
  },
  "recovering": {
    "--kinetic-tempo": "300ms",
    "--kinetic-scale": "1.0",
    "--surface-accent": "#2196F3",
    "--surface-opacity": "0.70"
  }
}
```

---

### 3. `ui/client.js`

Vanilla JavaScript. No framework. No build step. Drop-in reference implementation.
~100 lines. Well-commented. This is documentation you can run.

Must include:

**Security — namespace pattern validation:**
```javascript
const AETHER_ALLOWED_NAMESPACES = [/^--kinetic-/, /^--surface-/, /^--aether-/];
const AETHER_REJECTED_PATTERNS = [/url\(/, /^--aether-inject/];
const AETHER_MAX_VARS_PER_FRAME = 50;

function isAllowedVar(key, value) {
  if (AETHER_REJECTED_PATTERNS.some(p => p.test(key) || p.test(value))) return false;
  return AETHER_ALLOWED_NAMESPACES.some(p => p.test(key));
}
```

**rAF coalescing:**
Collect deltas within a frame, apply all in a single rAF callback.
Do not apply each delta as it arrives.

**prefers-reduced-motion:**
When `prefers-reduced-motion: reduce` is active:
- Filter out `--kinetic-tempo` and `--kinetic-scale` vars
- Keep `--surface-accent` and `--surface-opacity` (communicate state, not decoration)

**GHOST watchdog:**
Client-side timer. If no event received within `ghostThreshold` milliseconds,
transition UI to ghost state visually by applying ghost vars from local pulse map.
Default threshold: 60000ms (60s). Configurable.

**Reconnection:**
On `EventSource` reconnect (`onerror` → reopen), send `Last-Event-ID` header.
On receipt of `aether.state-snapshot` event type, replace full CSS state
(don't merge — replace) then resume normal delta application.

**Sequence gap detection:**
Track last received sequence number. Log warning if gap detected.
Do not attempt replay — just log and continue.

**Public API:**
```javascript
const aether = AetherUI.connect({
  url: '/aether/stream',          // SSE endpoint
  scope: 'document',              // CSS selector or 'document'
  ghostThreshold: 60000,          // ms before client-side GHOST
  pulseMap: null,                 // local pulse map for GHOST fallback vars
  onPhaseChange: (phase) => {},   // optional callback
  onGhost: (reason) => {},        // optional callback
  onRecover: () => {}             // optional callback
});

aether.disconnect();
```

---

### 4. `ui/CVP-SPEC.md`

Protocol specification document. Audience: developers integrating AETHER UI
into any design system or framework. No AETHER-specific jargon assumed.

Sections:
1. **Overview** — what CVP is, what problem it solves
2. **Design system agnosticism** — the three-contract model, pulse-map as seam
3. **Event schema** — full CVP JSON schema with field descriptions
4. **Scope model** — `"document"` for single-agent, CSS selector for multi-agent
5. **Security** — namespace validation, rejection patterns, max vars per frame
6. **Transport** — SSE format, HTTP/2 recommendation, connection limits on HTTP/1.x
7. **Heartbeat protocol** — emit interval, GHOST threshold, configurable defaults
8. **Reconnection protocol** — Last-Event-ID, state-snapshot event, sequence numbers
9. **GHOST protocol** — what GHOST means, reason field, recovery flow
10. **Multi-agent guidance** — scope isolation, parallel agents, last-write-wins warning
11. **Design system integration guide** — the three contracts, pulse-map override,
    ARIA requirements, `prefers-reduced-motion`
12. **Adapter pattern** — CVP is the internal format; adapters translate outward;
    adapters live outside core

---

### 5. `stamper.py` extensions

**Add `--psi` flag to stamp command:**
When `aether stamp <n> --psi` is used, create two additional files in the capsule:
- `{prefix}-psi.jsonld` — empty projection graph with correct structure
- `pulse-map.json` — copy of `ui/pulse-map.default.json`

**`{prefix}-psi.jsonld` initial structure:**
```json
{
  "@context": {
    "aether": "http://aether.dev/ontology#",
    "psi": "http://aether.dev/projection#"
  },
  "@type": "psi:ProjectionGraph",
  "psi:capsule": "{capsule-id}",
  "psi:version": "1.0.0",
  "psi:projections": []
}
```

**PSI projection limit:**
If stamper is ever adding projections to an existing PSI:
- Warn if projection count reaches 80
- Error (refuse to add) if projection count reaches 100

---

### 6. `cli.py` extensions

**Extend `aether validate <capsule>` to cross-reference PSI:**

If `{prefix}-psi.jsonld` is present in capsule dir:
1. Parse all `psi:binds_to_kg` IRI values from PSI projections
2. Load all `@id` values from `kg.jsonld`
3. For each PSI IRI:
   - If not found in KG → print warning: `⚠ psi.jsonld — orphaned IRI: {iri}`
   - If found but node has `"aether:status": "deprecated"` → print warning with
     suggestion to use the replacement if `aether:replacedBy` is present

Warnings only — capsule is still valid. Do not fail validation.
If no PSI file present → skip silently.

**Output format (append to existing validate output):**
```
⚠ psi.jsonld — 2 orphaned IRIs:
    aether:pricing_uncertainty → not found in kg.jsonld
    aether:value_prop_v1 → deprecated (see aether:value_prop_v2)
✓ psi.jsonld — 3 projections valid
```

---

## Testing Requirements

- Do not regress the 355/358 baseline
- Add tests for DAI Pulse in `tests/test_dai_pulse.py`:
  - Phase transition sequence produces correct CVP JSON
  - Minimum phase duration is enforced
  - Heartbeat produces correct event with empty vars
  - State snapshot on reconnect contains full current state
  - GHOST transition includes reason field
  - Recovery transition clears ghost state
  - Sequence numbers increment correctly
  - Unknown phase name raises ValueError
- Add tests for stamper PSI creation:
  - `--psi` flag creates `psi.jsonld` and `pulse-map.json`
  - PSI file has correct initial structure
- Add tests for validate IRI cross-reference:
  - Orphaned IRI produces warning, not error
  - Valid IRI produces no warning
  - Missing PSI file skips silently

---

## What NOT to Build

- No SSE server — DAI Pulse emits JSON strings, caller handles transport
- No AG-UI adapter — that goes in `aether-adapters` repo
- No LangGraph adapter — same
- No EDS/Fiori specific tokens — only AETHER namespace tokens in default pulse map
- No async/await — synchronous Python only
- No new pip dependencies — standard library only
- No `dashboard.py` changes — UI layer is separate from the operational dashboard

---

## Reference Files

The following files already exist and should be read before building:

- `aether/aether.py` — pipeline stages where DAI Pulse hooks attach
- `aether/stamper.py` — existing capsule creation pattern to follow
- `aether/cli.py` — existing command pattern to follow for new subcommands
- `aether/kg.py` — KG node structure (needed for validate IRI lookup)

---

## Definition to Hold

> AETHER UI is a design-system-agnostic protocol for projecting agent cognitive
> state into any pre-loaded component set via CSS variable deltas.
>
> The protocol is stable. The implementation is replaceable.
> `pulse-map.json` is the only file that knows which design system is in use.
> AETHER core never sees design system tokens.

Every file you create must be consistent with this definition.
If a decision conflicts with it, stop and flag it.

---

## Success Criteria

1. `python -m pytest tests/` — 355+ passing, 0 new failures
2. `aether stamp 1 --psi` — creates 7-file capsule (5 core + psi.jsonld + pulse-map.json)
3. `aether validate scholar-buffett` — runs IRI cross-reference, warns on orphans
4. `DAIPulse` produces valid CVP JSON for all 7 phase types
5. `client.js` loads in a browser with no errors, connects to a mock SSE endpoint
6. `CVP-SPEC.md` documents the full protocol with no AETHER-internal jargon

---

*Build in order: dai_pulse.py → tests → pulse-map.default.json →
client.js → CVP-SPEC.md → stamper.py → cli.py → final test run*
