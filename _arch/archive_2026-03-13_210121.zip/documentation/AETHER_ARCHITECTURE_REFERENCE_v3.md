# AETHER Architecture Reference

**Adaptive Embodied Thinking Holistic Evolutionary Runtime**

---

**Version:** 3.0 (Phase 3 — AEC Concept Layers + Orchestration)
**Date:** March 2026
**Status:** Engine operational, 21 production capsules, orchestrated routing

---

## 1. System Overview

AETHER is a 12-file Python framework for creating, running, verifying, and self-educating knowledge-grounded AI agents. Each agent is a self-contained directory (capsule) with 5 files. The framework processes queries through a 4-stage pipeline with multi-layer post-generation verification.

### 1.1 Architecture Diagram

```
                      ┌───────────────────────────────────┐
                      │            cli.py (~350)           │
                      │  run │ orchestrate │ verify │ stamp │
                      │  ingest-skill │ info │ queue │ educate │
                      └───┬──────┬──────┬──────┬──────┬───┘
                          │      │      │      │      │
          ┌───────────────┘      │      │      │      └──────────────┐
          ▼                      ▼      │      ▼                     ▼
  ┌──────────────┐    ┌──────────────┐  │  ┌──────────────┐  ┌──────────────┐
  │ stamper.py   │    │  aether.py   │  │  │ habitat.py   │  │  ingest.py   │
  │ (~170)       │    │  (~360)      │  │  │ (~200)       │  │  (~450)      │
  │              │    │              │  │  │              │  │              │
  │ stamp_empty  │    │ Capsule class│  │  │ register()   │  │ ingest_skill │
  │ stamp_from   │    │ run()        │  │  │ route()      │  │ ingest_doc   │
  │ restamp      │    │  distill()   │  │  │ orchestrate()│  │ ingest_research│
  │ validate     │    │  augment()   │  │  │ detect_gaps()│  │              │
  └──────────────┘    │  generate()  │  │  │ broadcast()  │  └──────────────┘
                      │  review()    │  │  └──────────────┘
                      └──┬────┬──┬──┘  │
                         │    │  │     │
            ┌────────────┘    │  └─────┼──────────────┐
            ▼                 │        │              ▼
  ┌──────────────┐    ┌──────┴─────┐  │    ┌──────────────────┐
  │  llm.py      │    │  aec.py    │  │    │  aec_concept.py  │
  │  (~150)      │    │  (~255)    │  │    │  (~280)          │
  │              │    │            │  │    │                  │
  │ call_llm()   │    │ verify()   │  │    │ compile_kg()     │
  │ make_llm_fn()│    │ det_gate() │  │    │ match_statement()│
  │ estimate_cost│    │ split_stmt │  │    │ type_operators   │
  └──────────────┘    │ merge()    │  │    │ edge_policies()  │
                      └────────────┘  │    │ concept_verify() │
                                      │    └──────────────────┘
                                      ▼
                            ┌──────────────────┐
                            │  education.py    │
                            │  (~370)          │
                            │                  │
                            │ educate()        │
                            │ queue_failure()  │
                            │ contradiction    │
                            │   _gate()        │
                            │ get_queue()      │
                            └──────────────────┘

  Supporting:
  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
  │  kg.py       │  │  report.py   │  │ dashboard.py │
  │  (~220)      │  │  (~300)      │  │ (~1,050)     │
  │              │  │              │  │              │
  │ load_kg()    │  │ print_report │  │ 5-tab UI     │
  │ add_knowledge│  │ ASCII art    │  │ vis-network  │
  │ stats()      │  │ score bar    │  │ port 8864    │
  └──────────────┘  └──────────────┘  └──────────────┘
```

**12 Python files. ~3,800 lines. stdlib + anthropic SDK.**

---

## 2. The Capsule Model

### 2.1 Five-File Format

| File | Purpose | Format | Mutability |
|------|---------|--------|------------|
| `{id}-manifest.json` | Identity: UID, name, version, lineage | JSON | Updated on restamp |
| `{id}-definition.json` | Behavior: pipeline config, thresholds, domain boundaries, AEC gates, triggers | JSON | Configurable |
| `{id}-persona.json` | Personality: tone, style, traits, description | JSON | Configurable |
| `{id}-kb.md` | Unstructured knowledge | Markdown | Immutable core |
| `{id}-kg.jsonld` | Structured knowledge: typed JSON-LD with nodes and edges | JSON-LD | Core immutable; acquired zone mutable |

### 2.2 KG Node Types

| @type | @id Prefix | Purpose | AEC Verification |
|-------|-----------|---------|-----------------|
| `skill:Concept` | `concept:` | Core topics and domains | Relevance detection |
| `skill:Rule` | `rule:` | Explicit guidelines and mandates | Compliance checking |
| `skill:AntiPattern` | `antipattern:` | Forbidden practices | Violation detection |
| `skill:Technique` | `technique:` | Implementation approaches | Application detection |
| `skill:Tool` | `tool:` | Technologies referenced | Usage context |
| `skill:Trait` | `trait:` | Persona characteristics | Tone alignment |

### 2.3 KG Edge Types

| Edge | Meaning | AEC Layer 3 Logic |
|------|---------|-------------------|
| `skill:avoids` | Source forbids target | Source matched + target tokens found → VIOLATION |
| `skill:requires` | Source depends on target | Informational in v1 |
| `skill:contradicts` | Mutually exclusive | Both matched → CONTRADICTION |
| `skill:enables` | Source makes target possible | Routing signal |
| `skill:contains` | Parent-child hierarchy | Topic grouping |
| `skill:prioritizes` | Importance ranking | Routing tiebreaker |

### 2.4 KG Origin Types

| Origin | Meaning | Mutability |
|--------|---------|------------|
| `core` | Original source material | Immutable at runtime |
| `acquired` | Learned through self-education | Mutable, subject to contradiction gate |
| `updated` | Core knowledge with corrections | Admin-modified |
| `deprecated` | Superseded, excluded from AEC | Never deleted |
| `provenance` | Tracking origin of knowledge | Metadata |

---

## 3. The Pipeline

### 3.1 Distill

Extracts: intent (query/instruction/comparison/creation/general), entities (regex capitalized words), format preference, brevity flag.

Zero latency. No LLM. Keyword + regex patterns.

### 3.2 Augment

Matches query entities against:
- **KB paragraphs** — top-3 by entity overlap scoring
- **KG nodes** — property value matching

Produces grounding context for the generate stage.

**Anti-gaming:** KG node `@id` values and `aether:` properties are stripped from the prompt sent to the LLM. The LLM sees human-readable labels only. AEC retains full access for verification.

### 3.3 Generate

Constructs prompt: persona instructions + matched KB/KG context + query. Single LLM API call. The only stage that costs money or introduces uncertainty.

### 3.4 Review

Runs AEC verification on the response. If score < threshold, queues failure for education.

---

## 4. AEC: Agent Education Calibration

### 4.1 Factual Layer (aec.py)

For scholar agents. Extracts numbers, dates, percentages, names from response statements. Matches against KG node property values with type-aware comparison (numeric tolerance, date canonicalization, partial name matching).

### 4.2 Concept Layer 1: Compiled Pattern Matching (aec_concept.py)

**Activation:** When KG has typed nodes (Rule, AntiPattern, Technique, Concept, Tool).

**Compile phase (once at capsule load):**
- `compile_kg()` tokenizes every `rdfs:label` into pattern sets
- Builds anti-pattern blacklist from parenthetical terms
- Builds edge policies from `avoids`/`requires`/`contradicts` edges
- Returns compiled detector structures

**Runtime (per statement):**
- `tokenize()` the statement
- Set intersection against compiled patterns
- Blacklist intersection for instant violation detection
- Per-type thresholds: Rules 0.50, Techniques 0.55, AntiPatterns 0.40, Concepts 0.30

**Performance:** 0.62ms compile time for 73 nodes. Sub-ms per statement.

### 4.3 Concept Layer 2: Type-Driven LLM Verification

**Activation:** When Layer 1 returns persona (no match) AND ambiguous candidates exist AND LLM is available.

**Type Operator Registry:** Maps `@type` to verification strategy:
- `skill:Rule` → "Does this statement FOLLOW, VIOLATE, or have NO RELATION to this rule?"
- `skill:AntiPattern` → "Does this statement USE what the pattern forbids?"
- `skill:Technique` → "Is this technique being APPLIED?"

**Safeguards:**
- Forced JSON classification (FOLLOW/VIOLATE/UNRELATED)
- Generosity guard in every prompt
- First grounded match wins (max 3 LLM calls per response)
- Concepts, Tools, and Traits do NOT get LLM checks

### 4.4 Concept Layer 3: Compiled Edge Policy Traversal

**Activation:** When Layer 1/2 matches a node that has outgoing `avoids`/`contradicts` edges.

**Logic:** If `concept:typography → avoids → antipattern:inter_roboto_arial`, and a statement matched `concept:typography` AND contains "Inter" → VIOLATION via graph path.

**Three edge types:**
- `avoids`: Source matched + target blacklist tokens found → violation (severity: high)
- `contradicts`: Both source and target matched in same statement → contradiction (severity: medium)
- `requires`: Informational only in v1 (logged, not scored)

**Performance:** <0.5ms per statement. Zero LLM calls. Entirely deterministic.

### 4.5 Scoring

```
Score = Grounded / (Grounded + Ungrounded)
```

Persona excluded. Default threshold 0.80.

Statement category mapping:

| Detection | Category |
|-----------|----------|
| Factual value matches KG property | Grounded |
| Concept pattern match (Layer 1) | Grounded |
| LLM confirms rule compliance (Layer 2) | Grounded |
| Anti-pattern blacklist hit | Ungrounded |
| Edge traversal violation (Layer 3) | Ungrounded |
| LLM confirms rule violation (Layer 2) | Ungrounded |
| No extractable values, no concept match | Persona |

### 4.6 Integrity Mechanisms

**Anti-gaming:** KG node IDs stripped from LLM prompts. Agent cannot parrot its own verification labels.

**Contradiction gate:** Core nodes have absolute veto over proposed acquired nodes. AntiPattern blacklist blocks forbidden knowledge acquisition. Rejections logged with conflicting node ID.

---

## 5. Self-Education Loop

### 5.1 Cycle

```
AEC Failure
    → Queue failure with gaps
    → Research gaps via LLM
    → Extract triples (subject-predicate-object)
    → Contradiction gate check (core veto)
    → Validate through AEC (threshold 0.5)
    → Integrate into KG as acquired origin
    → Re-evaluate original query
    → Integrated (score improved) or Failed
```

### 5.2 Status Progression

`pending` → `researching` → `validated` → `integrated`

Or: `pending` → `researching` → `failed`

Or: `pending` → `researching` → `rejected_contradiction`

---

## 6. Orchestration

### 6.1 Orchestrator Capsule

Standard 5-file capsule with `agent_type: "router"`. Generate and Review disabled — delegates only.

### 6.2 Routing Algorithm

Scores all capsules against query:
- Trigger text overlap: 0.25 weight
- Authoritative domain overlap: 0.25 weight
- KG label overlap: 0.30 weight
- Capsule name overlap: 0.10 weight
- KG node count (normalized): 0.10 weight

Gap threshold: 0.15. Below → no capsule matches.

### 6.3 Auto-Discovery

Orchestrator scans the registry at load time. Builds capability KG from capsule definitions. New capsules are discovered automatically.

### 6.4 Safety

- Orchestrator excludes itself (no routing loops)
- Excludes other router-type agents
- Excludes invalid capsules (missing files)

---

## 7. Ingest Pipeline

### 7.1 Three Modes

| Mode | Function | LLM Required | Use Case |
|------|----------|-------------|----------|
| `ingest_research` | Parse structured research output | No | Deep research prompt output (Gemini format) |
| `ingest_document` | Generic markdown → capsule | Yes | Any markdown file |
| `ingest_skill` | SKILL.md with YAML frontmatter → capsule | Yes | Claude/Copilot skills |

### 7.2 Extraction Skills (for skill ingest)

Three specialized SKILL.md files that serve as prompt templates:

| Skill | Extracts | Output |
|-------|----------|--------|
| `kg-from-skill` | Typed KG nodes (Concept, Rule, AntiPattern, Technique, Tool, Trait) with edges | kg.jsonld |
| `persona-from-skill` | Agent personality, tone, style, traits | persona.json |
| `definition-from-skill` | Agent type, boundaries, gates, triggers | definition.json |

Each is independently usable and improvable. AETHER's own ingest pipeline uses AETHER skills.

---

## 8. Knowledge Graph as Program

The KG serves three functions simultaneously:

| Function | How |
|----------|-----|
| **Knowledge Store** | Nodes hold entities, relationships, properties. Augment retrieves relevant context. |
| **Policy Engine** | Typed nodes + edges encode verification rules. `@type` determines which operator fires. |
| **Verification Runtime** | `compile_kg()` transforms nodes into pattern detectors and edges into policy checkers at load time. Runtime is set intersection. |

This is what distinguishes AETHER from other frameworks. RAGAS/TruLens/DeepEval treat KGs as retrieval substrates. AETHER compiles the graph into executable logic.

---

## 9. Capsule Inventory

### 9.1 Production Capsules (21)

| Category | Count | Examples |
|----------|-------|---------|
| Scholars | 2 | jefferson (51 KG nodes), scholar-buffett (48 nodes) |
| Validators | 2 | aether-validator, test-agent |
| Domain Experts | 2 | domain-agent-builder, domain-sap-cap |
| Anthropic Skills | 6 | frontend-design (73 nodes), brand-guidelines, doc-coauthoring, claude-api, skill-creator, mcp-builder |
| Executive Roles | 8 | CEO, CTO, CPO, CFO, CISO, CLO, Lead Dev, Lead Data Arch, Agent Perf Mgr |
| Infrastructure | 1 | Orchestrator (router) |

### 9.2 Staging (incomplete — SKILL.md ingested, supporting files not yet)

docx, pdf, pptx, xlsx, algorithmic-art, canvas-design, internal-comms, slack-gif-creator, theme-factory, web-artifacts-builder, webapp-testing

---

## 10. File Inventory

| File | Lines | Purpose |
|------|-------|---------|
| `aether.py` | ~360 | Capsule class, 4-stage pipeline |
| `aec.py` | ~255 | Factual entailment check |
| `aec_concept.py` | ~280 | 3-layer concept AEC (compiled matching, type-driven LLM, edge traversal) |
| `cli.py` | ~350 | Command-line interface (9 commands) |
| `dashboard.py` | ~1,050 | 5-tab diagnostic dashboard |
| `education.py` | ~370 | Self-education loop with contradiction gate |
| `habitat.py` | ~200 | Capsule registry, routing, orchestration |
| `ingest.py` | ~450 | Document/skill → capsule pipeline |
| `kg.py` | ~220 | JSON-LD knowledge graph operations |
| `llm.py` | ~150 | LLM wrapper (Anthropic, OpenAI, stub) |
| `report.py` | ~300 | ASCII execution report |
| `stamper.py` | ~170 | Capsule folder factory |

**Total: ~4,155 lines. 12 files. Python stdlib + anthropic SDK.**

---

## 11. Settled Architectural Decisions

| Decision | Status | Rationale |
|----------|--------|-----------|
| AEC is deterministic v1 with concept layers | SETTLED | Vectors dead (42.62% cosine). Compiled patterns work. |
| Capsule = 5 files | SETTLED | Portable, auditable, LLM-agnostic |
| Pipeline = 4 stages | SETTLED | Distill → Augment → Generate → Review |
| KG has 5 origin types | SETTLED | core/acquired/updated/deprecated/provenance |
| Score = grounded / (grounded + ungrounded) | SETTLED | Persona excluded |
| Self-education loop | SETTLED | Queue → research → validate → integrate |
| No frameworks in core | SETTLED | stdlib + anthropic SDK only |
| KG node IDs stripped from LLM prompts | SETTLED | Anti-gaming integrity fix |
| Core nodes veto acquired on contradiction | SETTLED | Education loop poisoning prevention |
| Compile KG at load time, not query time | SETTLED | O(statements) verification |
| Type-driven verification (`@type` → operator) | SETTLED | Schema IS the verification program |
| 1-hop edge traversal in v1 | SETTLED | avoids/requires/contradicts only |
| Capsule is I/O agnostic | SETTLED | Same capsule: CLI, API, MCP, Copilot, SAP CAP |
| Orchestrator is a capsule | SETTLED | Eats its own dog food |

---

## 12. Roadmap

| Priority | Item | Status |
|----------|------|--------|
| 1 | Ψ Layer (EDS, CSS Stream, DAI Pulse) | Spec received from Kimi. Not built. |
| 2 | A2A Communication | Subgraph exchange between capsules. Not built. |
| 3 | AEC as standalone 6th file | Pre-compiled policy checker portable with capsule. Designed. |
| 4 | Recursive directory ingest | Walk full skill folders including scripts/templates. Designed. |
| 5 | Knowledge decay (pheromone model) | utility_score + temporal decay on acquired nodes. Designed. |
| 6 | Negation detection | "Avoid Inter" shouldn't trigger blacklist when agent is refusing. Known limitation. |
| 7 | Anthropic letter | After demo capability is proven. |
| 8 | SAP CAP adapter | Wrap capsule in CAP service handler. ~40 lines. |

---

*AETHER v3.0 — 864 Zeros LLC — March 2026*
*github.com/jeff0926/aether*
