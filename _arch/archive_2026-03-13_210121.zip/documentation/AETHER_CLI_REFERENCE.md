# AETHER CLI Reference
## Command-Line Interface for the Aether Capsule Framework
**Version:** Phase 2 | **Entry Point:** `python cli.py <command>`

---

## Quick Start

```bash
# Validate a capsule
python cli.py validate examples/jefferson

# Get capsule info
python cli.py info examples/jefferson

# Run a query (stub LLM — no API key needed)
python cli.py run examples/jefferson "When was Jefferson born?" --provider stub

# Run with real LLM
python cli.py run examples/jefferson "When was Jefferson born?" --provider anthropic

# Run with full ASCII report
python cli.py run examples/jefferson "When was Jefferson born?" --provider anthropic --report full
```

---

## Commands

### `stamp` — Create a New Capsule

Creates a new capsule folder with all 5 required files.

```bash
python cli.py stamp <name> [options]
```

**Arguments:**
| Argument | Required | Description |
|----------|----------|-------------|
| `name` | Yes | Human-readable capsule name (e.g., "My Agent") |

**Options:**
| Flag | Default | Description |
|------|---------|-------------|
| `--source FILE` | None | Source file to seed the capsule (.md → kb, .jsonld → kg, .json → kg or definition) |
| `--output DIR` | `./capsules` | Output directory for the new capsule folder |
| `--version VER` | `1.0.0` | Semantic version string |

**Examples:**
```bash
# Empty capsule
python cli.py stamp "Sales Agent" --output ./examples

# From markdown knowledge base
python cli.py stamp "History Expert" --source knowledge.md --output ./examples

# From JSON-LD knowledge graph
python cli.py stamp "Finance Agent" --source market_data.jsonld --output ./examples --version 2.0.0

# From JSON (auto-detects: @graph/@context → kg, otherwise → definition)
python cli.py stamp "Config Agent" --source config.json --output ./examples
```

**Output:** Creates folder `{slug}-v{version}-{uid8}/` with 5 files:
- `{id}-manifest.json` — Identity
- `{id}-definition.json` — Pipeline config + thresholds
- `{id}-persona.json` — Tone, style, constraints
- `{id}-kb.md` — Knowledge base (empty or seeded from source)
- `{id}-kg.jsonld` — Knowledge graph (empty or seeded from source)

---

### `run` — Execute Pipeline on a Query

Runs the full 4-stage pipeline (distill → augment → generate → review) against a capsule.

```bash
python cli.py run <capsule_path> <query> [options]
```

**Arguments:**
| Argument | Required | Description |
|----------|----------|-------------|
| `capsule_path` | Yes | Path to capsule folder |
| `query` | Yes | The query to process |

**Options:**
| Flag | Default | Description |
|------|---------|-------------|
| `--provider PROVIDER` | `stub` | LLM provider: `anthropic`, `openai`, or `stub` |
| `--model MODEL` | Provider default | Override model name (e.g., `claude-sonnet-4-20250514`) |
| `--report full` | None | Print comprehensive ASCII execution report |

**Default Models:**
| Provider | Default Model |
|----------|--------------|
| `anthropic` | `claude-sonnet-4-20250514` |
| `openai` | `gpt-4o` |
| `stub` | Returns `[Stub response for N char prompt]` |

**Examples:**
```bash
# Quick test with stub (no API key needed)
python cli.py run examples/jefferson "What were Jefferson's views on liberty?" --provider stub

# Real LLM call
python cli.py run examples/scholar-buffett "What is Berkshire's investment philosophy?" --provider anthropic

# Full report with specific model
python cli.py run examples/jefferson "When was Jefferson born?" --provider anthropic --model claude-sonnet-4-20250514 --report full
```

**Output:**
```
Running: Capsule('jefferson', v1.0.0)
Query: When was Jefferson born?

Generated:
[LLM response text]

AEC Score: 0.857 (threshold: 0.8)
AEC Passed: True
Statements: 3G / 0U / 2P

--- Telemetry ---
Total: 5234.1ms
  Distill:    0.5ms | entities: 2
  Augment:    1.2ms | kb: 3, kg: 2
  Generate: 5230.0ms | prompt: 850 chars
            tokens: 150 in, 200 out
  Review:     2.4ms
```

With `--report full`, prints the complete ASCII art report with box-drawn sections for Agent Profile, Pipeline Results, AEC Verification (with score bar), and Telemetry Summary.

---

### `validate` — Check Capsule Integrity

Validates that a capsule folder has all required files and they parse correctly.

```bash
python cli.py validate <capsule_path>
```

**Examples:**
```bash
python cli.py validate examples/jefferson
# Output:
# Path: examples/jefferson
# Valid: True

python cli.py validate examples/broken-capsule
# Output:
# Path: examples/broken-capsule
# Valid: False
# Missing: ['broken-capsule-persona.json']
```

---

### `info` — Display Capsule Information

Shows capsule metadata, KG statistics, and file sizes.

```bash
python cli.py info <capsule_path>
```

**Example:**
```bash
python cli.py info examples/jefferson
# Output:
# ID: jefferson
# Name: Thomas Jefferson
# Version: 1.0.0
# Path: examples/jefferson
#
# KG Stats: {'total': 51, 'core': 49, 'acquired': 2, ...}
# KB Size: 28692 chars
#
# Files:
#   jefferson-manifest.json: 462 bytes
#   jefferson-definition.json: 1215 bytes
#   jefferson-persona.json: 1526 bytes
#   jefferson-kb.md: 28810 bytes
#   jefferson-kg.jsonld: 23146 bytes
```

---

### `queue` — View Education Queue

Shows the education queue status and pending items for a capsule.

```bash
python cli.py queue <capsule_path>
```

**Example:**
```bash
python cli.py queue examples/scholar-buffett
# Output:
# Education Queue: scholar-buffett
#   Total:       9
#   Pending:     4
#   Researching: 0
#   Validated:   0
#   Integrated:  2
#   Failed:      3
#
# Pending items (4):
#   [2026-03-05T20-57-46-91d26687] score=0.09 | How much did Berkshire pay for See's C...
#   [2026-03-05T21-02-13-a4b7c8d9] score=0.33 | What is Buffett's view on technology...
#   ...
```

---

### `educate` — Run Self-Education

Processes a pending failure through the self-education loop: research gaps via LLM → validate → integrate into KG → re-evaluate.

```bash
python cli.py educate <capsule_path> [options]
```

**Options:**
| Flag | Default | Description |
|------|---------|-------------|
| `--record-id ID` | Oldest pending | Specific failure record ID to educate |
| `--provider PROVIDER` | `anthropic` | LLM provider for research |
| `--model MODEL` | Provider default | Override model name |

**Examples:**
```bash
# Educate the oldest pending failure
python cli.py educate examples/scholar-buffett --provider anthropic

# Educate a specific failure
python cli.py educate examples/jefferson --record-id "2026-03-05T19-12-33-a1b2c3d4" --provider anthropic
```

**Output:**
```
Educating: 2026-03-05T20-57-46-91d26687
Capsule: scholar-buffett

--- Education Result ---
Status: integrated
Original Score: 0.09
New Score: 0.86
Triples Added: 5
Research Tokens: 150 in, 200 out
```

**The Self-Education Cycle:**
1. Load failure record → verify it's pending → mark as "researching"
2. Extract gap statements from AEC result
3. Call LLM with structured research prompt → get JSON triples
4. Validate research output through AEC (threshold 0.5)
5. Integrate validated triples into KG as `acquired` origin
6. Re-evaluate original response with updated KG
7. If new score ≥ threshold → mark "integrated"; else → mark "failed"

---

### `verify` — Standalone AEC Verification

Run AEC verification on arbitrary text against a reference knowledge graph. No pipeline, no capsule — just verification.

```bash
python cli.py verify <text> --reference <kg_file> [options]
```

**Arguments:**
| Argument | Required | Description |
|----------|----------|-------------|
| `text` | Yes | Text to verify (string or path to text file) |

**Options:**
| Flag | Default | Description |
|------|---------|-------------|
| `--reference, -r` | Required | Path to reference KG file (.jsonld) |
| `--threshold, -t` | `0.8` | AEC pass/fail threshold (0.0–1.0) |

**Examples:**
```bash
# Verify a string
python cli.py verify "Jefferson was born on April 13, 1743" -r examples/jefferson/jefferson-kg.jsonld

# Verify a file
python cli.py verify response.txt -r examples/scholar-buffett/scholar-buffett-kg.jsonld -t 0.9
```

**Output:**
```
AEC Score: 1.000 (threshold: 0.8)
Passed: True
Statements: 1G / 0U / 0P
Persona Ratio: 0.0

Gaps (0):
```

---

## Environment Setup

```bash
# Clone
git clone https://github.com/jeff0926/aether.git
cd aether

# Optional: Install LLM SDK
pip install anthropic

# Set API key (optional — stub provider works without it)
echo "ANTHROPIC_API_KEY=your-key-here" > .env
```

**Requirements:** Python 3.11+ (uses `str | Path` union syntax)

---

## Provider Configuration

API keys are loaded from `.env` file at project root:

```bash
# .env
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
```

The `stub` provider requires no API key and returns deterministic placeholder responses. Use it for testing the framework without spending API credits.

---

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Validation failure or missing files |

---

## Python API (Programmatic Usage)

```python
from aether import Capsule
from llm import make_llm_fn

# Load capsule with LLM
llm_fn = make_llm_fn(provider="anthropic")
capsule = Capsule("examples/jefferson", llm_fn=llm_fn)

# Run pipeline
ctx = capsule.run("When was Jefferson born?")

print(ctx["generated"])              # LLM response
print(ctx["distilled"]["intent"])    # query | instruction | comparison | creation | general
print(ctx["augmented"]["kb"])        # Matched KB paragraphs
print(ctx["augmented"]["kg"])        # Matched KG nodes
print(ctx["review"]["passed"])       # True/False
print(ctx["review"]["aec"]["score"]) # 0.0–1.0

# Standalone AEC
from aec import verify
result = verify("Jefferson was born in 1743", [{"birth_year": 1743}])
print(result["score"])               # 1.0
```

