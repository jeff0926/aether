# AETHER Deferred Topics — Additions
**Source:** Claude Code / Agentic Workflow video analysis  
**Date:** 2026-03-12  
**Session:** Claude.ai Tom session  
**Action:** Merge into Aether_Deferred_Topics.md (current rev 4 / 37 items)

---

## What Was Analyzed

Claude Code's agentic workflow pattern (2026) was compared against AETHER's current
implementation. The following items represent concepts from that ecosystem that AETHER
can adopt, improve, or supersede with its own superior architecture.

Items marked **[BUILD NOW]** are surgical changes to existing files.
Items marked **[DEFERRED]** follow the existing pattern.

---

## New Items

---

### Item 38 — AEC Retry Loop Before GHOST **[BUILD NOW]**

**Source concept:** Claude Code "self-healing" — agent reads error output, rewrites, retries.

**AETHER's current state:** `review()` in `aether.py` (lines 253–281) runs AEC, queues
the failure, but passes the unvalidated response through regardless. GHOST state is
decided but not implemented. The agent lies by omission.

**What we build:**
Inside `review()`, before returning ctx, add a single retry loop:

1. AEC fails → extract the specific gap statements (already in `aec_result["ungrounded_statements"]`)
2. Re-enter `generate()` with a constraint injected into the prompt:
   `"The following claims are NOT supported by your knowledge base. Do not make them: {gaps}"`
3. Re-run AEC on the new response
4. If retry passes → return the corrected response, flag as `"self_corrected": True`
5. If retry fails → return `[GHOST] Unable to verify response against knowledge base. Confidence: 0.0`

**Why this is better than Claude Code's version:**
Claude Code's self-healing fixes syntax errors and missing libraries — execution failures.
AETHER's retry loop fixes *knowledge failures* — hallucination at the statement level.
That is a fundamentally harder and more valuable problem.

**Files touched:** `aether.py` (review method only), no new files, no new dependencies.

**Estimated effort:** 30–40 lines.

---

### Item 39 — Two-Pass Progressive Augment **[BUILD NOW]**

**Source concept:** Claude Code "progressive disclosure" — scan metadata first, pull full
content only when semantically determined relevant.

**AETHER's current state:** `augment()` in `aether.py` (lines 185–207) splits KB on
double newlines, scores paragraphs by raw entity-count, returns top 3. This is dumb.
A paragraph with one entity mention outscores a highly relevant section that uses
synonyms or related terms.

**What we build:**
Replace single-pass augment with two-pass:

**Pass 1 — Structure scan:**
- Split KB by markdown headers (`## `, `### `)
- Score sections by: (a) entity match in header, (b) entity density in first sentence only
- Select top N section *candidates* (not full content)

**Pass 2 — Content pull:**
- For each candidate section, score full paragraph content
- Return top 3 by combined score

**Why this is better than Claude Code's version:**
Claude Code scans filesystem metadata (file names, sizes). AETHER scans KB *semantic
structure* (headers, topic sentences). The result is knowledge-aware retrieval, not
file-system-aware retrieval. Stronger signal, better augmentation.

**Files touched:** `aether.py` (augment method only). Optional: refactor into `kg.py`
per existing deferred item 5.5.

**Estimated effort:** 40–50 lines replacing 20 current lines.

---

### Item 40 — Capsule Export Layer: Multi-Platform Adapter **[DEFERRED]**

**Source concept:** Claude Code `.claude/skills/` — modular, versioned instruction sets
stored locally, invokable as commands.

**AETHER's position:** Capsules are architecturally superior to Claude Code skills.
Skills are prompt templates. Capsules are KG-grounded, AEC-validated, self-educating
knowledge structures. The value is exposing capsules to platforms that accept simpler
agent definition formats.

**What we build:**
A generic export function in `stamper.py`:

```python
export(capsule_path, format="claude-skill")
```

Initial format targets:
- `format="claude-skill"` — Renders kb.md + persona.json into `.claude/skills/` format.
  Capsule becomes invokable inside Claude Code sessions as `/run-{capsule-name}`
- `format="github-agent-md"` — GitHub Copilot Desktop agent.md (already partially designed)
- `format="claude-md"` — CLAUDE.md workspace brain injection (persona + KB summary + KG entity list)
- `format="openai-assistant"` — OpenAI assistant definition
- `format="a2a-agent-card"` — `.well-known/agent-card.json`

**The CLAUDE.md format is highest priority.** A capsule exported as CLAUDE.md means
a Claude Code workspace IS a running AETHER capsule — it thinks, retrieves, and
validates responses using capsule knowledge. AEC doesn't run natively inside Claude
Code but the knowledge governance is baked into the context at session start.

**Files touched:** `stamper.py` (new export function), `cli.py` (new `aether export` command).

**Estimated effort:** 60–80 lines. Low risk, high adoption value.

---

### Item 41 — CLAUDE.md as Capsule Seed (Bidirectional) **[DEFERRED]**

**Source concept:** CLAUDE.md as "workspace brain." Claude Code reads it at session
start to understand project context.

**AETHER's extension:**
- `aether stamp --source CLAUDE.md` → produces a full capsule from any CLAUDE.md file
- Capsule runs AEC on the source knowledge, identifies gaps, self-educates
- `aether export --format claude-md` → exports improved capsule back as CLAUDE.md

**Bidirectional flow:**
```
CLAUDE.md → stamp → capsule → AEC + education → export → improved CLAUDE.md
```

Every Claude Code workspace can be upgraded into a self-improving knowledge agent
without the developer knowing AETHER exists. The capsule is the engine; CLAUDE.md
is the interface they already use.

**Files touched:** `stamper.py` (extend existing `--source` flag), `cli.py`.

**Estimated effort:** 30–40 lines. Builds on existing `--source knowledge.md` path.

---

## What Was NOT Taken (And Why)

| Claude Code Feature | Decision | Reason |
|---|---|---|
| Sub-agent reviewer | Skip | AEC already does this deterministically. Claude Code's reviewer is probabilistic LLM-on-LLM. Ours is stronger. |
| Skills persistence | Skip | Capsules are architecturally superior. No value in adopting the weaker pattern. |
| Schema/API discovery | Deferred | Interesting for future tool-use layer but outside Phase 3 scope. |
| Parallel agent swarms | Deferred | A2A + Habitat covers this. Already on list (items 15–17). |

---

## Build Sequence Recommendation

```
1. Item 38 — AEC Retry + GHOST     ← fixes open problem #1, ~40 lines, aether.py only
2. Item 39 — Two-Pass Augment      ← fixes open problem #2, ~50 lines, aether.py only
3. Item 40 — Export Layer          ← new capability, stamper.py + cli.py
4. Item 41 — CLAUDE.md Seed        ← extends #3, stamper.py
```

Items 38 and 39 are the only ones that fix known architectural gaps.
Items 40 and 41 are new capability that expands AETHER's reach to any Claude Code user.

---

*Ready to paste into main AETHER Claude Code session.*
*Instruct Claude Code: "Read this file. Add items 38–41 to Aether_Deferred_Topics.md.
Then build items 38 and 39 in sequence against the current aether.py."*

---

### Item 42 — Session Refinement Command: `aether refine` **[DEFERRED]**

**Source concept:** Claude Code `/refine` skill — end-of-session sweep that extracts
lessons learned and updates CLAUDE.md regardless of pass/fail status.

**AETHER's current state:** `education.py` self-educates only on AEC failure.
Passing runs produce no learning signal even when augment was thin or KG matches were weak.

**What we build:**
`aether refine <capsule>` — a CLI command that:

1. Reads last N entries from `education-queue.json`
2. Identifies: recurring KG gaps, weak augment matches (score=1 on entity count),
   statements that passed AEC but had low grounding scores
3. Proposes new KG node candidates for acquisition
4. Optionally auto-queues them into the education loop for validation before integration

**Why better than Claude Code's version:**
Claude Code's /refine updates a flat markdown file with human-readable gotchas.
AETHER's refine produces structured KG triples, validated through AEC before
integration. The knowledge is typed, provenance-stamped, and queryable — not just
a text note.

**Trigger modes:**
- Manual: `aether refine <capsule>`
- Auto: after every N pipeline runs (configurable in definition.json)
- Hook: post-session if `refine.auto` is true in definition.json

**Files touched:** `cli.py` (new command), `education.py` (new `refine_session()` function).

**Estimated effort:** 50–60 lines. Builds on existing education queue infrastructure.

---

## Nothing Else Was Taken

| Claude Code Concept | Decision | Reason |
|---|---|---|
| Filesystem-as-Context | Skip | Covered by Item 39 (two-pass augment) |
| CLAUDE.md persistent memory | Skip | Covered by Items 40–41 |
| Sub-agents / parallel coordination | Skip | Covered by existing items 15–17 |
| Context compaction | Skip | Covered by existing item 9 (KG pruning) |
| Self-healing logic | Skip | Covered by Item 38 |

