# AETHER UI — Framework Definition
**Status:** SETTLED — Architectural Directive
**Date:** 2026-03-12
**Authority:** AETHER Project / 864zeros LLC

---

## Definition

**AETHER UI is a design-system-agnostic protocol for projecting agent cognitive
state into any pre-loaded component set via CSS variable deltas.**

It is not a component library.
It is not a rendering engine.
It is not tied to any specific design system.

It is a protocol. The design system is a plugin.

---

## The Portability Principle

AETHER's core value proposition is portability:

- The **KG** is LLM-agnostic — the same skill runs on Claude, GPT, Gemini, or any model
- The **capsule** is environment-agnostic — the same capsule runs standalone, via API, or as MCP
- The **UI layer** is design-system-agnostic — the same DAI Pulse drives any component set

All three layers follow the same principle: **the protocol is stable, the implementation
is replaceable.**

---

## What AETHER UI Is

A three-layer stack:

```
DAI Pulse          — cognitive state machine (Python, in core)
     ↓
CSS-Var Patch      — delta protocol (CVP), transport over SSE
Protocol (CVP)
     ↓
pulse-map.json     — design system adapter (the seam)
     ↓
DOM                — any pre-loaded component set
```

The first three layers are part of AETHER. The DOM layer belongs to the application
and the design system it uses.

---

## The Design System Contract

AETHER UI imposes exactly three requirements on any design system:

1. **Components are pre-loaded in the DOM** before the agent begins
2. **CSS custom properties are wired to visual behavior** at design time
3. **Components expose ARIA live regions** for DAI phase transitions

Any design system that satisfies these three constraints is a valid AETHER UI target.
No other constraints exist.

---

## The Seam: pulse-map.json

`pulse-map.json` is the only file that knows which design system is in use.

It maps DAI phase names to the CSS variable names *that design system* uses:

```json
{
  "discovery":    { "--kinetic-tempo": "400ms", "--surface-accent": "#token-A" },
  "deliberation": { "--kinetic-tempo": "200ms", "--surface-accent": "#token-B" },
  "validation":   { "--kinetic-tempo": "100ms", "--surface-accent": "#token-C" },
  "delivery":     { "--kinetic-tempo": "0ms",   "--surface-accent": "#token-D" },
  "ghost":        { "--kinetic-tempo": "600ms", "--surface-accent": "#token-E" }
}
```

A SAP Fiori/EDS implementation uses Fiori design tokens.
A Carbon (IBM) implementation uses Carbon tokens.
A Material implementation uses Material tokens.
A custom implementation uses whatever variable names the team defined.

**AETHER core never sees these values.** It emits phase names. The pulse-map
translates. The DOM responds. AETHER has no knowledge of the design system.

---

## Reference Implementations vs Definition

| Item | Role |
|---|---|
| SAP Fiori / EDS | First reference implementation — not the definition |
| `pulse-map.default.json` | Default token set — overridable per design system |
| `psi.jsonld` | Capsule-level projection rules — design-system-neutral |
| `client.js` | Reference client applier — works with any token namespace |

EDS/Fiori appears in documentation and examples because it is the first deployment
context. It is not a dependency, a requirement, or a constraint on the protocol.

---

## What This Means for the Build

Every build decision affecting AETHER UI must be evaluated against this directive:

> **"Would this decision bind AETHER UI to a specific design system?"**

If yes — redesign until the answer is no.

Specific implications:

- `pulse-map.default.json` uses neutral variable names (`--kinetic-tempo`,
  `--surface-accent`) — not Fiori-specific tokens. Fiori tokens go in a
  Fiori-specific pulse-map override.
- The CSS namespace security rules (`--kinetic-*`, `--surface-*`, `--aether-*`)
  are AETHER namespaces, not design system namespaces. Design systems that use
  different naming conventions publish their own allowlist extension.
- The CVP protocol spec makes no reference to Fiori, EDS, Carbon, or Material.
  Those appear only in integration guides.
- The `client.js` reference implementation contains no design system references.

---

## Parallel with AETHER Core

This principle mirrors how AETHER core treats LLM providers:

```
Core analogy:
  llm.py knows about providers (Anthropic, OpenAI, stub)
  The capsule knows nothing about which provider runs it

UI analogy:
  pulse-map.json knows about design system tokens
  DAI Pulse knows nothing about which design system renders it
```

The pattern is identical. The seam file is the only point of coupling.
Everything above the seam is protocol. Everything below is implementation.

---

## Settled Status

This definition is settled architectural doctrine.

It must be reflected in:
- The CVP protocol specification (`CVP-SPEC.md`)
- The build specification handed to Claude Code
- The AETHER README when the UI layer is documented
- Any external communications about AETHER UI (blog posts, talks, demos)

Do not re-litigate this definition. If a future build decision conflicts with it,
the decision must change — not the definition.

---

*AETHER — Adaptive Embodied Thinking Holistic Evolutionary Runtime*
*The protocol is stable. The implementation is replaceable.*
*github.com/jeff0926/aether — 864zeros LLC — 2026*
