Yes. And that's an important clarification to lock in before building.



\*\*What AETHER UI actually is:\*\*



A protocol for projecting agent cognitive state into any pre-loaded component set via CSS variable deltas.



The EDS/Fiori references in the spec are the \*first implementation target\* — not the definition. The design system is a plugin, not a requirement.



```

Design System A (SAP Fiori/EDS)  ─┐

Design System B (Carbon/IBM)     ─┤→ pulse-map.json → CVP → DOM

Design System C (Material)       ─┤

Design System D (custom)         ─┘

```



The only contract AETHER UI imposes on a design system:



1\. Components are pre-loaded in the DOM

2\. CSS custom properties are wired to visual behavior at design time

3\. Components expose ARIA live regions for phase transitions



That's it. Any design system that satisfies those three constraints works.



\*\*The pulse-map.json is the seam.\*\* It maps DAI phases to CSS variable names that \*that design system\* uses. A Carbon implementation uses Carbon tokens. A Fiori implementation uses Fiori tokens. AETHER core never knows the difference.



\*\*So yes — AETHER UI is a design-system-agnostic agent UI framework.\*\* SAP/EDS is just the reference implementation because that's the deployment context we're building for first.



That framing should probably be explicit in the build spec and the CVP protocol document. It's a significant part of the portability story — same reason the KG is LLM-agnostic.

