# AETHER UI — Round 2 Multi-LLM Synthesis
**Date:** 2026-03-12
**Reviewers:** Grok, Kimi, Gemini, ChatGPT, Copilot (5 LLMs)
**Status:** FINAL — All questions resolved. Ready for build spec.

---

## Headline

Five LLMs. Five challenge questions. Two rounds of review.

**The five decisions from the proposal held.** No reversals. No show-stoppers.
What Round 2 produced: ten concrete specification additions that make the
architecture production-ready rather than prototype-ready.

The architecture is vetted. This document is the final synthesis before the
build specification is written and handed to Claude Code.

---

## Challenge Question Resolution — All Five Closed

### Q1 — PSI Silent Failure on KG IRI Changes

**Verdict: Silent runtime failure is acceptable. Build-time warning is mandatory.**

All five agreed: crashing on a missing IRI is wrong — UI degrades gracefully.
But silent failure with no developer feedback is a debugging nightmare.

**Decision:** Add IRI cross-reference validation to `aether validate`.
When a developer runs `aether validate <capsule>`, the CLI cross-references
every `psi:binds_to_kg` IRI against `kg.jsonld`. Orphaned IRIs produce a
warning (not an error). No new PSI fields required in v1. This is a KISS solution.

Kimi's `psi:kg_version` field and ChatGPT's alias array are both good ideas —
both deferred to v2. V1 needs the CLI warning. That's enough.

### Q2 — Heartbeat Interval for Enterprise SAP

**Verdict: 5s/15s is too aggressive. Defaults changed. Configurable.**

Corporate proxies and load-balancers typically kill idle HTTP connections at
30–120 seconds. SAP infrastructure leans toward the longer end. A 15-second
GHOST threshold produces false positives on any SAP deployment on a corporate VPN.

**Decision:**
- Default emit: **20 seconds**
- Default GHOST threshold: **60 seconds** (3× multiplier)
- Both configurable via environment variable or `definition.json`

```python
AETHER_HEARTBEAT_INTERVAL = int(os.getenv("AETHER_HEARTBEAT_INTERVAL", 20))
AETHER_GHOST_THRESHOLD = int(os.getenv("AETHER_GHOST_THRESHOLD", 3))  # multiplier
```

Grok's 20s/60-75s recommendation was most practically grounded for corporate
proxy behavior. This matches it exactly.

### Q3 — CVP Adoption Barrier

**Verdict: Own CVP for v1. Publish reference adapter. AG-UI proposal is v2 strategy.**

Proprietary protocol is not a barrier if the adapter is official and published.
The barrier only appears when developers must write the translation themselves.

**Decision:**
- AETHER owns `aether.css-delta` as the v1 output format
- Official `aether-agui-adapter` published alongside core (not in core)
- Official `aether-langgraph-adapter` published alongside core (not in core)
- A CVP → AG-UI reference specification document published with v1

Strategic note (deferred): Kimi's Path B — proposing `css-delta` as a generic
event type to the AG-UI working group — is the right long-term move.
Not for v1 build. Flag for post-launch community engagement.

### Q4 — Allowlist vs Schema Validation

**Verdict: Namespace-pattern validation. Not a flat allowlist. Not a schema.**

ChatGPT identified the flaw in a flat allowlist: maintenance burden. Every new
EDS design token requires a list update. A namespace pattern solves it permanently.

**Decision:**
```javascript
const AETHER_NAMESPACE_PATTERNS = [
  /^--kinetic-/,
  /^--surface-/,
  /^--aether-/
];

function isAllowedVar(key) {
  return AETHER_NAMESPACE_PATTERNS.some(p => p.test(key));
}
```

Any CSS variable in the `--kinetic-*`, `--surface-*`, or `--aether-*` namespaces
is permitted. Everything else is rejected before touching the DOM. New EDS tokens
that follow the naming convention are automatically permitted. No list to maintain.

Additional rejection rules (all five LLMs noted this):
- Any value containing `url(` → rejected
- Any value containing `calc(` with external references → rejected
- Any variable starting with `--aether-inject` → rejected (reserved injection namespace)

### Q5 — Multi-Agent CSS Scope Conflict

**Verdict: Mandatory fix. Scope selectors required. `document` is single-agent only.**

This was the strongest consensus across all five responses. 5/5 agreed that
last-write-wins on `document` scope is unacceptable in any real multi-agent deployment.

**Decision:**
- `scope: "document"` remains valid for single-agent applications only
- CVP spec updated: scope field accepts any valid CSS selector string
- Multi-agent apps assign each capsule a scoped DOM container:

```html
<div id="agent-pricing-001" data-aether-scope="pricing-agent">
  <!-- EDS blocks for this agent -->
</div>
```

```json
{
  "scope": "#agent-pricing-001"
}
```

CSS variables inherit through scope boundary. Agents cannot cross-contaminate.
`aether validate` should warn if PSI scope is `document` and habitat.py has
more than one active capsule registered.

---

## Ten Specification Additions from Round 2

These were not in the v2 proposal. All ten are incorporated into the build spec.

### Addition 1 — Sequence Numbers in CVP (Grok + ChatGPT)
Add `sequence` to CVP meta. Required for reconnection recovery and out-of-order detection.

```json
"meta": {
  "phase": "deliberation",
  "capsule": "{id}",
  "sequence": 42,
  "heartbeat": false
}
```

Client detects gaps in sequence on reconnect. Server sends state snapshot
if client reconnects with a `Last-Event-ID` header.

### Addition 2 — `reason` Field in GHOST Events (Gemini)
When phase is `ghost`, meta must include reason.

```json
"meta": {
  "phase": "ghost",
  "sequence": 87,
  "reason": "aec_failed_twice",
  "capsule": "{id}"
}
```

Enables ARIA live region to announce a meaningful message, not just "error."

### Addition 3 — Reconnection State Snapshot (ChatGPT + Grok)
When SSE client reconnects (sends `Last-Event-ID`), server responds with
a full state snapshot event before resuming the stream:

```json
{
  "type": "aether.state-snapshot",
  "scope": "#agent-pricing-001",
  "vars": { "--kinetic-tempo": "200ms", "--surface-accent": "#FF9800" },
  "meta": { "phase": "deliberation", "sequence": 42 }
}
```

Client replaces current CSS state entirely from snapshot, then applies
subsequent deltas normally. No replay buffer needed.

### Addition 4 — Minimum Phase Duration (ChatGPT)
DAI Pulse must enforce a minimum phase display duration of **200ms**.

If the pipeline moves from `validation` → `delivery` in 50ms, the UI
still shows `validation` for at least 150ms more. Prevents kinetic flicker
during fast pipeline execution or AEC retry loops.

```python
MIN_PHASE_DURATION_MS = 200
```

This is a Python-side constraint in `dai_pulse.py`, not a client concern.

### Addition 5 — `prefers-reduced-motion` Support (ChatGPT)
The client-side applier must check the `prefers-reduced-motion` media query.
When reduced motion is preferred, kinetic variables are suppressed:

```javascript
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

function applyAetherDelta(event) {
  const delta = JSON.parse(event.data);
  const vars = reducedMotion.matches
    ? filterKineticVars(delta.vars)  // remove animation vars, keep color/state vars
    : delta.vars;
  // ... apply vars
}
```

`--kinetic-tempo`, `--kinetic-scale` are filtered when reduced motion is active.
`--surface-accent` and phase-indicating color tokens are preserved (they communicate
state, not just decoration).

### Addition 6 — GHOST Recovery Event (Grok)
When a new query arrives after GHOST state, DAI Pulse must emit a recovery event
before transitioning to `discovery`:

```json
{
  "type": "aether.css-delta",
  "scope": "...",
  "vars": {},
  "meta": {
  "phase": "recovering",
  "sequence": 88,
  "reason": "new_query"
  }
}
```

Client clears GHOST visual state before new pipeline begins.
Without this, GHOST styling may persist into the next query's discovery phase.

### Addition 7 — `aether validate` IRI Cross-Reference (Gemini)
`aether validate <capsule>` extended to cross-reference `psi.jsonld` against `kg.jsonld`.

```
$ aether validate scholar-buffett
✓ manifest.json — valid
✓ definition.json — valid
✓ persona.json — valid
✓ kb.md — valid
✓ kg.jsonld — valid (47 nodes, 3 deprecated)
⚠ psi.jsonld — 2 orphaned IRIs:
    aether:pricing_uncertainty → not found in kg.jsonld
    aether:value_prop_v1 → deprecated in kg.jsonld (use aether:value_prop_v2)
```

Warnings only. Capsule is still valid. Developer is informed before deployment.

### Addition 8 — PSI Projection Limit (Kimi)
Stamper enforces a maximum of **100 projections per PSI file**.
Warning at 80. Error at 100. A PSI with 100+ projections is a design smell —
it means the capsule is trying to control too much UI from the knowledge layer.

### Addition 9 — CVP Namespace Security (ChatGPT)
Rejection patterns added to applier spec (see Q4 above).
Additionally: any delta with more than **50 variable updates in a single frame**
is rejected as a potential attack vector. Normal pipeline operation never
produces bursts that large.

### Addition 10 — Pulse-Map Override Story (Grok)
Explicitly define where `pulse-map.json` lives and how it is loaded.

Convention:
- Default pulse-map ships with AETHER core as `aether/ui/pulse-map.default.json`
- Per-capsule override: `{capsule-dir}/pulse-map.json` (present → overrides default)
- Per-deployment override: env var `AETHER_PULSE_MAP_PATH` → overrides both

Stamper creates `pulse-map.json` in capsule dir when `--psi` flag is used.
If absent, core default is used silently.

---

## Items Deferred to v2 / Post-Launch

| Item | Source | Why Deferred |
|---|---|---|
| PSI composite triggers (`all/any` conditions) | ChatGPT | Powerful but adds runtime complexity. V1 single-IRI triggers are sufficient. |
| PSI `kg_version` compatibility field | Kimi | CLI warning (Addition 7) covers the gap for v1. |
| CVP → AG-UI working group proposal | Kimi/Grok | Strategic, not build. Post-launch community action. |
| DAI Pulse as deterministic timeline | ChatGPT | Interesting. Fundamentally changes the state machine model. Separate design discussion. |
| PSI IRI alias arrays | ChatGPT | Nice-to-have. V1 validate warning is the KISS solution. |
| Observability hooks (Prometheus/OTel) | Grok | Phase 4+ scope. Not in core v1. |

---

## Confidence Assessment

```
CONFIDENCE REPORT
─────────────────────────────────────────
Decision/Output:   AETHER UI build specification is ready to write
Confidence Level:  91%
Basis:             Two rounds of independent multi-LLM review.
                   5 LLMs, 10 challenge questions, zero show-stoppers.
                   All five architectural decisions held under stress-testing.
                   10 concrete additions identified, all KISS-compatible.
Blind Spots:       Real SAP Fiori EDS block behavior not tested against spec.
                   Actual corporate proxy behavior for heartbeat not field-tested.
                   Browser performance of namespace-pattern security not benchmarked.
Risk:              Low — no architectural reversals needed
Proceed?:          YES — write the build spec
─────────────────────────────────────────
```

---

## What the Build Spec Must Cover

The build spec handed to Claude Code must include:

**Python side (new file: `dai_pulse.py`):**
- Five phases + `alive` + `recovering` transitions
- Minimum phase duration enforcement (200ms)
- Heartbeat emission (default 20s, configurable)
- GHOST recovery emission
- `reason` field on GHOST events
- Sequence number generation and tracking
- State snapshot on reconnect

**Python side (updates to `stamper.py`):**
- `psi.jsonld` creation when `--psi` flag used
- `pulse-map.json` creation when `--psi` flag used
- PSI projection limit enforcement (warn at 80, error at 100)

**Python side (updates to `cli.py`):**
- `aether validate` extended with IRI cross-reference check
- Warning output format for orphaned PSI IRIs

**Client reference implementation (new: `aether/ui/client.js`):**
- `applyAetherDelta()` with namespace-pattern security
- rAF coalescing
- `prefers-reduced-motion` handling
- State snapshot handler
- Sequence gap detection
- GHOST timeout watchdog (configurable threshold)
- GHOST recovery handler

**Protocol document (new: `aether/ui/CVP-SPEC.md`):**
- Full CVP event schema with all fields
- Scope model and multi-agent guidance
- Security rejection rules
- Reconnection protocol
- Heartbeat protocol
- GHOST/recovery protocol

**Pulse-map default (new: `aether/ui/pulse-map.default.json`):**
- All five phases with default CSS variable values

---

*Two rounds of review. Five LLMs. Architecture is sound. Build it.*
*github.com/jeff0926/aether — 864zeros LLC — 2026*
