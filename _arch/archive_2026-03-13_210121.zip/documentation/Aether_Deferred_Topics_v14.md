# Aether Deferred Topics

Living list of topics identified during development. Items marked ✅ are implemented. Items marked 🔨 are in active build. All others are backlog.

Updated: 2026-03-13 (rev 14 — 60 items)

---

## AEC Refinements

1. ✅ **LLM concept-level verification** — Type-driven LLM operators for Rule/AntiPattern/Technique. Layer 2 in aec_concept.py. Commit e353283.

2. ✅ **Education queue** — Complete cycle: queue_failure → research → validate → integrate → re-evaluate. Working in education.py.

3. **Name matching precision** — Bidirectional partial matching still too loose. "Thomas" matches "Thomas Jefferson." Consider minimum token overlap ratio. Known test failure.

4. **Cross-statement entity resolution** — "He authored the Declaration" loses "He = Jefferson." Coreference resolution would improve accuracy.

5. **Persona ratio monitoring** — Track persona_ratio over time per capsule. If trending above 30-40%, KB needs expansion.

---

## AEC Concept Layers (Phase 3a — Complete)

5.1. ✅ **Layer 1: Compiled pattern matching** — Sørensen-Dice + token set intersection + anti-pattern blacklist. compile_kg() at load time. Commit 250be2c.

5.2. ✅ **Layer 2: Type-driven LLM verification** — TYPE_OPERATORS registry. Rule → compliance, AntiPattern → violation, Technique → application. Commit e353283.

5.3. ✅ **Layer 3: Compiled edge policy traversal** — avoids/requires/contradicts edges compiled at load. 1-hop deterministic. Commit 9c1100e.

5.4. ✅ **Anti-gaming fix** — KG node IDs stripped from LLM prompts. Agent cannot parrot verification labels.

5.5. ✅ **Contradiction gate** — Core nodes veto acquired. AntiPattern blacklist blocks forbidden knowledge acquisition. Rejections logged.

5.6. ✅ **Magnitude extraction** — $25 million → 25,000,000 working.

5.7. **Percentage extraction** — Regex ordering issue with "19.8%". Small fix pending.

5.8. **Negation detection** — "Avoid Inter" triggers blacklist violation even when agent is refusing the anti-pattern. Known limitation.

5.9. **Multi-hop reasoning verification** — Verify reasoning chains against graph paths. Type-constrained heuristic closure designed. Layer 4 future.

5.10. **Knowledge decay (pheromone model)** — utility_score + last_accessed on acquired nodes. Exponential decay at compile time. Designed, not built.

5.11. **Education loop poisoning defense** — Beyond contradiction gate: hypothesis queue, zero-context LLM arbitration. Designed, not built.

---

## Code Refinements

6. **Refactor aether.py augment to use kg.py** — Augment stage duplicates KG node matching logic.

7. **Statement splitter improvement** — Rich responses sometimes evaluate only 1-4 statements from 10+ sentences.

---

## KG & Knowledge Management

8. **Selective subgraph extraction** — N-hop expansion, temporal filtering for large KGs.

9. ✅ **Knowledge Origin Classification (5 types)** — core, acquired, updated, deprecated, provenance. All implemented in kg.py.

10. **KG maintenance sweeps** — Periodic checks for orphaned nodes, duplicate labels, conflicting origins.

11. **`aether:source` provenance field** — Track where every node came from. Field defined. Not yet populated on all nodes.

---

## Ingest Pipeline

12. ✅ **ingest_skill** — SKILL.md with YAML frontmatter → capsule. Working. 17 Anthropic skills ingested.

13. ✅ **Three extraction skills** — kg-from-skill, persona-from-skill, definition-from-skill. Specialized prompts producing 46% more KG nodes than generic.

14. **Recursive directory ingest** — Walk full skill folders including scripts/, templates/, schemas/. 11 Anthropic skills incomplete because supporting files missed.

15. **Export function** — `export(capsule, format="skill-md")`. Close the round-trip loop. Designed, not built.

16. **Capsule Handshake Protocol** — Zip 5 files → quarantine on arrival → auditor verifies → stamp if clean. Designed.

---

## Orchestration & A2A

17. ✅ **Orchestrator capsule** — Routes queries to best capsule. 5-signal scoring. Gap detection. Dry-run mode.

18. **A2A Subgraph Exchange** — Agents communicate via pruned/grafted KG fragments, not text strings.

19. **Auditor capsule** — External verification agent. Different persona (skeptical), different KG (verification criteria). Breaks self-grading paradox.

20. **Epistemic Rebase** — When re-stamping v2, stash v1 acquired nodes, test against new core, drop contradictions, merge survivors.

---

## UI / Ψ Layer

21. **EDS Slivers** — ≤1KB HTML fragments, namespaced via `data-aether-agent`, CSS-variable-driven. Spec from Kimi complete.

22. **CSS Stream** — Agent emits CSS variables, not JSON. Sub-16ms DOM updates via hardware-accelerated repaints. Spec complete.

23. **DAI Pulse** — 4-state machine (reflex → deliberation → complete → ghost) mapped to pipeline stages. Spec complete.

24. **2KB Edge Orchestrator** — DOM scanner, event bus listener, CSS Stream applicator. 2,000-byte JS file. Spec complete.

25. **SAP UDEx Design System Capsule** — Ingest SAP Fiori/UDEx tokens.css as KG. Agent projects UI through authorized CSS variables only.

---

## Enterprise & Adapters

26. **SAP CAP adapter** — Wrap capsule in CAP service handler. ~40 lines Node.js.

27. **MCP server adapter** — Expose capsule KB as resources, pipeline as tools. ~50 lines.

28. **REST API adapter** — POST handler. ~15 lines.

29. **AEC as standalone 6th file** — Pre-compiled policy checker, JSON, ships with capsule. Portable verification.

30. **AEC as MCP server** — Expose AEC verify as an MCP tool for any LLM.

31. **Copilot SKILL.md export** — Generate Copilot-compatible SKILL.md from capsule.

32. **CI/CD gate adapter** — Feed PR diff → AEC → compliance stamp. ~30 lines.

---

## Dashboard & Reporting

33. ✅ **Dashboard** — 5-tab operational diagnostics. vis-network KG explorer. Port 8864.

34. **Dashboard update** — Reflect orchestrator, new capsules, routing view.

35. **Orchestrator routing visualization** — Show routing decision, scores, candidate list in dashboard.

36. **AEC Layer visualization** — Show which layer verified each statement (factual/L1/L2/L3).

---

## Agent Diversity

37. ✅ **Scholar agents** — Jefferson (51 nodes), Buffett (48 nodes).

38. ✅ **Skill agents** — frontend-design (73 nodes) + 5 other complete Anthropic skills.

39. ✅ **Executive roles** — 8 corporate DNA capsules from Gemini (CEO, CTO, CPO, CFO, CISO, CLO, Lead Dev, Lead Data Arch).

40. **Process agents** — Multi-step workflow orchestrators. Not built.

41. **Reactive agents** — Event-driven, pheromone emission pattern. Not built.

42. **Calculus/domain grading agents** — Agents that grade work, not generate it. Conceptual.

---

## Meta / System

43. **CLAUDE.md** — Repo-level config for Claude Code sessions. Not created.

44. **Session versioning** — Track which Claude session modified which files.

45. **Feature brick registry** — Catalog of all independently deployable modules.

46. **Blind testing** — Run same query across capsules, compare scores.

47. **Pluggable queue backends** — File-based (current), Redis, Kafka.

---

## Research & Competitive

48. **SHACL distinction** — Articulate why AEC isn't "SHACL for text." SHACL validates structured data. AEC validates natural language. (Kimi flagged.)

49. **Cross-LLM validation** — Use different LLMs for generation vs verification.

50. **Hallucination percentage claims** — Need real test data before citing reduction percentages externally.

---

## Copilot Skillz (Parked)

51. **Copilot agent-as-code framework** — Applying AETHER pattern to Copilot .agent.md + SKILL.md. 80K employee scale. Gemini building exploratory skill sets.

52. **Bidirectional Copilot export/import** — Capsule → SKILL.md → Copilot, and reverse.

---

## Prior POC Concepts (Validated, Not Ported)

53. **Aura Protocol** — Binary WebSocket, 12-byte header, 4 frame types. Proven in aether-RD.

54. **Stigmergic communication** — Acrylic pheromone payloads, habitat broadcast. Proven in aether-RD.

55. **Mitosis** — Gap detection triggers new capsule stamping. Partial in habitat gap detection.

56. **UDEx Slivers** — 6 EDS components all under 1KB. Proven in aether-RD.

---

## Company Stack

57. **Autonomous Application Framework** — Telegraph-driven, event-based build kit.

58. **Vulture Nest** — Market intelligence (find → grade → build → sell).

59. **EPHD product line** — For His Glory.

60. **OIA product line** — Organize Your Internal Architecture.

---

*Rev 14 — 60 items — 2026-03-13*
*Previous: Rev 13 (55 items, 2026-03-09)*
