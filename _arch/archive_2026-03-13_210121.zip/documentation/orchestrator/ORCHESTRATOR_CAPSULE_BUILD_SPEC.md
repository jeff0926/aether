# Orchestrator Capsule — Build Spec for Claude Code Agent

**What:** A capsule whose job is routing queries to the right capsule and returning the result. It's an agent that knows about other agents.
**Where:** `examples/orchestrator-v1.0.0-{hash}/` — a standard 5-file capsule
**Constraint:** Python stdlib only. The orchestrator uses the existing Habitat + Capsule classes. No new infrastructure.

---

## Context

Read these files first:
- `habitat.py` — Capsule registry, topic routing, gap detection
- `aether.py` — Capsule class, pipeline runner, `run()` method
- `cli.py` — Existing CLI commands for reference
- Any 2 capsule folders in `examples/` to understand the 5-file format

**The problem:** We have 12+ working capsules. Each must be addressed individually — `python cli.py run examples/jefferson "question"`. The user needs to know which agent handles their query. There's no single entry point.

**The fix:** An orchestrator capsule that receives any query, determines which capsule should handle it, invokes that capsule's pipeline, and returns the result. One entry point for all agents.

---

## The Orchestrator IS a Capsule

Standard 5-file format. It eats its own dog food.

### manifest.json
```json
{
  "id": "orchestrator-v1.0.0-{hash}",
  "name": "AETHER Orchestrator",
  "version": "1.0.0",
  "created": "{timestamp}"
}
```

### definition.json
```json
{
  "pipeline": {
    "distill": {"enabled": true},
    "augment": {"enabled": true},
    "generate": {"enabled": false},
    "review": {"enabled": false}
  },
  "review": {"min_length": 0, "max_length": 100000, "threshold": 0.0},
  "agent_type": "router",
  "agent_name": "orchestrator",
  "primary_function": "Route incoming queries to the most appropriate capsule in the registry based on topic affinity and domain boundaries.",
  "domain_boundaries": {
    "authoritative": ["query routing", "agent selection", "capability matching", "gap detection"],
    "out_of_scope": ["direct content generation", "domain expertise", "code writing"]
  },
  "suggested_aec_gates": [],
  "trigger_text": "Any query that doesn't specify a target capsule."
}
```

**Key:** Generate and Review are DISABLED. The orchestrator doesn't generate responses — it delegates to the target capsule which runs its own full pipeline including AEC.

### persona.json
```json
{
  "persona_name": "Signal Router",
  "tone": "operational",
  "style": "precise",
  "interaction_style_traits": {
    "efficient": true,
    "transparent": true,
    "decisive": true,
    "verbose": false
  },
  "persona_keywords": ["routing", "dispatch", "capability", "delegation", "orchestration"],
  "persona_description": "A zero-latency routing intelligence that matches queries to agents. Never generates content directly — always delegates to the most capable specialist."
}
```

### kb.md

The KB describes the orchestrator's routing methodology:

```markdown
# AETHER Orchestrator

## Routing Methodology

The orchestrator matches queries to capsules using three signals:

1. **Topic affinity** — keyword overlap between query entities and capsule definitions
2. **Domain authority** — capsule's `authoritative` domains in definition.json
3. **Capability coverage** — capsule's KG node types indicate what it can verify

## Routing Rules

- If exactly one capsule matches with high affinity → route directly
- If multiple capsules match → select the one with highest KG node count for the topic
- If no capsule matches → report the gap (no hallucination)
- Never generate a response directly — always delegate
- Return the delegated capsule's full result including AEC score

## Gap Protocol

When no capsule can handle a query, report:
- The query topic
- The closest matching capsule (if any) and why it's insufficient
- A recommendation for what kind of capsule would fill the gap
```

### kg.jsonld

The KG contains one node per registered capsule, describing its capabilities:

```json
{
  "@context": {
    "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
    "aether": "http://aether.dev/ontology#",
    "skill": "http://aether.dev/skill#"
  },
  "@graph": []
}
```

**The KG starts empty.** It gets populated at load time by scanning the capsule registry (see below).

---

## Implementation: `orchestrate()` Function

Add to `habitat.py` (~60-80 lines):

### `orchestrate(query: str, registry_path: str, llm_fn=None) -> dict`

```python
def orchestrate(query: str, registry_path: str, llm_fn=None) -> dict:
    """
    Route a query to the best matching capsule, run it, return the result.
    
    Steps:
    1. Scan registry_path for all valid capsules
    2. Load each capsule's definition.json (lightweight — just metadata, not full Capsule)
    3. Score each capsule against the query using:
       a. Keyword overlap between query and capsule's trigger_text
       b. Keyword overlap between query and capsule's authoritative domains
       c. Capsule's KG node count as a tiebreaker (more knowledge = more authority)
    4. Select the best match (or report gap)
    5. Load the full Capsule and run the query through its pipeline
    6. Return the result with routing metadata
    
    Returns:
        {
            'routed_to': str,          # capsule ID
            'routed_name': str,        # capsule name
            'match_score': float,      # routing confidence 0-1
            'match_method': str,       # how the match was determined
            'candidates': [...],       # all scored candidates
            'result': dict,            # full pipeline result from target capsule
            'gap': dict | None,        # if no match found
        }
    """
```

### Scoring Algorithm

For each capsule, compute a routing score:

```python
def _score_capsule(query_tokens: set, capsule_meta: dict) -> float:
    """
    Score a capsule's relevance to a query.
    
    Signals (weighted):
    - trigger_text overlap:      0.4 weight
    - authoritative domain overlap: 0.3 weight  
    - capsule name/id overlap:   0.2 weight
    - KG node count (normalized): 0.1 weight (tiebreaker)
    """
```

Use `tokenize()` from `aec_concept.py` for consistent word extraction. Same stopword list.

### Gap Detection

If the best score is below 0.15 (very low overlap), report a gap instead of forcing a bad match:

```python
{
    'gap': {
        'query': query,
        'topic': extracted_topic,
        'closest_capsule': best_candidate['name'],
        'closest_score': best_candidate['score'],
        'recommendation': f"No capsule covers '{extracted_topic}'. Consider stamping a new agent for this domain."
    }
}
```

---

## CLI Integration

### New command: `orchestrate`

```bash
python cli.py orchestrate "When was Jefferson born?" --registry ./examples --provider anthropic
```

**Arguments:**
| Argument | Required | Description |
|----------|----------|-------------|
| `query` | Yes | The query to route |

**Options:**
| Flag | Default | Description |
|------|---------|-------------|
| `--registry DIR` | `./examples` | Directory containing capsule folders |
| `--provider` | `stub` | LLM provider for the target capsule |
| `--model` | Provider default | Override model |
| `--report full` | None | Show full AEC report from target capsule |
| `--dry-run` | False | Show routing decision without executing |

**Output:**
```
Routing: "When was Jefferson born?"
  Candidates:
    jefferson              score=0.82 ★ SELECTED
    scholar-buffett        score=0.12
    frontend-design        score=0.03
  
  Dispatching to: jefferson (Thomas Jefferson Scholar Agent)
  
  [... target capsule's normal output ...]
  
  AEC Score: 1.0 (threshold: 0.8)
  AEC Passed: True
```

### Dry-run mode

```bash
python cli.py orchestrate "How do I approach typography?" --registry ./examples --dry-run
```

Shows the routing decision and scores without executing the target capsule's pipeline. Useful for debugging routing logic.

---

## The Orchestrator's KG — Auto-Populated

When the orchestrator loads, it scans the registry and builds its own KG dynamically:

```python
def _build_capability_kg(registry_path: str) -> dict:
    """
    Scan all capsules in registry and build a capability KG.
    Each capsule becomes a node with its capabilities as properties.
    """
    graph = []
    for capsule_dir in Path(registry_path).iterdir():
        if not capsule_dir.is_dir():
            continue
        # Load manifest + definition only (lightweight)
        manifest = load_manifest(capsule_dir)
        definition = load_definition(capsule_dir)
        if not manifest or not definition:
            continue
        
        graph.append({
            "@id": f"agent:{manifest.get('id', capsule_dir.name)}",
            "@type": "aether:Agent",
            "rdfs:label": manifest.get('name', capsule_dir.name),
            "aether:origin": "core",
            "aether:agent_type": definition.get('agent_type', 'unknown'),
            "aether:domains": definition.get('domain_boundaries', {}).get('authoritative', []),
            "aether:trigger": definition.get('trigger_text', ''),
            "aether:path": str(capsule_dir),
        })
    
    return {
        "@context": {
            "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
            "aether": "http://aether.dev/ontology#"
        },
        "@graph": graph
    }
```

This means the orchestrator's KG is always current — it discovers new capsules automatically when they're added to the registry.

---

## Exclusions

The orchestrator MUST exclude itself from routing. If the query matches "routing" or "orchestration," it doesn't route to itself — it explains its own capabilities.

Also exclude capsules that are clearly not ready:
- Skip capsules where `validate_folder()` returns missing files
- Skip capsules with `agent_type: "router"` (prevent routing loops)
- Skip capsules with empty KGs (0 nodes) unless they're scholar agents with substantial KBs

---

## Test Cases

### Test 1: Clear single match
```bash
python cli.py orchestrate "When was Jefferson born?" --registry ./examples --provider stub
```
Expected: Routes to jefferson capsule. High confidence.

### Test 2: Domain match
```bash
python cli.py orchestrate "How should I approach typography for a website?" --registry ./examples --provider stub
```
Expected: Routes to frontend-design capsule.

### Test 3: Financial domain
```bash
python cli.py orchestrate "What is Buffett's investment philosophy?" --registry ./examples --provider stub
```
Expected: Routes to scholar-buffett capsule.

### Test 4: No match (gap detection)
```bash
python cli.py orchestrate "How do I configure a Kubernetes cluster?" --registry ./examples --provider stub
```
Expected: Gap detected. No capsule covers Kubernetes.

### Test 5: Dry run
```bash
python cli.py orchestrate "Tell me about Jefferson" --registry ./examples --dry-run
```
Expected: Shows candidates and scores, doesn't execute.

### Test 6: Full pipeline with AEC
```bash
python cli.py orchestrate "When was Jefferson born?" --registry ./examples --provider anthropic --report full
```
Expected: Routes to jefferson, runs full pipeline, shows AEC report.

### Test 7: No routing loops
Orchestrator doesn't route to itself.

---

## Performance Budget

- Registry scan + definition loading: <50ms for 12 capsules
- Scoring all candidates: <5ms (set intersection, same as AEC Layer 1)
- Total orchestrator overhead before dispatch: <60ms
- Target capsule execution: whatever the target takes (pipeline + LLM)

---

## Quality Checks

1. Orchestrator is a standard 5-file capsule in `examples/`
2. `orchestrate()` lives in `habitat.py` (it's orchestration, that's Habitat's job)
3. CLI `orchestrate` command works with all existing flags
4. Dry-run mode shows routing without execution
5. Gap detection fires when no capsule scores above 0.15
6. Orchestrator excludes itself and other router-type agents
7. Auto-populated KG reflects current registry state
8. All existing tests still pass
9. Routing scores use `tokenize()` from `aec_concept.py` for consistency
