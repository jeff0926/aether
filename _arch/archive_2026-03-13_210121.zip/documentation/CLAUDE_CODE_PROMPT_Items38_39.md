# Claude Code Agent Prompt — Items 38 & 39
# Target file: aether.py only. No other files touched.

---

## Step 0 — Read Before Writing

Read these files in full before writing a single line of code:
- `aether.py` — full file
- `aec.py` — understand the `verify()` return shape, especially `result["gaps"]`
- `tests/test_aec_standalone.py` — know what the test suite already covers

Do not begin implementation until you have read all three.

---

## Change 1 of 2 — Extract `_build_prompt` Helper

**Before touching `augment()` or `review()`, extract the prompt-building logic
from `generate()` into a private method.**

Create `Capsule._build_prompt(self, ctx: dict, constraints: list[str] = None) -> str`

- Move the existing prompt-building block from `generate()` into this method exactly
  as-is — no logic changes
- `generate()` calls `self._build_prompt(ctx)` to replace the moved block
- When `constraints` is provided (a list of gap statement strings), append this block
  to the end of the prompt before the final "Response:" line:

```
KNOWLEDGE CONSTRAINTS:
The following claims are not supported by the knowledge base.
Do not make these claims in your response:
- {constraint 1}
- {constraint 2}
...
```

- When `constraints` is None or empty, behavior is identical to the original.
- All existing tests must still pass after this refactor — `generate()` output
  must be identical to before.

---

## Change 2 of 2 — Two-Pass Progressive Augment (Item 39)

Replace the KB search block inside `augment()`. Do not touch the KG search block.
Do not change the method signature or the shape of `ctx["augmented"]`.

**Pass 1 — Structure scan:**
- Detect whether the KB contains markdown headers by checking for lines starting
  with `##` or `###`
- If headers exist: split the KB into sections on those header lines, keeping the
  header with its body
- Score each section:
  - +2 for each entity matched in the header line
  - +1 for each entity matched in the first sentence of the section body
- Keep all sections with score > 0 as candidates

**Pass 2 — Content pull:**
- For each candidate section score the full body by total entity mentions
- Final score = Pass 1 score + Pass 2 body score
- Sort descending, take top 3 full sections as `kb_context`

**Fallback — No headers detected:**
- Run the original paragraph-split logic exactly as it was
- `kb_context` is the top 3 paragraphs by entity count

**Add one field to `ctx["augmented"]`:**
- `"kb_pass": "two-pass"` or `"kb_pass": "fallback"`

This field is additive — it does not replace or rename any existing field.

---

## Change 3 of 3 — AEC Retry Loop + GHOST State (Item 38)

Modify `review()` with the following logic. The method signature does not change.
`ctx["review"]` must always contain all five keys on every path:
`aec`, `passed`, `queued`, `self_corrected`, `ghost`

```
FIRST RUN:
  response_text = extract from ctx["generated"] (existing logic)
  aec_result = aec_verify(response_text, kg_nodes, threshold)

  IF aec_result["passed"]:
      ctx["review"] = {
          "aec": aec_result, "passed": True,
          "queued": False, "self_corrected": False, "ghost": False
      }
      return ctx

  IF NOT aec_result["passed"]:
      queue_failure(...)  <- always queue the original failure regardless of retry outcome
      queued = True

      RETRY:
        gaps = [g["text"] for g in aec_result["gaps"]]
        constrained_prompt_result = self.llm_fn(self._build_prompt(ctx, constraints=gaps))
        retry_text = extract text from constrained_prompt_result

        retry_aec = aec_verify(retry_text, kg_nodes, threshold)

        IF retry_aec["passed"]:
            ctx["generated"] = retry_text
            ctx["review"] = {
                "aec": retry_aec, "passed": True,
                "queued": True, "self_corrected": True, "ghost": False
            }
            return ctx

        IF NOT retry_aec["passed"]:
            ctx["generated"] = "[GHOST] Unable to verify response against knowledge base. Confidence: 0.0"
            ctx["review"] = {
                "aec": retry_aec, "passed": False,
                "queued": True, "self_corrected": False, "ghost": True
            }
            return ctx
```

One retry only. No loop. No recursion.

---

## Verification Steps — Run in Order

```bash
# 1. Validate capsule structure unchanged
python cli.py validate examples/test-agent

# 2. Run pipeline — confirm output shape includes new keys
python cli.py run examples/test-agent "What is Aether?"

# 3. Full test suite
python -m pytest tests/ -v

# 4. Threshold self-check
# Inspect the aether-validator or scholar-buffett capsule definition.json.
# If review.threshold is set above 0.85, lower it to 0.75 for initial testing.
# If self_corrected fires on every clean run, threshold is miscalibrated —
# set threshold to 0.7 in definition.json and re-run until clean passes pass clean.
# Document the threshold value used in a comment in the test output.
```

If any existing test breaks due to missing new keys (`kb_pass`, `self_corrected`, `ghost`),
update the test assertions to include the new keys with their expected default values.
Do not remove or weaken any existing assertion.

---

## Done Criteria

- [ ] `_build_prompt(ctx, constraints=None)` extracted as private method
- [ ] `generate()` delegates to `_build_prompt(ctx)`
- [ ] `augment()` uses two-pass when KB has markdown headers
- [ ] `augment()` uses original fallback when KB has no headers
- [ ] `ctx["augmented"]["kb_pass"]` set on every augment run
- [ ] `review()` queues original failure before retry
- [ ] `review()` retries once with constrained prompt on AEC failure
- [ ] `review()` sets `self_corrected: True` on successful retry
- [ ] `review()` returns GHOST string and sets `ghost: True` on retry failure
- [ ] All five review keys present on every path
- [ ] All existing tests pass
- [ ] No new files created
- [ ] No new imports added
- [ ] Threshold verified and documented — `self_corrected` not firing on clean runs
