# AETHER Daily Development Summary
**Date:** 2026-03-13
**Session Time:** ~1.5 hours
**Commit Range:** 092e246 → 8de8812
**Branch:** main

---

## Project Overview: AETHER

AETHER (Adaptive Embodied Thinking Holistic Evolutionary Runtime) is a minimal agent framework where agents are defined as **5-file capsule folders**. The core is ~10 Python files, ~2,500 lines, using only standard library + Anthropic SDK.

### Core Architecture

```
capsule/
  {id}-manifest.json      # Identity: id, name, version
  {id}-definition.json    # Pipeline config, thresholds
  {id}-persona.json       # Tone, style, constraints
  {id}-kb.md              # Knowledge base (markdown)
  {id}-kg.jsonld          # Knowledge graph (JSON-LD)
```

### Pipeline Flow
```
Query → Distill → Augment → Generate → Review (AEC) → Response
                                          ↓
                              [If AEC fails twice → GHOST state]
                                          ↓
                              [Education queue for self-improvement]
```

### Key Concepts

- **AEC (Aether Entailment Check):** Verifies LLM responses against the KG. Scores factual grounding.
- **GHOST State:** When AEC fails twice, response is marked unverifiable but still delivered with warning.
- **Education Queue:** Failed AEC results queue for later KG enrichment.
- **Capsule:** Self-contained agent definition (5 required files + optional PSI).
- **Orchestrator:** Routes queries to the best-matching capsule based on semantic scoring.

---

## Today's Accomplishments

### Anti-Gaming Fix (Commit: 138bb19)

**Files:** `aether.py`

Fixed LLM prompt leaking node IDs that enabled AEC score inflation.

#### Problem
The `_build_prompt()` function was including namespaced properties in KG node formatting, allowing node IDs like `antipattern:generic_ai_aesthetics` to leak into LLM responses. The LLM could then "cite" these IDs to artificially boost AEC scores.

#### Solution
Extended the property filter in `_build_prompt()` (lines 323-351):

```python
# Skip JSON-LD keywords, rdfs:label, and any namespaced property (contains :)
if k.startswith("@") or k == "rdfs:label" or ":" in k:
    continue
# Skip values that look like node IDs
v_str = str(v)
if ":" in v_str and any(ns in v_str for ns in ["aether:", "rule:", "antipattern:", "technique:", "concept:", "skill:", "psi:"]):
    continue
```

Now only `rdfs:label` and non-namespaced properties reach the LLM prompt.

---

### Contradiction Gate (Commit: 138bb19)

**Files:** `education.py`

Added contradiction gate to prevent acquired nodes from contradicting core knowledge.

#### New Function: `_check_contradiction()`

```python
def _check_contradiction(proposed: dict, kg: dict) -> dict | None:
    """Check if a proposed acquired node contradicts any core node."""
```

**Logic:**
1. **Core conflict check:** If proposed subject matches a core node's subject (Dice bigram > 0.6) AND predicates conflict, reject with veto
2. **AntiPattern check:** If KG contains AntiPattern nodes and proposed content overlaps forbidden patterns (token overlap >= 50%), reject

**New status:** `rejected_contradiction` added to `VALID_STATUSES`

**Integration:** Called in `educate()` before `add_knowledge()` to gate all KG additions.

---

### Orchestrator Capsule Build (Commit: 8de8812)

Built query-to-capsule routing system per `ORCHESTRATOR_CAPSULE_BUILD_SPEC.md`.

#### New Capsule: `examples/orchestrator-v1.0.0-6cb4ea81/`

| File | Purpose |
|------|---------|
| `*-manifest.json` | Identity with router type |
| `*-definition.json` | Pipeline config: generate/review disabled, agent_type: router |
| `*-persona.json` | Operational tone, precise style |
| `*-kb.md` | Routing methodology, gap protocol, scoring weights |
| `*-kg.jsonld` | Empty graph (orchestrator has no domain knowledge) |

The `agent_type: router` ensures the orchestrator is excluded from routing to prevent loops.

#### New Functions in `habitat.py`

**1. `_load_capsule_meta(capsule_path)`** (lines 109-153)

Loads lightweight metadata from a capsule for scoring:
- manifest.json: id, name
- definition.json: agent_type, trigger_text, authoritative domains
- kg.jsonld: node count + all `rdfs:label` values

**2. `_score_capsule(query_tokens, capsule_meta, max_kg_nodes)`** (lines 156-214)

Scores capsule relevance to query with weighted signals:

| Signal | Weight | Source |
|--------|--------|--------|
| KG label overlap | 0.3 | `rdfs:label` tokens from KG nodes |
| trigger_text overlap | 0.25 | definition.json trigger_text |
| authoritative domain overlap | 0.25 | definition.json domain_boundaries |
| capsule name/id overlap | 0.1 | manifest name + agent_name |
| KG node count (normalized) | 0.1 | Tiebreaker for depth |

KG label overlap is calculated against query tokens, enabling semantic routing based on actual KG content.

**3. `orchestrate(query, registry_path, llm_fn, dry_run)`** (lines 217-335)

Main routing function:
1. Scan registry for valid capsules
2. Exclude router-type agents (prevent loops)
3. Score all capsules against query
4. If best score < 0.15 → report gap with recommendation
5. If dry_run → return routing decision without executing
6. Otherwise → load capsule, run pipeline, return result

#### CLI Command: `cmd_orchestrate()`

**File:** `cli.py` (lines 442-531, parser 637-644)

```bash
python cli.py orchestrate <query> --registry ./examples [--dry-run] [--provider stub] [--report full]
```

**Output includes:**
- Scored candidates (top 5)
- Selected capsule with score
- Gap detection with topic and recommendation
- Pipeline result with AEC score (if executed)

---

## Test Results

### Orchestrator Routing Tests

| Query | Expected | Result | Score |
|-------|----------|--------|-------|
| "How should I approach typography?" | Routes (not gap) | pptx | 0.2381 |
| "When was Jefferson born?" | jefferson | Thomas Jefferson Scholar | 0.2115 |
| "What is Buffett's investment philosophy?" | buffett | buffett | 0.3575 |
| "How do I use the Claude API?" | claude-api | claude-api | 0.3247 |

All queries route successfully (above 0.15 threshold). KG label matching provides the primary signal.

---

## Architecture Decisions Made Today

1. **KG labels are the primary routing signal (0.3 weight)** — Capsules with populated KGs route better than those with only trigger text.

2. **Gap threshold at 0.15** — Queries below this score report gaps rather than routing to poor matches.

3. **Router-type agents self-exclude** — Prevents routing loops; orchestrator never routes to itself.

4. **Anti-gaming via property filtering** — Node IDs never reach LLM prompts; only rdfs:label is visible.

5. **Contradiction gate is absolute** — Core nodes have veto power over conflicting acquired knowledge.

---

## File Summary

### Modified Files

| File | Changes |
|------|---------|
| `aether.py` | Anti-gaming fix in `_build_prompt()` |
| `education.py` | `_check_contradiction()`, new status `rejected_contradiction` |
| `habitat.py` | +240 lines: `_load_capsule_meta()`, `_score_capsule()`, `orchestrate()` |
| `cli.py` | +100 lines: `cmd_orchestrate()`, parser registration |

### New Files

| File | Purpose |
|------|---------|
| `examples/orchestrator-v1.0.0-6cb4ea81/*` | 5-file orchestrator capsule |

---

## Commands Reference

```bash
# Orchestrate (new)
aether orchestrate "query" --registry ./examples --dry-run   # Preview routing
aether orchestrate "query" --registry ./examples --provider anthropic  # Execute

# Existing commands
aether stamp "Agent Name" --output ./capsules
aether run <capsule> "query" --provider anthropic
aether validate <capsule>
aether export <capsule> --format claude-md
aether queue <capsule>
aether educate <capsule>
aether refine <capsule>
```

---

## Repository State

```
Branch: main
Latest commit: 8de8812
Remote: https://github.com/jeff0926/aether.git
Status: Clean (all changes committed and pushed)
```

---

## For New LLM Sessions

**To continue development:**

1. Read `IGNORE/documentation/` for spec files
2. Check for new `CLAUDE_CODE_PROMPT_Item*.md` files for next tasks
3. Test baseline: `python -m pytest tests/ -v -s`
4. Core entry point: `aether.py` → `Capsule` class
5. CLI entry point: `cli.py` → `main()`

**Key imports:**
```python
from aether import Capsule, generate_id, get_required_files
from habitat import Habitat, orchestrate
from stamper import stamp_empty, stamp_from_source, export_capsule
from education import refine_session, queue_failure, educate
from ui.dai_pulse import DAIPulse
```

**Run quick verification:**
```bash
python cli.py orchestrate "test query" --registry ./examples --dry-run
python aether.py
python habitat.py
```
