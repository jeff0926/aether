#!/usr/bin/env python3
"""
AETHER Full Diagnostic Suite
=============================
Exhaustive test of every module, every function, every capsule.
Run from project root: python IGNORE/daily/AETHER_FULL_DIAGNOSTIC.py

Produces a detailed report of what works, what's broken, what's missing.
"""

import sys
import os
import json
import time
import traceback
from pathlib import Path
from datetime import datetime
from io import StringIO

# Ensure we're running from project root
PROJECT_ROOT = Path(__file__).parent
if PROJECT_ROOT.name in ("daily", "IGNORE"):
    PROJECT_ROOT = PROJECT_ROOT.parent
    if PROJECT_ROOT.name == "IGNORE":
        PROJECT_ROOT = PROJECT_ROOT.parent
sys.path.insert(0, str(PROJECT_ROOT))

# Windows encoding fix
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

# ═══════════════════════════════════════════════════════════════════
# REPORT STATE
# ═══════════════════════════════════════════════════════════════════

results = {
    "timestamp": datetime.now().isoformat(),
    "sections": [],
    "pass_count": 0,
    "fail_count": 0,
    "skip_count": 0,
    "warnings": [],
}

current_section = None

def section(name):
    global current_section
    current_section = {"name": name, "tests": [], "pass": 0, "fail": 0, "skip": 0}
    results["sections"].append(current_section)
    print(f"\n{'='*70}")
    print(f"  {name}")
    print(f"{'='*70}")

def test(name, fn):
    """Run a single test, catch all errors."""
    global current_section
    start = time.time()
    try:
        result = fn()
        elapsed = round((time.time() - start) * 1000, 2)
        status = "PASS" if result is not False else "FAIL"
        detail = "" if result is True or result is None else str(result)[:200] if result is not False else ""
        if status == "PASS":
            current_section["pass"] += 1
            results["pass_count"] += 1
        else:
            current_section["fail"] += 1
            results["fail_count"] += 1
        current_section["tests"].append({"name": name, "status": status, "time_ms": elapsed, "detail": detail})
        icon = "✅" if status == "PASS" else "❌"
        print(f"  {icon} {name} ({elapsed}ms) {detail[:80]}")
        return result
    except Exception as e:
        elapsed = round((time.time() - start) * 1000, 2)
        current_section["fail"] += 1
        results["fail_count"] += 1
        error_msg = f"{type(e).__name__}: {str(e)[:150]}"
        current_section["tests"].append({"name": name, "status": "ERROR", "time_ms": elapsed, "detail": error_msg})
        print(f"  💥 {name} ({elapsed}ms) {error_msg}")
        return False

def skip(name, reason):
    global current_section
    current_section["skip"] += 1
    results["skip_count"] += 1
    current_section["tests"].append({"name": name, "status": "SKIP", "time_ms": 0, "detail": reason})
    print(f"  ⏭️  {name} — {reason}")

def warn(msg):
    results["warnings"].append(msg)
    print(f"  ⚠️  WARNING: {msg}")

# ═══════════════════════════════════════════════════════════════════
# SECTION 1: MODULE IMPORTS
# ═══════════════════════════════════════════════════════════════════

section("1. MODULE IMPORTS")

modules = {}

def import_module(name):
    def _test():
        mod = __import__(name)
        modules[name] = mod
        return True
    return _test

for mod_name in ["aec", "aether", "cli", "education", "habitat", "kg", "llm", "report", "stamper"]:
    test(f"import {mod_name}", import_module(mod_name))

# ═══════════════════════════════════════════════════════════════════
# SECTION 2: AEC — ENTAILMENT CHECK
# ═══════════════════════════════════════════════════════════════════

section("2. AEC — ENTAILMENT CHECK")

def test_split_statements():
    from aec import split_statements
    stmts = split_statements("Thomas Jefferson was born in 1743. He was a great leader. The Declaration was signed in 1776.")
    assert len(stmts) >= 2, f"Expected ≥2 statements, got {len(stmts)}"
    return f"{len(stmts)} statements"

def test_split_empty():
    from aec import split_statements
    assert split_statements("") == []
    assert split_statements("   ") == []
    return True

def test_extract_values_numbers():
    from aec import _extract_values
    vals = _extract_values("The price is 1,743 dollars and 25.5 percent")
    types = [v[2] for v in vals]
    assert "number" in types, f"No numbers found in {vals}"
    assert "percentage" in types, f"No percentages found in {vals}"
    return f"{len(vals)} values extracted"

def test_extract_values_dates():
    from aec import _extract_values
    vals = _extract_values("Born on April 13, 1743 and died in 1826")
    types = [v[2] for v in vals]
    assert "date" in types, f"No dates found in {vals}"
    return f"{len(vals)} values extracted"

def test_extract_values_names():
    from aec import _extract_values
    vals = _extract_values("Thomas Jefferson authored the Declaration of Independence")
    types = [v[2] for v in vals]
    assert "name" in types, f"No names found in {vals}"
    return f"{len(vals)} values extracted"

def test_extract_values_magnitude():
    from aec import _extract_values
    vals = _extract_values("Revenue was $25 million and assets totaled $373.3 billion")
    nums = [(v[0], v[1]) for v in vals if v[2] == "number"]
    has_million = any(abs(n - 25e6) < 1e3 for _, n in nums)
    has_billion = any(abs(n - 373.3e9) < 1e6 for _, n in nums)
    assert has_million, f"$25 million not extracted correctly: {nums}"
    assert has_billion, f"$373.3 billion not extracted correctly: {nums}"
    return f"magnitude extraction OK"

def test_deterministic_gate_match():
    from aec import deterministic_gate
    kg = [{"@id": "test:1", "rdfs:label": "Thomas Jefferson", "birth_year": 1743}]
    result = deterministic_gate("Thomas Jefferson was born in 1743", kg)
    assert result["matched"], f"Expected match: {result}"
    return f"method={result['method']}"

def test_deterministic_gate_no_match():
    from aec import deterministic_gate
    kg = [{"@id": "test:1", "birth_year": 1743}]
    result = deterministic_gate("The temperature is 99 degrees", kg)
    assert not result["matched"], f"Expected no match: {result}"
    return True

def test_deterministic_gate_no_values():
    from aec import deterministic_gate
    kg = [{"@id": "test:1", "rdfs:label": "Test"}]
    result = deterministic_gate("This is a qualitative statement about leadership", kg)
    assert result["method"] == "no_values", f"Expected no_values: {result}"
    return True

def test_verify_grounded():
    from aec import verify
    response = "Thomas Jefferson was born on April 13, 1743 in Virginia."
    kg = [{"@id": "p:j", "rdfs:label": "Thomas Jefferson", "birth_year": 1743, "birth_date": "1743-04-13", "birth_place": "Virginia"}]
    result = verify(response, kg)
    assert result["passed"], f"Expected pass: score={result['score']}"
    assert result["grounded_statements"] > 0
    return f"score={result['score']}, G={result['grounded_statements']}, U={result['ungrounded_statements']}, P={result['persona_statements']}"

def test_verify_ungrounded():
    from aec import verify
    response = "Jefferson was born in 1750 in New York."
    kg = [{"@id": "p:j", "rdfs:label": "Thomas Jefferson", "birth_year": 1743, "birth_place": "Virginia"}]
    result = verify(response, kg)
    # Should have ungrounded statements (wrong year, wrong place)
    return f"score={result['score']}, passed={result['passed']}, U={result['ungrounded_statements']}"

def test_verify_all_persona():
    from aec import verify
    response = "He was a brilliant thinker and visionary leader who inspired many people."
    kg = [{"@id": "p:j", "rdfs:label": "Thomas Jefferson"}]
    result = verify(response, kg)
    assert result["passed"], f"All-persona should pass: {result}"
    assert result["persona_statements"] > 0
    return f"score={result['score']}, persona={result['persona_statements']}"

def test_verify_empty():
    from aec import verify
    result = verify("", [])
    assert not result["passed"]
    return f"score={result['score']}"

def test_verify_numeric_tolerance():
    from aec import verify
    response = "The value is 100.5"
    kg = [{"@id": "t:1", "value": 100}]
    result = verify(response, kg)
    return f"score={result['score']} (100.5 vs 100 with 1% tolerance)"

test("split_statements — basic", test_split_statements)
test("split_statements — empty", test_split_empty)
test("extract_values — numbers + percentages", test_extract_values_numbers)
test("extract_values — dates", test_extract_values_dates)
test("extract_values — names", test_extract_values_names)
test("extract_values — magnitude ($25 million)", test_extract_values_magnitude)
test("deterministic_gate — match", test_deterministic_gate_match)
test("deterministic_gate — no match", test_deterministic_gate_no_match)
test("deterministic_gate — no extractable values", test_deterministic_gate_no_values)
test("verify — grounded response", test_verify_grounded)
test("verify — ungrounded response", test_verify_ungrounded)
test("verify — all persona (should pass)", test_verify_all_persona)
test("verify — empty input", test_verify_empty)
test("verify — numeric tolerance", test_verify_numeric_tolerance)

# ═══════════════════════════════════════════════════════════════════
# SECTION 3: KG — KNOWLEDGE GRAPH
# ═══════════════════════════════════════════════════════════════════

section("3. KG — KNOWLEDGE GRAPH")

def test_kg_empty():
    from kg import load_kg, get_nodes, stats, EMPTY_KG
    kg = {"@context": EMPTY_KG["@context"].copy(), "@graph": []}
    s = stats(kg)
    assert s["total"] == 0
    return f"empty KG stats: {s}"

def test_kg_add_knowledge():
    from kg import load_kg, add_knowledge, get_nodes, stats, EMPTY_KG
    kg = {"@context": EMPTY_KG["@context"].copy(), "@graph": []}
    kg = add_knowledge(kg, {
        "subject": "Test Fact",
        "predicate": "rdfs:comment",
        "object": "Learned via AEC",
        "confidence": 0.85,
        "aec_trigger": "test",
    }, origin="acquired")
    s = stats(kg)
    assert s["acquired"] == 1, f"Expected 1 acquired, got {s}"
    return f"after add: {s}"

def test_kg_add_all_origins():
    from kg import add_knowledge, stats, EMPTY_KG
    kg = {"@context": EMPTY_KG["@context"].copy(), "@graph": []}
    for origin in ["core", "acquired", "updated", "deprecated", "provenance"]:
        kg = add_knowledge(kg, {
            "subject": f"{origin}_node",
            "predicate": "test",
            "object": "value",
        }, origin=origin)
    s = stats(kg)
    assert s["total"] == 5, f"Expected 5 total: {s}"
    return f"all origins: {s}"

def test_kg_invalid_origin():
    from kg import add_knowledge, EMPTY_KG
    kg = {"@context": EMPTY_KG["@context"].copy(), "@graph": []}
    try:
        add_knowledge(kg, {"subject": "x", "predicate": "y", "object": "z"}, origin="invalid")
        return False  # Should have raised
    except ValueError:
        return True

def test_kg_mark_deprecated():
    from kg import add_knowledge, mark_deprecated, get_deprecated_nodes, EMPTY_KG
    kg = {"@context": EMPTY_KG["@context"].copy(), "@graph": [
        {"@id": "test:1", "rdfs:label": "Old Fact", "value": 100}
    ]}
    kg = mark_deprecated(kg, "test:1", reason="outdated")
    deprecated = get_deprecated_nodes(kg)
    assert len(deprecated) == 1
    return f"deprecated: {deprecated[0].get('rdfs:label')}"

def test_kg_mark_updated():
    from kg import mark_updated, EMPTY_KG
    kg = {"@context": EMPTY_KG["@context"].copy(), "@graph": [
        {"@id": "test:1", "rdfs:label": "Fact", "value": 100}
    ]}
    kg = mark_updated(kg, "test:1", {"value": 200})
    node = kg["@graph"][0]
    assert node["value"] == 200
    assert node.get("aether:origin") == "updated"
    return True

def test_kg_query_nodes():
    from kg import query_nodes, EMPTY_KG
    kg = {"@context": EMPTY_KG["@context"].copy(), "@graph": [
        {"@id": "p:jefferson", "rdfs:label": "Thomas Jefferson", "role": "President"},
        {"@id": "p:hamilton", "rdfs:label": "Alexander Hamilton", "role": "Secretary"},
        {"@id": "d:declaration", "rdfs:label": "Declaration of Independence"},
    ]}
    matches = query_nodes(kg, ["Jefferson"])
    assert len(matches) >= 1, f"Expected match for 'Jefferson': {matches}"
    return f"{len(matches)} matches for 'Jefferson'"

def test_kg_query_empty():
    from kg import query_nodes, EMPTY_KG
    kg = {"@context": EMPTY_KG["@context"].copy(), "@graph": []}
    assert query_nodes(kg, ["anything"]) == []
    assert query_nodes(kg, []) == []
    return True

def test_kg_load_nonexistent():
    from kg import load_kg
    kg = load_kg("/nonexistent/path.jsonld")
    assert "@graph" in kg
    assert len(kg["@graph"]) == 0
    return "returns empty KG"

test("empty KG", test_kg_empty)
test("add_knowledge (acquired)", test_kg_add_knowledge)
test("add_knowledge (all 5 origins)", test_kg_add_all_origins)
test("add_knowledge (invalid origin → ValueError)", test_kg_invalid_origin)
test("mark_deprecated", test_kg_mark_deprecated)
test("mark_updated", test_kg_mark_updated)
test("query_nodes — match", test_kg_query_nodes)
test("query_nodes — empty", test_kg_query_empty)
test("load_kg — nonexistent file", test_kg_load_nonexistent)

# ═══════════════════════════════════════════════════════════════════
# SECTION 4: STAMPER — CAPSULE FACTORY
# ═══════════════════════════════════════════════════════════════════

section("4. STAMPER — CAPSULE FACTORY")

import tempfile
import re

def test_stamp_empty():
    from stamper import stamp_empty, validate_capsule
    with tempfile.TemporaryDirectory() as tmp:
        path = stamp_empty("Test Agent", tmp)
        assert path.is_dir()
        v = validate_capsule(path)
        assert v["valid"], f"Validation failed: {v}"
        files = list(path.iterdir())
        assert len(files) == 5, f"Expected 5 files, got {len(files)}"
        return f"{path.name} — {len(files)} files"

def test_stamp_id_format():
    from stamper import stamp_empty
    with tempfile.TemporaryDirectory() as tmp:
        path = stamp_empty("My Cool Agent", tmp)
        pattern = r"^[a-z0-9-]+-v\d+\.\d+\.\d+-[a-f0-9]{8}$"
        assert re.match(pattern, path.name), f"ID format mismatch: {path.name}"
        return path.name

def test_stamp_from_md():
    from stamper import stamp_from_source
    with tempfile.TemporaryDirectory() as tmp:
        # Create source markdown
        src = Path(tmp) / "source.md"
        src.write_text("# Test KB\n\nThis is test knowledge.", encoding="utf-8")
        path = stamp_from_source("From MD", str(src), tmp)
        kb_file = [f for f in path.iterdir() if f.name.endswith("-kb.md")][0]
        content = kb_file.read_text(encoding="utf-8")
        assert "test knowledge" in content
        return f"KB populated from {src.name}"

def test_stamp_from_jsonld():
    from stamper import stamp_from_source
    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / "source.jsonld"
        kg_data = {"@context": {}, "@graph": [{"@id": "test:1", "value": 42}]}
        src.write_text(json.dumps(kg_data), encoding="utf-8")
        path = stamp_from_source("From KG", str(src), tmp)
        kg_file = [f for f in path.iterdir() if f.name.endswith("-kg.jsonld")][0]
        data = json.loads(kg_file.read_text(encoding="utf-8"))
        assert len(data.get("@graph", [])) == 1
        return "KG populated from source"

def test_restamp_lineage():
    from stamper import stamp_empty, restamp
    with tempfile.TemporaryDirectory() as tmp:
        v1 = stamp_empty("Lineage Test", tmp)
        v2 = restamp(v1, "2.0.0")
        from aether import get_required_files
        files = get_required_files(v2.name)
        manifest = json.loads((v2 / files["manifest"]).read_text(encoding="utf-8"))
        assert manifest.get("previous_id") == v1.name
        assert manifest.get("previous_version") == "1.0.0"
        return f"{v1.name} → {v2.name}"

def test_validate_invalid():
    from stamper import validate_capsule
    with tempfile.TemporaryDirectory() as tmp:
        fake = Path(tmp) / "not-a-capsule"
        fake.mkdir()
        v = validate_capsule(fake)
        assert not v["valid"]
        return f"missing: {len(v['missing'])} files"

test("stamp_empty — create + validate", test_stamp_empty)
test("stamp_empty — ID format", test_stamp_id_format)
test("stamp_from_source — markdown", test_stamp_from_md)
test("stamp_from_source — JSON-LD", test_stamp_from_jsonld)
test("restamp — lineage tracking", test_restamp_lineage)
test("validate_capsule — invalid folder", test_validate_invalid)

# ═══════════════════════════════════════════════════════════════════
# SECTION 5: CAPSULE LOADING & VALIDATION
# ═══════════════════════════════════════════════════════════════════

section("5. CAPSULE LOADING & VALIDATION")

EXAMPLES_DIR = PROJECT_ROOT / "examples"
CAPSULE_DIRS = []

if EXAMPLES_DIR.is_dir():
    CAPSULE_DIRS = [d for d in EXAMPLES_DIR.iterdir() if d.is_dir()]

def test_examples_exist():
    assert EXAMPLES_DIR.is_dir(), f"examples/ directory not found at {EXAMPLES_DIR}"
    assert len(CAPSULE_DIRS) >= 1, "No capsule folders in examples/"
    return f"{len(CAPSULE_DIRS)} capsules found"

test("examples/ directory exists", test_examples_exist)

for capsule_dir in CAPSULE_DIRS:
    cap_name = capsule_dir.name

    def make_validate_test(d):
        def _test():
            from stamper import validate_capsule
            v = validate_capsule(d)
            if not v["valid"]:
                return f"INVALID — missing: {v['missing']}, errors: {v['errors']}"
            return True
        return _test

    def make_load_test(d):
        def _test():
            from aether import Capsule
            cap = Capsule(d)
            assert cap.id
            assert cap.name
            assert cap.version
            return f"id={cap.id}, name={cap.name}, v{cap.version}"
        return _test

    def make_file_sizes_test(d):
        def _test():
            sizes = {}
            for f in d.iterdir():
                sizes[f.suffix] = f.stat().st_size
            total = sum(sizes.values())
            return f"total={total:,}B — {sizes}"
        return _test

    def make_kg_stats_test(d):
        def _test():
            from aether import get_required_files
            from kg import load_kg, stats
            files = get_required_files(d.name)
            kg_path = d / files["kg"]
            if not kg_path.exists():
                return False
            kg = load_kg(kg_path)
            s = stats(kg)
            return f"nodes={s['total']}, core={s['core']}, acquired={s['acquired']}"
        return _test

    def make_education_queue_test(d):
        def _test():
            from education import queue_stats
            s = queue_stats(d)
            return f"total={s['total']}, pending={s['pending']}, integrated={s['integrated']}"
        return _test

    test(f"[{cap_name}] validate", make_validate_test(capsule_dir))
    test(f"[{cap_name}] load Capsule", make_load_test(capsule_dir))
    test(f"[{cap_name}] file sizes", make_file_sizes_test(capsule_dir))
    test(f"[{cap_name}] KG stats", make_kg_stats_test(capsule_dir))
    test(f"[{cap_name}] education queue", make_education_queue_test(capsule_dir))

# ═══════════════════════════════════════════════════════════════════
# SECTION 6: PIPELINE EXECUTION (STUB LLM)
# ═══════════════════════════════════════════════════════════════════

section("6. PIPELINE EXECUTION (stub LLM)")

for capsule_dir in CAPSULE_DIRS:
    cap_name = capsule_dir.name

    def make_pipeline_test(d):
        def _test():
            from aether import Capsule
            from llm import make_llm_fn
            llm_fn = make_llm_fn(provider="stub")
            cap = Capsule(d, llm_fn=llm_fn)
            ctx = cap.run("What can you tell me about this topic?")

            # Check all pipeline stages ran
            stages = ctx.get("telemetry", {}).get("stages", {})
            ran = list(stages.keys())
            total_ms = ctx.get("telemetry", {}).get("total_ms", 0)

            # Check AEC ran
            aec = ctx.get("review", {}).get("aec", {})
            score = aec.get("score", -1)
            passed = aec.get("passed", None)

            return (f"stages={ran}, total={total_ms:.1f}ms, "
                    f"aec_score={score}, aec_passed={passed}, "
                    f"queued={ctx.get('review', {}).get('queued', '?')}")
        return _test

    test(f"[{cap_name}] full pipeline (stub)", make_pipeline_test(capsule_dir))

# ═══════════════════════════════════════════════════════════════════
# SECTION 7: PIPELINE STAGES — DETAILED
# ═══════════════════════════════════════════════════════════════════

section("7. PIPELINE STAGES — DETAILED")

def test_distill_intents():
    from aether import Capsule
    from llm import make_llm_fn
    # Use first available capsule
    if not CAPSULE_DIRS:
        return False
    cap = Capsule(CAPSULE_DIRS[0], llm_fn=make_llm_fn(provider="stub"))

    intents_map = {
        "What is democracy?": "query",
        "How do I build a house?": "instruction",
        "Compare Hamilton and Jefferson": "comparison",
        "Create a new policy": "creation",
        "Hello there": "general",
    }
    results = []
    for query, expected in intents_map.items():
        ctx = {"input": query}
        ctx = cap.distill(ctx)
        actual = ctx["distilled"]["intent"]
        match = "✓" if actual == expected else f"✗ (got {actual})"
        results.append(f"{expected}={match}")
    return ", ".join(results)

def test_augment_matching():
    from aether import Capsule
    from llm import make_llm_fn
    if not CAPSULE_DIRS:
        return False
    # Use jefferson capsule if available
    jeff = [d for d in CAPSULE_DIRS if "jefferson" in d.name.lower()]
    cap_dir = jeff[0] if jeff else CAPSULE_DIRS[0]
    cap = Capsule(cap_dir, llm_fn=make_llm_fn(provider="stub"))

    ctx = {"input": "Tell me about Thomas Jefferson", "distilled": {"entities": ["Thomas", "Jefferson"], "intent": "query"}}
    ctx = cap.augment(ctx)
    kb_count = len(ctx["augmented"].get("kb", []))
    kg_count = len(ctx["augmented"].get("kg", []))
    return f"kb_matches={kb_count}, kg_matches={kg_count}"

def test_augment_no_entities():
    from aether import Capsule
    from llm import make_llm_fn
    if not CAPSULE_DIRS:
        return False
    cap = Capsule(CAPSULE_DIRS[0], llm_fn=make_llm_fn(provider="stub"))
    ctx = {"input": "hello", "distilled": {"entities": [], "intent": "general"}}
    ctx = cap.augment(ctx)
    kb_count = len(ctx["augmented"].get("kb", []))
    kg_count = len(ctx["augmented"].get("kg", []))
    return f"kb_matches={kb_count}, kg_matches={kg_count} (expected 0,0 with no entities)"

test("distill — intent classification", test_distill_intents)
test("augment — entity matching", test_augment_matching)
test("augment — no entities", test_augment_no_entities)

# ═══════════════════════════════════════════════════════════════════
# SECTION 8: EDUCATION QUEUE
# ═══════════════════════════════════════════════════════════════════

section("8. EDUCATION QUEUE")

def test_education_queue_roundtrip():
    from education import queue_failure, get_queue, get_pending, update_status, queue_stats
    with tempfile.TemporaryDirectory() as tmp:
        cap = Path(tmp) / "test-cap"
        cap.mkdir()
        aec_result = {"score": 0.4, "threshold": 0.8, "passed": False, "gaps": [{"text": "wrong", "reason": "test"}]}
        record = queue_failure(cap, "test query", "test response", aec_result)
        assert record["status"] == "pending"
        assert record["aec_score"] == 0.4

        q = get_queue(cap)
        assert len(q) == 1

        p = get_pending(cap)
        assert len(p) == 1

        update_status(cap, record["id"], "researching")
        q = get_queue(cap)
        assert q[0]["status"] == "researching"

        s = queue_stats(cap)
        assert s["total"] == 1
        assert s["researching"] == 1
        return f"queue roundtrip OK: {s}"

def test_education_statuses():
    from education import VALID_STATUSES
    expected = ["pending", "researching", "validated", "integrated", "failed"]
    assert VALID_STATUSES == expected, f"Unexpected statuses: {VALID_STATUSES}"
    return f"statuses: {VALID_STATUSES}"

def test_education_invalid_status():
    from education import update_status
    with tempfile.TemporaryDirectory() as tmp:
        cap = Path(tmp) / "test-cap"
        cap.mkdir()
        try:
            update_status(cap, "fake-id", "invalid_status")
            return False
        except ValueError:
            return True

def test_education_get_oldest():
    from education import queue_failure, get_oldest_pending
    with tempfile.TemporaryDirectory() as tmp:
        cap = Path(tmp) / "test-cap"
        cap.mkdir()
        aec = {"score": 0.3, "threshold": 0.8, "passed": False, "gaps": []}
        queue_failure(cap, "first", "resp1", aec)
        import time; time.sleep(0.01)
        queue_failure(cap, "second", "resp2", aec)
        oldest = get_oldest_pending(cap)
        assert oldest["query"] == "first"
        return "oldest = first query"

test("queue roundtrip (queue → get → update → stats)", test_education_queue_roundtrip)
test("valid statuses list", test_education_statuses)
test("invalid status → ValueError", test_education_invalid_status)
test("get_oldest_pending", test_education_get_oldest)

# ═══════════════════════════════════════════════════════════════════
# SECTION 9: HABITAT — CAPSULE REGISTRY
# ═══════════════════════════════════════════════════════════════════

section("9. HABITAT — CAPSULE REGISTRY")

def test_habitat_register():
    from habitat import Habitat
    h = Habitat()
    h.register("agent-001", {"name": "Test", "scent_subscriptions": ["topic.*"]})
    capsules = h.list_capsules()
    assert len(capsules) == 1
    return f"registered: {capsules[0]['name']}"

def test_habitat_route_exact():
    from habitat import Habitat
    h = Habitat()
    h.register("a1", {"scent_subscriptions": ["market.analysis"]})
    h.register("a2", {"scent_subscriptions": ["weather.forecast"]})
    matches = h.route("market.analysis")
    assert "a1" in matches
    assert "a2" not in matches
    return f"routed to: {matches}"

def test_habitat_route_wildcard():
    from habitat import Habitat
    h = Habitat()
    h.register("a1", {"scent_subscriptions": ["market.*"]})
    matches = h.route("market.analysis")
    assert "a1" in matches
    return f"wildcard match: {matches}"

def test_habitat_detect_gaps():
    from habitat import Habitat
    h = Habitat()
    h.register("a1", {"scent_subscriptions": ["market.*"]})
    assert h.detect_gaps("market.analysis") == False  # Has handler
    assert h.detect_gaps("sports.scores") == True  # No handler
    return "gap detection OK"

def test_habitat_broadcast():
    from habitat import Habitat
    h = Habitat()
    h.register("a1", {"scent_subscriptions": ["test.topic"]})
    result = h.broadcast("test.topic", {"data": "hello"})
    assert "a1" in result["recipients"]
    return f"broadcast to {len(result['recipients'])} recipients"

def test_habitat_stats():
    from habitat import Habitat
    h = Habitat()
    h.register("a1", {"scent_subscriptions": ["x", "y"]})
    h.register("a2", {"scent_subscriptions": ["y", "z"]})
    s = h.stats()
    assert s["capsules"] == 2
    return f"stats: {s}"

test("register + list", test_habitat_register)
test("route — exact match", test_habitat_route_exact)
test("route — wildcard", test_habitat_route_wildcard)
test("detect_gaps", test_habitat_detect_gaps)
test("broadcast", test_habitat_broadcast)
test("stats", test_habitat_stats)

# ═══════════════════════════════════════════════════════════════════
# SECTION 10: LLM WRAPPER
# ═══════════════════════════════════════════════════════════════════

section("10. LLM WRAPPER")

def test_llm_stub():
    from llm import call_llm
    result = call_llm("Hello", provider="stub")
    assert "text" in result
    assert result["cost"] == 0.0
    return f"stub response: {result['text'][:50]}"

def test_llm_make_fn():
    from llm import make_llm_fn
    fn = make_llm_fn(provider="stub")
    result = fn("Test prompt")
    assert isinstance(result, dict)
    assert "text" in result
    return True

def test_llm_unknown_provider():
    from llm import call_llm
    result = call_llm("Hello", provider="nonexistent")
    assert "Error" in result["text"] or "Unknown" in result["text"]
    return f"handled gracefully: {result['text'][:60]}"

def test_llm_cost_estimation():
    from llm import estimate_cost
    cost = estimate_cost("claude-sonnet-4-20250514", 1000, 500)
    assert cost > 0
    return f"${cost:.6f} (1000 in, 500 out, Sonnet)"

def test_llm_anthropic_no_key():
    from llm import call_llm
    # Force no key by passing empty string
    result = call_llm("Hello", provider="anthropic", api_key="")
    # Should handle gracefully (error message, not crash)
    return f"handled: {result['text'][:60]}"

test("stub provider", test_llm_stub)
test("make_llm_fn", test_llm_make_fn)
test("unknown provider", test_llm_unknown_provider)
test("cost estimation", test_llm_cost_estimation)
test("anthropic without key", test_llm_anthropic_no_key)

# ═══════════════════════════════════════════════════════════════════
# SECTION 11: CROSS-MODULE INTEGRATION
# ═══════════════════════════════════════════════════════════════════

section("11. CROSS-MODULE INTEGRATION")

def test_capsule_to_aec():
    """Capsule pipeline feeds AEC correctly."""
    from aether import Capsule
    from llm import make_llm_fn
    if not CAPSULE_DIRS:
        return False
    cap = Capsule(CAPSULE_DIRS[0], llm_fn=make_llm_fn(provider="stub"))
    ctx = cap.run("Tell me something")
    assert "review" in ctx
    assert "aec" in ctx["review"]
    assert "score" in ctx["review"]["aec"]
    return f"pipeline→AEC: score={ctx['review']['aec']['score']}"

def test_aec_failure_queues():
    """When AEC fails, education queue gets entry."""
    from aether import Capsule
    from llm import make_llm_fn
    from education import get_queue
    if not CAPSULE_DIRS:
        return False
    cap = Capsule(CAPSULE_DIRS[0], llm_fn=make_llm_fn(provider="stub"))
    ctx = cap.run("Tell me about something obscure with numbers 99999")
    queued = ctx.get("review", {}).get("queued", False)
    return f"queued={queued}, aec_passed={ctx.get('review', {}).get('passed', '?')}"

def test_validate_then_load():
    """validate_folder + Capsule constructor."""
    from aether import validate_folder, Capsule
    if not CAPSULE_DIRS:
        return False
    d = CAPSULE_DIRS[0]
    missing = validate_folder(d)
    assert missing == [], f"Missing files: {missing}"
    cap = Capsule(d)
    assert cap.id
    return f"validate→load OK: {cap.id}"

def test_generate_id_uniqueness():
    """IDs should be unique even for same name."""
    from aether import generate_id
    import time
    id1 = generate_id("Test Agent", "1.0.0")
    time.sleep(0.01)
    id2 = generate_id("Test Agent", "1.0.0")
    assert id1 != id2, f"IDs should differ: {id1} vs {id2}"
    return f"{id1} ≠ {id2}"

test("pipeline → AEC integration", test_capsule_to_aec)
test("AEC failure → education queue", test_aec_failure_queues)
test("validate_folder → Capsule load", test_validate_then_load)
test("generate_id uniqueness", test_generate_id_uniqueness)

# ═══════════════════════════════════════════════════════════════════
# SECTION 12: FILE INTEGRITY
# ═══════════════════════════════════════════════════════════════════

section("12. FILE INTEGRITY")

def test_all_modules_under_400_lines():
    """Design principle: no file exceeds ~300 lines (target)."""
    over = []
    for py in PROJECT_ROOT.glob("*.py"):
        lines = len(py.read_text(encoding="utf-8").splitlines())
        if lines > 400:
            over.append(f"{py.name}={lines}")
    if over:
        warn(f"Files over 400 lines: {over}")
        return f"WARNING: {over}"
    return "all modules under 400 lines"

def test_no_circular_imports():
    """All modules should import without errors (already tested in section 1)."""
    # If section 1 passed, we're good
    import_results = results["sections"][0]["tests"] if results["sections"] else []
    failures = [t for t in import_results if t["status"] != "PASS"]
    if failures:
        return False
    return f"all {len(import_results)} modules import cleanly"

def test_readme_exists():
    readme = PROJECT_ROOT / "README.md"
    assert readme.exists()
    lines = len(readme.read_text(encoding="utf-8").splitlines())
    return f"README.md: {lines} lines"

def test_gitignore_exists():
    gi = PROJECT_ROOT / ".gitignore"
    assert gi.exists()
    return True

def test_env_exists():
    env = PROJECT_ROOT / ".env"
    if env.exists():
        return "present"
    else:
        warn(".env file not found — LLM calls will fail without API key")
        return "MISSING"

test("module line counts", test_all_modules_under_400_lines)
test("no circular imports", test_no_circular_imports)
test("README.md exists", test_readme_exists)
test(".gitignore exists", test_gitignore_exists)
test(".env exists", test_env_exists)

# ═══════════════════════════════════════════════════════════════════
# FINAL REPORT
# ═══════════════════════════════════════════════════════════════════

print("\n")
print("╔══════════════════════════════════════════════════════════════════════╗")
print("║                    AETHER DIAGNOSTIC REPORT                        ║")
print(f"║  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}                                           ║")
print("╠══════════════════════════════════════════════════════════════════════╣")

total = results["pass_count"] + results["fail_count"] + results["skip_count"]
print(f"║  TOTAL TESTS:  {total:<5}                                              ║")
print(f"║  ✅ PASSED:     {results['pass_count']:<5}                                              ║")
print(f"║  ❌ FAILED:     {results['fail_count']:<5}                                              ║")
print(f"║  ⏭️  SKIPPED:    {results['skip_count']:<5}                                              ║")
print("╠══════════════════════════════════════════════════════════════════════╣")

for sec in results["sections"]:
    icon = "✅" if sec["fail"] == 0 else "❌"
    print(f"║  {icon} {sec['name']:<40} {sec['pass']}P {sec['fail']}F {sec['skip']}S ║")

print("╠══════════════════════════════════════════════════════════════════════╣")

if results["warnings"]:
    print("║  WARNINGS:                                                          ║")
    for w in results["warnings"]:
        print(f"║    ⚠️  {w:<60} ║")
    print("╠══════════════════════════════════════════════════════════════════════╣")

if results["fail_count"] == 0:
    print("║  🎯 ALL TESTS PASSED — AETHER CORE IS STABLE                       ║")
else:
    print(f"║  ⚠️  {results['fail_count']} FAILURE(S) DETECTED — REVIEW NEEDED                     ║")

print("╚══════════════════════════════════════════════════════════════════════╝")

# Save JSON report
report_path = PROJECT_ROOT / "IGNORE" / "daily" / f"diagnostic-{datetime.now().strftime('%Y-%m-%d')}.json"
try:
    report_path.parent.mkdir(parents=True, exist_ok=True)
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, default=str)
    print(f"\nJSON report saved: {report_path}")
except Exception as e:
    print(f"\nCould not save JSON report: {e}")

