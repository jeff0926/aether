# AETHER System Diagnostic Report
## Generated: 2026-03-12T11:11:05.963924
## Framework Version: Phase 2

---

### Executive Summary
- **Total tests:** 358
- **Passed:** 355
- **Failed:** 3
- **Pass rate:** 99.2%

---

### Module Health

| Module | Import | Notes |
|--------|--------|-------|
| `aec` | PASS |  |
| `aether` | PASS |  |
| `cli` | PASS |  |
| `education` | PASS |  |
| `habitat` | PASS |  |
| `kg` | PASS |  |
| `llm` | PASS |  |
| `report` | PASS |  |
| `stamper` | PASS |  |


### AEC Verification Tests

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| split_basic | 3 | 3 | PASS |
| split_abbreviations | 2 | 2 | PASS |
| split_empty | [] | [] | PASS |
| split_short | [] | [] | PASS |
| extract_numbers | True | True | PASS |
| extract_year | True | True | PASS |
| extract_full_date | True | True | PASS |
| extract_percentage | True | False | FAIL |
| extract_name | True | True | PASS |
| extract_magnitude_million | True | True | PASS |
| extract_magnitude_billion | True | True | PASS |
| gate_match | True | True | PASS |
| gate_no_match | False | True | FAIL |
| gate_no_values | no_values | no_values | PASS |
| gate_empty_kg | no_input | no_input | PASS |
| verify_grounded_score | True | True | PASS |
| verify_grounded_passed | True | True | PASS |
| verify_mixed_has_ungrounded | True | True | PASS |
| verify_all_persona_passes | True | True | PASS |
| verify_all_persona_score | 1.0 | 1.0 | PASS |
| verify_empty_response | False | False | PASS |
| verify_numeric_tolerance | True | True | PASS |


### Knowledge Graph Tests

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| load_nonexistent | True | True | PASS |
| stats_core | 1 | 1 | PASS |
| stats_acquired | 1 | 1 | PASS |
| stats_provenance | 1 | 1 | PASS |
| mark_deprecated | 1 | 1 | PASS |
| stats_deprecated | 1 | 1 | PASS |
| mark_updated_value | 150 | 150 | PASS |
| query_nodes | True | True | PASS |
| query_empty | [] | [] | PASS |
| invalid_origin | ValueError | ValueError | PASS |
| save_reload | 3 | 3 | PASS |


### Capsule & Pipeline Tests

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| validate_aether-validator-v1.0.0-d5a16071 | [] | [] | PASS |
| validate_algorithmic-art-v1.0.0-96ad66bb | [] | [] | PASS |
| validate_brand-guidelines-v1.0.0-e6dde892 | [] | [] | PASS |
| validate_canvas-design-v1.0.0-04e28042 | [] | [] | PASS |
| validate_claude-api-v1.0.0-c43fcb17 | [] | [] | PASS |
| validate_doc-coauthoring-v1.0.0-4bfea1b8 | [] | [] | PASS |
| validate_docx-v1.0.0-bd7cc055 | [] | [] | PASS |
| validate_domain-agent-builder | [] | [] | PASS |
| validate_domain-sap-cap-v1.0.0-f23f10ee | [] | [] | PASS |
| validate_frontend-design-v1.0.0-0f96de3e | [] | [] | PASS |
| validate_frontend-design-v1.0.0-27245b0a | [] | [] | PASS |
| validate_frontend-design-v1.0.0-38620c5e | [] | [] | PASS |
| validate_frontend-design-v1.0.0-a97550c4 | [] | [] | PASS |
| validate_frontend-design-v1.0.0-aed0ec02 | [] | [] | PASS |
| validate_frontend-design-v1.0.0-c0c8ecdf | [] | [] | PASS |
| validate_frontend-design-v1.0.0-c4ebfb1c | [] | [] | PASS |
| validate_frontend-design-v1.0.0-ff6ab491 | [] | [] | PASS |
| validate_internal-comms-v1.0.0-1984d41b | [] | [] | PASS |
| validate_jefferson | [] | [] | PASS |
| validate_mcp-builder-v1.0.0-689f2526 | [] | [] | PASS |
| validate_pdf-v1.0.0-9ab91eb5 | [] | [] | PASS |
| validate_pptx-v1.0.0-31e5aa80 | [] | [] | PASS |
| validate_scholar-buffett | [] | [] | PASS |
| validate_skill-creator-v1.0.0-9a0ea093 | [] | [] | PASS |
| validate_slack-gif-creator-v1.0.0-2630f4cd | [] | [] | PASS |
| validate_test-agent-v1.0.0-24f8476e | [] | [] | PASS |
| validate_theme-factory-v1.0.0-0a693e1e | [] | [] | PASS |
| validate_web-artifacts-builder-v1.0.0-589d4c03 | [] | [] | PASS |
| validate_webapp-testing-v1.0.0-9906c370 | [] | [] | PASS |
| validate_xlsx-v1.0.0-f6f859fc | [] | [] | PASS |
| load_aether-validator-v1.0.0-d5a16071 | True | True | PASS |
| load_algorithmic-art-v1.0.0-96ad66bb | True | True | PASS |
| load_brand-guidelines-v1.0.0-e6dde892 | True | True | PASS |
| load_canvas-design-v1.0.0-04e28042 | True | True | PASS |
| load_claude-api-v1.0.0-c43fcb17 | True | True | PASS |
| load_doc-coauthoring-v1.0.0-4bfea1b8 | True | True | PASS |
| load_docx-v1.0.0-bd7cc055 | True | True | PASS |
| load_domain-agent-builder | True | True | PASS |
| load_domain-sap-cap-v1.0.0-f23f10ee | True | True | PASS |
| load_frontend-design-v1.0.0-0f96de3e | True | True | PASS |
| load_frontend-design-v1.0.0-27245b0a | True | True | PASS |
| load_frontend-design-v1.0.0-38620c5e | True | True | PASS |
| load_frontend-design-v1.0.0-a97550c4 | True | True | PASS |
| load_frontend-design-v1.0.0-aed0ec02 | True | True | PASS |
| load_frontend-design-v1.0.0-c0c8ecdf | True | True | PASS |
| load_frontend-design-v1.0.0-c4ebfb1c | True | True | PASS |
| load_frontend-design-v1.0.0-ff6ab491 | True | True | PASS |
| load_internal-comms-v1.0.0-1984d41b | True | True | PASS |
| load_jefferson | True | True | PASS |
| load_mcp-builder-v1.0.0-689f2526 | True | True | PASS |
| load_pdf-v1.0.0-9ab91eb5 | True | True | PASS |
| load_pptx-v1.0.0-31e5aa80 | True | True | PASS |
| load_scholar-buffett | True | True | PASS |
| load_skill-creator-v1.0.0-9a0ea093 | True | True | PASS |
| load_slack-gif-creator-v1.0.0-2630f4cd | True | True | PASS |
| load_test-agent-v1.0.0-24f8476e | True | True | PASS |
| load_theme-factory-v1.0.0-0a693e1e | True | True | PASS |
| load_web-artifacts-builder-v1.0.0-589d4c03 | True | True | PASS |
| load_webapp-testing-v1.0.0-9906c370 | True | True | PASS |
| load_xlsx-v1.0.0-f6f859fc | True | True | PASS |
| run_jefferson_distill | True | True | PASS |
| run_jefferson_augment | True | True | PASS |
| run_jefferson_generate | True | True | PASS |
| run_jefferson_review | True | True | PASS |
| run_jefferson_telemetry | True | True | PASS |
| run_scholar-buffett_distill | True | True | PASS |
| run_scholar-buffett_augment | True | True | PASS |
| run_scholar-buffett_generate | True | True | PASS |
| run_scholar-buffett_review | True | True | PASS |
| run_scholar-buffett_telemetry | True | True | PASS |
| run_test-agent-v1.0.0-24f8476e_distill | True | True | PASS |
| run_test-agent-v1.0.0-24f8476e_augment | True | True | PASS |
| run_test-agent-v1.0.0-24f8476e_generate | True | True | PASS |
| run_test-agent-v1.0.0-24f8476e_review | True | True | PASS |
| run_test-agent-v1.0.0-24f8476e_telemetry | True | True | PASS |
| validator_generate_disabled | False | False | PASS |
| generate_id_format | True | True | PASS |
| aether-validator-v1.0.0-d5a16071_files_exist | True | True | PASS |
| aether-validator-v1.0.0-d5a16071_manifest_id | True | True | PASS |
| aether-validator-v1.0.0-d5a16071_manifest_version | True | True | PASS |
| aether-validator-v1.0.0-d5a16071_definition_pipeline | True | True | PASS |
| aether-validator-v1.0.0-d5a16071_persona_parse | True | True | PASS |
| aether-validator-v1.0.0-d5a16071_kb_nonempty | True | True | PASS |
| aether-validator-v1.0.0-d5a16071_kg_graph | True | True | PASS |
| algorithmic-art-v1.0.0-96ad66bb_files_exist | True | True | PASS |
| algorithmic-art-v1.0.0-96ad66bb_manifest_id | True | True | PASS |
| algorithmic-art-v1.0.0-96ad66bb_manifest_version | True | True | PASS |
| algorithmic-art-v1.0.0-96ad66bb_definition_pipeline | True | True | PASS |
| algorithmic-art-v1.0.0-96ad66bb_persona_parse | True | True | PASS |
| algorithmic-art-v1.0.0-96ad66bb_kb_nonempty | True | True | PASS |
| algorithmic-art-v1.0.0-96ad66bb_kg_graph | True | True | PASS |
| brand-guidelines-v1.0.0-e6dde892_files_exist | True | True | PASS |
| brand-guidelines-v1.0.0-e6dde892_manifest_id | True | True | PASS |
| brand-guidelines-v1.0.0-e6dde892_manifest_version | True | True | PASS |
| brand-guidelines-v1.0.0-e6dde892_definition_pipeline | True | True | PASS |
| brand-guidelines-v1.0.0-e6dde892_persona_parse | True | True | PASS |
| brand-guidelines-v1.0.0-e6dde892_kb_nonempty | True | True | PASS |
| brand-guidelines-v1.0.0-e6dde892_kg_graph | True | True | PASS |
| canvas-design-v1.0.0-04e28042_files_exist | True | True | PASS |
| canvas-design-v1.0.0-04e28042_manifest_id | True | True | PASS |
| canvas-design-v1.0.0-04e28042_manifest_version | True | True | PASS |
| canvas-design-v1.0.0-04e28042_definition_pipeline | True | True | PASS |
| canvas-design-v1.0.0-04e28042_persona_parse | True | True | PASS |
| canvas-design-v1.0.0-04e28042_kb_nonempty | True | True | PASS |
| canvas-design-v1.0.0-04e28042_kg_graph | True | True | PASS |
| claude-api-v1.0.0-c43fcb17_files_exist | True | True | PASS |
| claude-api-v1.0.0-c43fcb17_manifest_id | True | True | PASS |
| claude-api-v1.0.0-c43fcb17_manifest_version | True | True | PASS |
| claude-api-v1.0.0-c43fcb17_definition_pipeline | True | True | PASS |
| claude-api-v1.0.0-c43fcb17_persona_parse | True | True | PASS |
| claude-api-v1.0.0-c43fcb17_kb_nonempty | True | True | PASS |
| claude-api-v1.0.0-c43fcb17_kg_graph | True | True | PASS |
| doc-coauthoring-v1.0.0-4bfea1b8_files_exist | True | True | PASS |
| doc-coauthoring-v1.0.0-4bfea1b8_manifest_id | True | True | PASS |
| doc-coauthoring-v1.0.0-4bfea1b8_manifest_version | True | True | PASS |
| doc-coauthoring-v1.0.0-4bfea1b8_definition_pipeline | True | True | PASS |
| doc-coauthoring-v1.0.0-4bfea1b8_persona_parse | True | True | PASS |
| doc-coauthoring-v1.0.0-4bfea1b8_kb_nonempty | True | True | PASS |
| doc-coauthoring-v1.0.0-4bfea1b8_kg_graph | True | True | PASS |
| docx-v1.0.0-bd7cc055_files_exist | True | True | PASS |
| docx-v1.0.0-bd7cc055_manifest_id | True | True | PASS |
| docx-v1.0.0-bd7cc055_manifest_version | True | True | PASS |
| docx-v1.0.0-bd7cc055_definition_pipeline | True | True | PASS |
| docx-v1.0.0-bd7cc055_persona_parse | True | True | PASS |
| docx-v1.0.0-bd7cc055_kb_nonempty | True | True | PASS |
| docx-v1.0.0-bd7cc055_kg_graph | True | True | PASS |
| domain-agent-builder_files_exist | True | True | PASS |
| domain-agent-builder_manifest_id | True | True | PASS |
| domain-agent-builder_manifest_version | True | True | PASS |
| domain-agent-builder_definition_pipeline | True | True | PASS |
| domain-agent-builder_persona_parse | True | True | PASS |
| domain-agent-builder_kb_nonempty | True | True | PASS |
| domain-agent-builder_kg_graph | True | True | PASS |
| domain-sap-cap-v1.0.0-f23f10ee_files_exist | True | True | PASS |
| domain-sap-cap-v1.0.0-f23f10ee_manifest_id | True | True | PASS |
| domain-sap-cap-v1.0.0-f23f10ee_manifest_version | True | True | PASS |
| domain-sap-cap-v1.0.0-f23f10ee_definition_pipeline | True | True | PASS |
| domain-sap-cap-v1.0.0-f23f10ee_persona_parse | True | True | PASS |
| domain-sap-cap-v1.0.0-f23f10ee_kb_nonempty | True | True | PASS |
| domain-sap-cap-v1.0.0-f23f10ee_kg_graph | True | True | PASS |
| frontend-design-v1.0.0-0f96de3e_files_exist | True | True | PASS |
| frontend-design-v1.0.0-0f96de3e_manifest_id | True | True | PASS |
| frontend-design-v1.0.0-0f96de3e_manifest_version | True | True | PASS |
| frontend-design-v1.0.0-0f96de3e_definition_pipeline | True | True | PASS |
| frontend-design-v1.0.0-0f96de3e_persona_parse | True | True | PASS |
| frontend-design-v1.0.0-0f96de3e_kb_nonempty | True | True | PASS |
| frontend-design-v1.0.0-0f96de3e_kg_graph | True | True | PASS |
| frontend-design-v1.0.0-27245b0a_files_exist | True | True | PASS |
| frontend-design-v1.0.0-27245b0a_manifest_id | True | True | PASS |
| frontend-design-v1.0.0-27245b0a_manifest_version | True | True | PASS |
| frontend-design-v1.0.0-27245b0a_definition_pipeline | True | True | PASS |
| frontend-design-v1.0.0-27245b0a_persona_parse | True | True | PASS |
| frontend-design-v1.0.0-27245b0a_kb_nonempty | True | True | PASS |
| frontend-design-v1.0.0-27245b0a_kg_graph | True | True | PASS |
| frontend-design-v1.0.0-38620c5e_files_exist | True | True | PASS |
| frontend-design-v1.0.0-38620c5e_manifest_id | True | True | PASS |
| frontend-design-v1.0.0-38620c5e_manifest_version | True | True | PASS |
| frontend-design-v1.0.0-38620c5e_definition_pipeline | True | True | PASS |
| frontend-design-v1.0.0-38620c5e_persona_parse | True | True | PASS |
| frontend-design-v1.0.0-38620c5e_kb_nonempty | True | True | PASS |
| frontend-design-v1.0.0-38620c5e_kg_graph | True | True | PASS |
| frontend-design-v1.0.0-a97550c4_files_exist | True | True | PASS |
| frontend-design-v1.0.0-a97550c4_manifest_id | True | True | PASS |
| frontend-design-v1.0.0-a97550c4_manifest_version | True | True | PASS |
| frontend-design-v1.0.0-a97550c4_definition_pipeline | True | True | PASS |
| frontend-design-v1.0.0-a97550c4_persona_parse | True | True | PASS |
| frontend-design-v1.0.0-a97550c4_kb_nonempty | True | True | PASS |
| frontend-design-v1.0.0-a97550c4_kg_graph | True | True | PASS |
| frontend-design-v1.0.0-aed0ec02_files_exist | True | True | PASS |
| frontend-design-v1.0.0-aed0ec02_manifest_id | True | True | PASS |
| frontend-design-v1.0.0-aed0ec02_manifest_version | True | True | PASS |
| frontend-design-v1.0.0-aed0ec02_definition_pipeline | True | True | PASS |
| frontend-design-v1.0.0-aed0ec02_persona_parse | True | True | PASS |
| frontend-design-v1.0.0-aed0ec02_kb_nonempty | True | True | PASS |
| frontend-design-v1.0.0-aed0ec02_kg_graph | True | True | PASS |
| frontend-design-v1.0.0-c0c8ecdf_files_exist | True | True | PASS |
| frontend-design-v1.0.0-c0c8ecdf_manifest_id | True | True | PASS |
| frontend-design-v1.0.0-c0c8ecdf_manifest_version | True | True | PASS |
| frontend-design-v1.0.0-c0c8ecdf_definition_pipeline | True | True | PASS |
| frontend-design-v1.0.0-c0c8ecdf_persona_parse | True | True | PASS |
| frontend-design-v1.0.0-c0c8ecdf_kb_nonempty | True | True | PASS |
| frontend-design-v1.0.0-c0c8ecdf_kg_graph | True | True | PASS |
| frontend-design-v1.0.0-c4ebfb1c_files_exist | True | True | PASS |
| frontend-design-v1.0.0-c4ebfb1c_manifest_id | True | True | PASS |
| frontend-design-v1.0.0-c4ebfb1c_manifest_version | True | True | PASS |
| frontend-design-v1.0.0-c4ebfb1c_definition_pipeline | True | True | PASS |
| frontend-design-v1.0.0-c4ebfb1c_persona_parse | True | True | PASS |
| frontend-design-v1.0.0-c4ebfb1c_kb_nonempty | True | True | PASS |
| frontend-design-v1.0.0-c4ebfb1c_kg_graph | True | True | PASS |
| frontend-design-v1.0.0-ff6ab491_files_exist | True | True | PASS |
| frontend-design-v1.0.0-ff6ab491_manifest_id | True | True | PASS |
| frontend-design-v1.0.0-ff6ab491_manifest_version | True | True | PASS |
| frontend-design-v1.0.0-ff6ab491_definition_pipeline | True | True | PASS |
| frontend-design-v1.0.0-ff6ab491_persona_parse | True | True | PASS |
| frontend-design-v1.0.0-ff6ab491_kb_nonempty | True | True | PASS |
| frontend-design-v1.0.0-ff6ab491_kg_graph | True | True | PASS |
| internal-comms-v1.0.0-1984d41b_files_exist | True | True | PASS |
| internal-comms-v1.0.0-1984d41b_manifest_id | True | True | PASS |
| internal-comms-v1.0.0-1984d41b_manifest_version | True | True | PASS |
| internal-comms-v1.0.0-1984d41b_definition_pipeline | True | True | PASS |
| internal-comms-v1.0.0-1984d41b_persona_parse | True | True | PASS |
| internal-comms-v1.0.0-1984d41b_kb_nonempty | True | True | PASS |
| internal-comms-v1.0.0-1984d41b_kg_graph | True | True | PASS |
| jefferson_files_exist | True | True | PASS |
| jefferson_manifest_id | True | True | PASS |
| jefferson_manifest_version | True | True | PASS |
| jefferson_definition_pipeline | True | True | PASS |
| jefferson_persona_parse | True | True | PASS |
| jefferson_kb_nonempty | True | True | PASS |
| jefferson_kg_graph | True | True | PASS |
| mcp-builder-v1.0.0-689f2526_files_exist | True | True | PASS |
| mcp-builder-v1.0.0-689f2526_manifest_id | True | True | PASS |
| mcp-builder-v1.0.0-689f2526_manifest_version | True | True | PASS |
| mcp-builder-v1.0.0-689f2526_definition_pipeline | True | True | PASS |
| mcp-builder-v1.0.0-689f2526_persona_parse | True | True | PASS |
| mcp-builder-v1.0.0-689f2526_kb_nonempty | True | True | PASS |
| mcp-builder-v1.0.0-689f2526_kg_graph | True | True | PASS |
| pdf-v1.0.0-9ab91eb5_files_exist | True | True | PASS |
| pdf-v1.0.0-9ab91eb5_manifest_id | True | True | PASS |
| pdf-v1.0.0-9ab91eb5_manifest_version | True | True | PASS |
| pdf-v1.0.0-9ab91eb5_definition_pipeline | True | True | PASS |
| pdf-v1.0.0-9ab91eb5_persona_parse | True | True | PASS |
| pdf-v1.0.0-9ab91eb5_kb_nonempty | True | True | PASS |
| pdf-v1.0.0-9ab91eb5_kg_graph | True | True | PASS |
| pptx-v1.0.0-31e5aa80_files_exist | True | True | PASS |
| pptx-v1.0.0-31e5aa80_manifest_id | True | True | PASS |
| pptx-v1.0.0-31e5aa80_manifest_version | True | True | PASS |
| pptx-v1.0.0-31e5aa80_definition_pipeline | True | True | PASS |
| pptx-v1.0.0-31e5aa80_persona_parse | True | True | PASS |
| pptx-v1.0.0-31e5aa80_kb_nonempty | True | True | PASS |
| pptx-v1.0.0-31e5aa80_kg_graph | True | True | PASS |
| scholar-buffett_files_exist | True | True | PASS |
| scholar-buffett_manifest_id | True | True | PASS |
| scholar-buffett_manifest_version | True | True | PASS |
| scholar-buffett_definition_pipeline | True | True | PASS |
| scholar-buffett_persona_parse | True | True | PASS |
| scholar-buffett_kb_nonempty | True | True | PASS |
| scholar-buffett_kg_graph | True | True | PASS |
| skill-creator-v1.0.0-9a0ea093_files_exist | True | True | PASS |
| skill-creator-v1.0.0-9a0ea093_manifest_id | True | True | PASS |
| skill-creator-v1.0.0-9a0ea093_manifest_version | True | True | PASS |
| skill-creator-v1.0.0-9a0ea093_definition_pipeline | True | True | PASS |
| skill-creator-v1.0.0-9a0ea093_persona_parse | True | True | PASS |
| skill-creator-v1.0.0-9a0ea093_kb_nonempty | True | True | PASS |
| skill-creator-v1.0.0-9a0ea093_kg_graph | True | True | PASS |
| slack-gif-creator-v1.0.0-2630f4cd_files_exist | True | True | PASS |
| slack-gif-creator-v1.0.0-2630f4cd_manifest_id | True | True | PASS |
| slack-gif-creator-v1.0.0-2630f4cd_manifest_version | True | True | PASS |
| slack-gif-creator-v1.0.0-2630f4cd_definition_pipeline | True | True | PASS |
| slack-gif-creator-v1.0.0-2630f4cd_persona_parse | True | True | PASS |
| slack-gif-creator-v1.0.0-2630f4cd_kb_nonempty | True | True | PASS |
| slack-gif-creator-v1.0.0-2630f4cd_kg_graph | True | True | PASS |
| test-agent-v1.0.0-24f8476e_files_exist | True | True | PASS |
| test-agent-v1.0.0-24f8476e_manifest_id | True | True | PASS |
| test-agent-v1.0.0-24f8476e_manifest_version | True | True | PASS |
| test-agent-v1.0.0-24f8476e_definition_pipeline | True | True | PASS |
| test-agent-v1.0.0-24f8476e_persona_parse | True | True | PASS |
| test-agent-v1.0.0-24f8476e_kb_nonempty | True | True | PASS |
| test-agent-v1.0.0-24f8476e_kg_graph | True | True | PASS |
| theme-factory-v1.0.0-0a693e1e_files_exist | True | True | PASS |
| theme-factory-v1.0.0-0a693e1e_manifest_id | True | True | PASS |
| theme-factory-v1.0.0-0a693e1e_manifest_version | True | True | PASS |
| theme-factory-v1.0.0-0a693e1e_definition_pipeline | True | True | PASS |
| theme-factory-v1.0.0-0a693e1e_persona_parse | True | True | PASS |
| theme-factory-v1.0.0-0a693e1e_kb_nonempty | True | True | PASS |
| theme-factory-v1.0.0-0a693e1e_kg_graph | True | True | PASS |
| web-artifacts-builder-v1.0.0-589d4c03_files_exist | True | True | PASS |
| web-artifacts-builder-v1.0.0-589d4c03_manifest_id | True | True | PASS |
| web-artifacts-builder-v1.0.0-589d4c03_manifest_version | True | True | PASS |
| web-artifacts-builder-v1.0.0-589d4c03_definition_pipeline | True | True | PASS |
| web-artifacts-builder-v1.0.0-589d4c03_persona_parse | True | True | PASS |
| web-artifacts-builder-v1.0.0-589d4c03_kb_nonempty | True | True | PASS |
| web-artifacts-builder-v1.0.0-589d4c03_kg_graph | True | True | PASS |
| webapp-testing-v1.0.0-9906c370_files_exist | True | True | PASS |
| webapp-testing-v1.0.0-9906c370_manifest_id | True | True | PASS |
| webapp-testing-v1.0.0-9906c370_manifest_version | True | True | PASS |
| webapp-testing-v1.0.0-9906c370_definition_pipeline | True | True | PASS |
| webapp-testing-v1.0.0-9906c370_persona_parse | True | True | PASS |
| webapp-testing-v1.0.0-9906c370_kb_nonempty | True | True | PASS |
| webapp-testing-v1.0.0-9906c370_kg_graph | True | True | PASS |
| xlsx-v1.0.0-f6f859fc_files_exist | True | True | PASS |
| xlsx-v1.0.0-f6f859fc_manifest_id | True | True | PASS |
| xlsx-v1.0.0-f6f859fc_manifest_version | True | True | PASS |
| xlsx-v1.0.0-f6f859fc_definition_pipeline | True | True | PASS |
| xlsx-v1.0.0-f6f859fc_persona_parse | True | True | PASS |
| xlsx-v1.0.0-f6f859fc_kb_nonempty | True | True | PASS |
| xlsx-v1.0.0-f6f859fc_kg_graph | True | True | PASS |


### Stamper Tests

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| stamp_empty_valid | True | True | PASS |
| files_prefixed | True | True | PASS |
| stamp_from_md | True | True | PASS |
| stamp_from_jsonld | True | True | PASS |
| restamp_lineage | True | True | PASS |
| validate_invalid | False | False | PASS |


### Education Queue Tests

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| queue_failure_status | pending | pending | PASS |
| queue_failure_score | 0.4 | 0.4 | PASS |
| get_pending | 1 | 1 | PASS |
| update_status | researching | researching | PASS |
| queue_stats_total | 1 | 1 | PASS |
| queue_stats_researching | 1 | 1 | PASS |
| get_oldest_pending | True | True | PASS |
| parse_json_clean | True | True | PASS |
| parse_json_markdown | True | True | PASS |
| parse_json_garbage | exception | exception | PASS |
| build_research_prompt | True | True | PASS |


### Habitat Tests

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| register_count | 2 | 2 | PASS |
| route_exact | ['agent-001'] | ['agent-001'] | PASS |
| route_wildcard | ['agent-002'] | ['agent-002'] | PASS |
| route_multi | 2 | 2 | PASS |
| route_none | [] | [] | PASS |
| detect_gap | True | True | PASS |
| broadcast | True | True | PASS |
| stats_capsules | 2 | 2 | PASS |
| unregister | 1 | 1 | PASS |
| log | True | True | PASS |


### LLM Tests

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| stub_text | True | True | PASS |
| stub_cost | 0.0 | 0.0 | PASS |
| make_llm_fn | True | True | PASS |
| unknown_provider | True | True | PASS |
| estimate_cost | True | True | PASS |


### Report Generator Tests

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| report_no_crash | True | FAIL: '_io.StringIO' object ha | FAIL |


### Cross-Module Integration

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| integration_pipeline_runs | True | True | PASS |
| integration_aec_in_review | True | True | PASS |
| integration_telemetry | True | True | PASS |
| integration_stamp_load_run | True | True | PASS |
| integration_habitat_route | True | True | PASS |


### Known Issues Status

| Issue | Status | Details |
|-------|--------|---------|
| magnitude_million | PASS | {'expected': 25000000, 'actual': [('$25 million', 25000000.0 |
| magnitude_billion | PASS | {'expected': 373300000000, 'actual': [('$373.3 billion', 373 |
| numeric_tolerance | PASS | {'expected': '99.5 matches 100 within 1%', 'actual': 'ground |
| aether-validator-v1.0.0-d5a16071_queue | N/A | {'total': 4, 'pending': 4, 'scores': [0.0, 0.0, 0.0, 0.0]} |
| domain-agent-builder_queue | N/A | {'total': 4, 'pending': 2, 'scores': [0.5, 0.5, 0.667, 0.714 |
| frontend-design-v1.0.0-38620c5e_queue | N/A | {'total': 1, 'pending': 0, 'scores': [0.25]} |
| frontend-design-v1.0.0-ff6ab491_queue | N/A | {'total': 8, 'pending': 8, 'scores': [0.4, 0.333, 0.667, 0.2 |
| jefferson_queue | N/A | {'total': 11, 'pending': 10, 'scores': [0.143, 0.0, 0.0, 0.0 |
| scholar-buffett_queue | N/A | {'total': 13, 'pending': 8, 'scores': [0.091, 0.333, 0.125,  |
| test-agent-v1.0.0-24f8476e_queue | N/A | {'total': 1, 'pending': 0, 'scores': [0.0]} |


### Capsule Inventory

| Capsule | Valid | KB Size | KG Nodes | AEC Score |
|---------|-------|---------|----------|-----------|
| `aether-validator-v1.0.0-d5a16071` | Yes | 986 | 6 | N/A |
| `algorithmic-art-v1.0.0-96ad66bb` | Yes | 19327 | 50 | N/A |
| `brand-guidelines-v1.0.0-e6dde892` | Yes | 1913 | 52 | N/A |
| `canvas-design-v1.0.0-04e28042` | Yes | 11566 | 54 | N/A |
| `claude-api-v1.0.0-c43fcb17` | Yes | 17731 | 59 | N/A |
| `doc-coauthoring-v1.0.0-4bfea1b8` | Yes | 15341 | 67 | N/A |
| `docx-v1.0.0-bd7cc055` | Yes | 19181 | 50 | N/A |
| `domain-agent-builder` | Yes | 3435 | 22 | N/A |
| `domain-sap-cap-v1.0.0-f23f10ee` | Yes | 31940 | 15 | N/A |
| `frontend-design-v1.0.0-0f96de3e` | Yes | 3956 | 0 | N/A |
| `frontend-design-v1.0.0-27245b0a` | Yes | 3956 | 0 | N/A |
| `frontend-design-v1.0.0-38620c5e` | Yes | 3956 | 55 | N/A |
| `frontend-design-v1.0.0-a97550c4` | Yes | 3956 | 0 | N/A |
| `frontend-design-v1.0.0-aed0ec02` | Yes | 3956 | 0 | N/A |
| `frontend-design-v1.0.0-c0c8ecdf` | Yes | 3956 | 0 | N/A |
| `frontend-design-v1.0.0-c4ebfb1c` | Yes | 3956 | 65 | N/A |
| `frontend-design-v1.0.0-ff6ab491` | Yes | 3956 | 73 | N/A |
| `internal-comms-v1.0.0-1984d41b` | Yes | 1098 | 34 | N/A |
| `jefferson` | Yes | 28692 | 51 | 0.0 |
| `mcp-builder-v1.0.0-689f2526` | Yes | 8701 | 63 | N/A |
| `pdf-v1.0.0-9ab91eb5` | Yes | 7511 | 55 | N/A |
| `pptx-v1.0.0-31e5aa80` | Yes | 8344 | 64 | N/A |
| `scholar-buffett` | Yes | 21148 | 48 | 0.0 |
| `skill-creator-v1.0.0-9a0ea093` | Yes | 32624 | 56 | N/A |
| `slack-gif-creator-v1.0.0-2630f4cd` | Yes | 7527 | 80 | N/A |
| `test-agent-v1.0.0-24f8476e` | Yes | 711 | 4 | 1.0 |
| `theme-factory-v1.0.0-0a693e1e` | Yes | 2778 | 51 | N/A |
| `web-artifacts-builder-v1.0.0-589d4c03` | Yes | 2695 | 43 | N/A |
| `webapp-testing-v1.0.0-9906c370` | Yes | 3574 | 52 | N/A |
| `xlsx-v1.0.0-f6f859fc` | Yes | 10423 | 67 | N/A |


### Codebase Metrics

- **Total Python files:** 14
- **Total lines:** 7005
- **External dependencies:** anthropic (optional), openai (optional)
- **Python version:** 3.11+

#### Lines per file:

| File | Lines |
|------|-------|
| `dashboard.py` | 1259 |
| `tests/test_exhaustive.py` | 1030 |
| `aec_concept.py` | 812 |
| `education.py` | 617 |
| `aether.py` | 485 |
| `cli.py` | 480 |
| `stamper.py` | 475 |
| `ingest.py` | 466 |
| `aec.py` | 378 |
| `report.py` | 299 |
| `kg.py` | 219 |
| `tests/test_aec_standalone.py` | 198 |
| `llm.py` | 153 |
| `habitat.py` | 134 |

---

### Recommendations

- **3 test(s) failed** - Review failed tests above

---

*Report generated by test_exhaustive.py*