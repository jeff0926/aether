# AETHER System Diagnostic Report
## Generated: 2026-03-09T20:50:16.555850
## Framework Version: Phase 2

---

### Executive Summary
- **Total tests:** 142
- **Passed:** 139
- **Failed:** 3
- **Pass rate:** 97.9%

---

### Module Health

| Module | Import | Notes |
|--------|--------|-------|
| `aec` | PASS |  |
| `aether` | PASS |  |
| `cli` | PASS |  |
| `education` | PASS |  |
| `habitat` | PASS |  |
| `kg` | PASS |  |
| `llm` | PASS |  |
| `report` | PASS |  |
| `stamper` | PASS |  |


### AEC Verification Tests

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| split_basic | 3 | 3 | PASS |
| split_abbreviations | 2 | 2 | PASS |
| split_empty | [] | [] | PASS |
| split_short | [] | [] | PASS |
| extract_numbers | True | True | PASS |
| extract_year | True | True | PASS |
| extract_full_date | True | True | PASS |
| extract_percentage | True | False | FAIL |
| extract_name | True | True | PASS |
| extract_magnitude_million | True | True | PASS |
| extract_magnitude_billion | True | True | PASS |
| gate_match | True | True | PASS |
| gate_no_match | False | True | FAIL |
| gate_no_values | no_values | no_values | PASS |
| gate_empty_kg | no_input | no_input | PASS |
| verify_grounded_score | True | True | PASS |
| verify_grounded_passed | True | True | PASS |
| verify_mixed_has_ungrounded | True | True | PASS |
| verify_all_persona_passes | True | True | PASS |
| verify_all_persona_score | 1.0 | 1.0 | PASS |
| verify_empty_response | False | False | PASS |
| verify_numeric_tolerance | True | True | PASS |


### Knowledge Graph Tests

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| load_nonexistent | True | True | PASS |
| stats_core | 1 | 1 | PASS |
| stats_acquired | 1 | 1 | PASS |
| stats_provenance | 1 | 1 | PASS |
| mark_deprecated | 1 | 1 | PASS |
| stats_deprecated | 1 | 1 | PASS |
| mark_updated_value | 150 | 150 | PASS |
| query_nodes | True | True | PASS |
| query_empty | [] | [] | PASS |
| invalid_origin | ValueError | ValueError | PASS |
| save_reload | 3 | 3 | PASS |


### Capsule & Pipeline Tests

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| validate_aether-validator-v1.0.0-d5a16071 | [] | [] | PASS |
| validate_domain-agent-builder | [] | [] | PASS |
| validate_domain-sap-cap-v1.0.0-f23f10ee | [] | [] | PASS |
| validate_jefferson | [] | [] | PASS |
| validate_scholar-buffett | [] | [] | PASS |
| validate_test-agent-v1.0.0-24f8476e | [] | [] | PASS |
| load_aether-validator-v1.0.0-d5a16071 | True | True | PASS |
| load_domain-agent-builder | True | True | PASS |
| load_domain-sap-cap-v1.0.0-f23f10ee | True | True | PASS |
| load_jefferson | True | True | PASS |
| load_scholar-buffett | True | True | PASS |
| load_test-agent-v1.0.0-24f8476e | True | True | PASS |
| run_jefferson_distill | True | True | PASS |
| run_jefferson_augment | True | True | PASS |
| run_jefferson_generate | True | True | PASS |
| run_jefferson_review | True | True | PASS |
| run_jefferson_telemetry | True | True | PASS |
| run_scholar-buffett_distill | True | True | PASS |
| run_scholar-buffett_augment | True | True | PASS |
| run_scholar-buffett_generate | True | True | PASS |
| run_scholar-buffett_review | True | True | PASS |
| run_scholar-buffett_telemetry | True | True | PASS |
| run_test-agent-v1.0.0-24f8476e_distill | True | True | PASS |
| run_test-agent-v1.0.0-24f8476e_augment | True | True | PASS |
| run_test-agent-v1.0.0-24f8476e_generate | True | True | PASS |
| run_test-agent-v1.0.0-24f8476e_review | True | True | PASS |
| run_test-agent-v1.0.0-24f8476e_telemetry | True | True | PASS |
| validator_generate_disabled | False | False | PASS |
| generate_id_format | True | True | PASS |
| aether-validator-v1.0.0-d5a16071_files_exist | True | True | PASS |
| aether-validator-v1.0.0-d5a16071_manifest_id | True | True | PASS |
| aether-validator-v1.0.0-d5a16071_manifest_version | True | True | PASS |
| aether-validator-v1.0.0-d5a16071_definition_pipeline | True | True | PASS |
| aether-validator-v1.0.0-d5a16071_persona_parse | True | True | PASS |
| aether-validator-v1.0.0-d5a16071_kb_nonempty | True | True | PASS |
| aether-validator-v1.0.0-d5a16071_kg_graph | True | True | PASS |
| domain-agent-builder_files_exist | True | True | PASS |
| domain-agent-builder_manifest_id | True | True | PASS |
| domain-agent-builder_manifest_version | True | True | PASS |
| domain-agent-builder_definition_pipeline | True | True | PASS |
| domain-agent-builder_persona_parse | True | True | PASS |
| domain-agent-builder_kb_nonempty | True | True | PASS |
| domain-agent-builder_kg_graph | True | True | PASS |
| domain-sap-cap-v1.0.0-f23f10ee_files_exist | True | True | PASS |
| domain-sap-cap-v1.0.0-f23f10ee_manifest_id | True | True | PASS |
| domain-sap-cap-v1.0.0-f23f10ee_manifest_version | True | True | PASS |
| domain-sap-cap-v1.0.0-f23f10ee_definition_pipeline | True | True | PASS |
| domain-sap-cap-v1.0.0-f23f10ee_persona_parse | True | True | PASS |
| domain-sap-cap-v1.0.0-f23f10ee_kb_nonempty | True | True | PASS |
| domain-sap-cap-v1.0.0-f23f10ee_kg_graph | True | True | PASS |
| jefferson_files_exist | True | True | PASS |
| jefferson_manifest_id | True | True | PASS |
| jefferson_manifest_version | True | True | PASS |
| jefferson_definition_pipeline | True | True | PASS |
| jefferson_persona_parse | True | True | PASS |
| jefferson_kb_nonempty | True | True | PASS |
| jefferson_kg_graph | True | True | PASS |
| scholar-buffett_files_exist | True | True | PASS |
| scholar-buffett_manifest_id | True | True | PASS |
| scholar-buffett_manifest_version | True | True | PASS |
| scholar-buffett_definition_pipeline | True | True | PASS |
| scholar-buffett_persona_parse | True | True | PASS |
| scholar-buffett_kb_nonempty | True | True | PASS |
| scholar-buffett_kg_graph | True | True | PASS |
| test-agent-v1.0.0-24f8476e_files_exist | True | True | PASS |
| test-agent-v1.0.0-24f8476e_manifest_id | True | True | PASS |
| test-agent-v1.0.0-24f8476e_manifest_version | True | True | PASS |
| test-agent-v1.0.0-24f8476e_definition_pipeline | True | True | PASS |
| test-agent-v1.0.0-24f8476e_persona_parse | True | True | PASS |
| test-agent-v1.0.0-24f8476e_kb_nonempty | True | True | PASS |
| test-agent-v1.0.0-24f8476e_kg_graph | True | True | PASS |


### Stamper Tests

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| stamp_empty_valid | True | True | PASS |
| files_prefixed | True | True | PASS |
| stamp_from_md | True | True | PASS |
| stamp_from_jsonld | True | True | PASS |
| restamp_lineage | True | True | PASS |
| validate_invalid | False | False | PASS |


### Education Queue Tests

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| queue_failure_status | pending | pending | PASS |
| queue_failure_score | 0.4 | 0.4 | PASS |
| get_pending | 1 | 1 | PASS |
| update_status | researching | researching | PASS |
| queue_stats_total | 1 | 1 | PASS |
| queue_stats_researching | 1 | 1 | PASS |
| get_oldest_pending | True | True | PASS |
| parse_json_clean | True | True | PASS |
| parse_json_markdown | True | True | PASS |
| parse_json_garbage | exception | exception | PASS |
| build_research_prompt | True | True | PASS |


### Habitat Tests

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| register_count | 2 | 2 | PASS |
| route_exact | ['agent-001'] | ['agent-001'] | PASS |
| route_wildcard | ['agent-002'] | ['agent-002'] | PASS |
| route_multi | 2 | 2 | PASS |
| route_none | [] | [] | PASS |
| detect_gap | True | True | PASS |
| broadcast | True | True | PASS |
| stats_capsules | 2 | 2 | PASS |
| unregister | 1 | 1 | PASS |
| log | True | True | PASS |


### LLM Tests

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| stub_text | True | True | PASS |
| stub_cost | 0.0 | 0.0 | PASS |
| make_llm_fn | True | True | PASS |
| unknown_provider | True | True | PASS |
| estimate_cost | True | True | PASS |


### Report Generator Tests

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| report_no_crash | True | FAIL: '_io.StringIO' object ha | FAIL |


### Cross-Module Integration

| Test | Expected | Actual | Status |
|------|----------|--------|--------|
| integration_pipeline_runs | True | True | PASS |
| integration_aec_in_review | True | True | PASS |
| integration_telemetry | True | True | PASS |
| integration_stamp_load_run | True | True | PASS |
| integration_habitat_route | True | True | PASS |


### Known Issues Status

| Issue | Status | Details |
|-------|--------|---------|
| magnitude_million | PASS | {'expected': 25000000, 'actual': [('$25 million', 25000000.0 |
| magnitude_billion | PASS | {'expected': 373300000000, 'actual': [('$373.3 billion', 373 |
| numeric_tolerance | PASS | {'expected': '99.5 matches 100 within 1%', 'actual': 'ground |
| aether-validator-v1.0.0-d5a16071_queue | N/A | {'total': 1, 'pending': 1, 'scores': [0.0]} |
| domain-agent-builder_queue | N/A | {'total': 4, 'pending': 2, 'scores': [0.5, 0.5, 0.667, 0.714 |
| jefferson_queue | N/A | {'total': 3, 'pending': 2, 'scores': [0.143, 0.0, 0.0]} |
| scholar-buffett_queue | N/A | {'total': 9, 'pending': 4, 'scores': [0.091, 0.333, 0.125, 0 |
| test-agent-v1.0.0-24f8476e_queue | N/A | {'total': 1, 'pending': 0, 'scores': [0.0]} |


### Capsule Inventory

| Capsule | Valid | KB Size | KG Nodes | AEC Score |
|---------|-------|---------|----------|-----------|
| `aether-validator-v1.0.0-d5a16071` | Yes | 986 | 6 | N/A |
| `domain-agent-builder` | Yes | 3435 | 22 | N/A |
| `domain-sap-cap-v1.0.0-f23f10ee` | Yes | 31940 | 15 | N/A |
| `jefferson` | Yes | 28692 | 51 | 0.0 |
| `scholar-buffett` | Yes | 21148 | 48 | 0.0 |
| `test-agent-v1.0.0-24f8476e` | Yes | 711 | 4 | 1.0 |


### Codebase Metrics

- **Total Python files:** 12
- **Total lines:** 3835
- **External dependencies:** anthropic (optional), openai (optional)
- **Python version:** 3.11+

#### Lines per file:

| File | Lines |
|------|-------|
| `tests/test_exhaustive.py` | 1030 |
| `education.py` | 370 |
| `aether.py` | 360 |
| `ingest.py` | 326 |
| `cli.py` | 322 |
| `report.py` | 298 |
| `aec.py` | 255 |
| `kg.py` | 219 |
| `tests/test_aec_standalone.py` | 198 |
| `stamper.py` | 170 |
| `llm.py` | 153 |
| `habitat.py` | 134 |

---

### Recommendations

- **3 test(s) failed** - Review failed tests above

---

*Report generated by test_exhaustive.py*